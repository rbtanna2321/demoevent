module.exports = function(app) {
	var express = require("express");
	var router = express.Router();
	var Excel = require('exceljs');
	const Emplyee = require('../models/user.model.js');
	var async = require("async");
	const http = require('http').createServer(app);
	const io = require('socket.io').listen(http);


	var path = __basedir + '/views';
	app.set('views', __dirname + '/views');
	app.use(express.static(__dirname + '/views'));
	app.use('/css', express.static(__dirname + 'css'));

	app.get('/', (req, res) => {
		res.sendFile(path + "/index.html")
	});

	io.on('connection', function (socket) {
		socket.on('sales:add:data', function (data, scb) {
			console.log(data)
				.then(response => {
					if (data.recipe) {
						if (data.recipe._id) {
							Recipe.findOneAndUpdate({
								_id: data.recipe._id,
								isDeleted: false
							}, data.recipe, {new: true})
								.then(exp => {
									socket(socket, scb, exp, {event: "sales:add:data:success"});
								});
						} else {
							data.recipe.store = store._id;
							Recipe.create(data.recipe)
								.then(exp => {
									socket(socket, scb, exp, {event: "sales:add:data:success"});
								}).catch(err => {
								_logger.error(err);
								socket(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:add:data:error"});
							});
						}
					}

				});
		});

	});

// 	// Save a User to MongoDB
// 	app.post('/api/restaurants/save', restaurants.save);
// 	// Retrieve all Users
// 	app.get('/api/users/all', restaurants.findAll);
//
// 	// app.get('/api/booking/Download', restaurants.download);
//
// 	app.get('/download', function (req, res, next) {
// 		Restaurant.find({isDeleted:false})
// 	.then(users => {
// 		var BookingRecords = users;
// 		var workbook = new Excel.Workbook();
// 		workbook.creator = 'Me';
// 		var sheetName = 'Data';
// 		var sheet = workbook.addWorksheet(sheetName);
// 		sheet.state = 'visible';
// 		sheet.columns = [
// 			{header: 'Restaurant', key: 'restaurant'},
// 			{header: 'Meal', key: 'meal'},
// 			{header: 'Number of People', key: 'numOfPeople'},
// 			{header: 'Date of Creation', key: 'createdAt'}
// 		];
// 		async.each(BookingRecords, function (row , cb) {
// 				sheet.addRow({
// 					restaurant: row.restaurant,
// 					meal: row.meal,
// 					numOfPeople: row.numOfMember,
// 					createdAt: row.createdAt,
// 				}).commit();
// 			cb();
// 		}, function (err, result) {
// 			workbook.xlsx.writeBuffer().then(function (data) {
// 				var returnObj = {buffer: data};
// 				res.send(returnObj)
// 			});
// 		});
// 	}).catch(err => {
// 	res.status(500).send({
// 		message: err.message
// 	});
// });
// 	});
// 		app.use("/", router);

		app.use("*", (req, res) => {
			res.sendFile(path + "/404.html");
		});

};