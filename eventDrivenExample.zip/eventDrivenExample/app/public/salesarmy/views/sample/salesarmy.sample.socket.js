'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  MODEL_NAME_CAPITAL = require('../api/models/server.MODEL_NAME.model');

module.exports.listen = function (io, socket) {

  socket.on("SOCKET_PREFIX:get", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 0 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {createdAt: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true
              };
              var qf = {store: store._id, isDeleted: false};
              if (data.MODEL_NAMEId) {
                qf._id = data.MODEL_NAMEId;
              }
              if (data.filters.searchText && data.filters.searchText.length > 0) {
                qf['$or'] = [];
                qf['$or'].push({'name': {'$regex': data.filters.searchText, '$options': 'i'}});
              }
              MODEL_NAME_CAPITAL.paginate(qf, options).then(function (documents) {
                socket.emit("SOCKET_PREFIX:get:success", documents);
              });
            } else {
              socket.emit("SOCKET_PREFIX:get:error", {message: "Something went wrong. Please try again later."});
            }
          });
      });
  });

  socket.on("SOCKET_PREFIX:add", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.MODEL_NAME) {
              if (data.MODEL_NAME._id) {
                MODEL_NAME_CAPITAL.findOneAndUpdate({
                  _id: data.MODEL_NAME._id,
                  store: store._id,
                  isDeleted: false
                }, data.MODEL_NAME, {new: true})
                  .then(exp => {
                    socket.emit("SOCKET_PREFIX:add:success", exp);
                  });
              } else {
                data.MODEL_NAME.store = store._id;
                MODEL_NAME_CAPITAL.create(data.MODEL_NAME)
                  .then(exp => {
                    socket.emit("SOCKET_PREFIX:add:success", exp);
                  }).catch(err => {
                  socket.emit("SOCKET_PREFIX:add:error", {message: "Something went wrong. Please try again later."});
                });
              }
            }
          });
      });
  });

  socket.on("SOCKET_PREFIX:delete", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              MODEL_NAME_CAPITAL.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isDeleted: true}, {new: true})
                .then(exp => {
                  socket.emit("SOCKET_PREFIX:delete:success", exp);
                });
            } else {
              socket.emit("SOCKET_PREFIX:delete:error", {message: "Something went wrong. Please try again later."});
            }
          });
      });
  });
};