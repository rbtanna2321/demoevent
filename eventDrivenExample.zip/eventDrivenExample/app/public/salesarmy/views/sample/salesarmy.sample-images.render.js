'use strict';

var express = require('express');
var router = express();
var path = require("path");
var oppressor = require("oppressor");
var fs = require("fs");
var Helper = require('../../../app/api/shared/server.helper');
var MODEL_NAME_CAPITAL = require('../models/server.MODEL_NAME.model');

router.get("/", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('html', require('ejs').renderFile);
      var offset = _.isUndefined(req.query.start) ? 0 : req.query.start;
      var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
      var sort = {createdAt: "desc"};
      if (!_.isUndefined(req.query.length)) {
        if (parseInt(req.query.length) === -1) {
          limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
        } else {
          if (parseInt(req.query.length) !== -1 && req.query.length !== undefined) {
            limit = req.query.length;
          } else {
            limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
          }
        }
      }
      if (!req.query.ajax) {
        limit = 0;
      }
      var options = {
        offset: parseInt(offset),
        limit: parseInt(limit),
        sort: sort,
        lean: true,
        populate: [{path: "attachments", model: "PrivateFile", select: '_id metadata fileId url store'}]
      };
      var qf = {store: store._id, isDeleted: false};
      if (req.query.search && req.query.search.value.length > 0) {
        qf['$or'] = [];
        qf['$or'].push({'name': {'$regex': req.query.search.value, '$options': 'i'}});
      }
      MODEL_NAME_CAPITAL.paginate(qf, options).then(function (documents) {
        if (req.query && req.query.ajax) {
          res.send({data: documents.docs, recordsFiltered: documents.total, recordsTotal: 0})
        } else {
          res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/HTML_FILE_NAME.html`), {
            store: store,
            employees: documents.docs,
            currentTotal: documents.pages
          });
        }
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

module.exports = router;