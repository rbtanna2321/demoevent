'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var CatalogSchema = new Schema({
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  employee: {
    type: mongoose.Schema.ObjectId,
    ref: 'Sales-Employee',
  },
  product: {
    type: mongoose.Schema.ObjectId,
    ref: 'Sales-Product',
  },
  user: {
    model: String,
    object: {
      type: mongoose.Schema.Types.ObjectId,
      refPath: "user.model"
    }
  },

  price: {type: Number},
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});


CatalogSchema.plugin(autopopulate);
CatalogSchema.plugin(Paginate);
CatalogSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Catalog', CatalogSchema);