'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  Rooms = require('../api/models/server.hotel.room.model');

module.exports.listen = function (io, socket) {

  socket.on("sales:room:get", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 0 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {createdAt: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true,
                populate: [{path: "file", model: "PrivateFile", select: '_id metadata fileId url store'},
                  {path:"hotel" , model:"Sales-Hotel" , select:"_id name "}]
              };
              var qf = {store: store._id, isDeleted: false};
              if (data.roomId) {
                qf._id = data.roomId;
              }
              qf.employee = data.filters.employee;
              if (data.filters.searchText && data.filters.searchText.length > 0) {
                qf['$or'] = [];
                qf['$or'].push({'name': {'$regex': data.filters.searchText, '$options': 'i'}});
                qf['$or'].push({'mobile': {'$regex': data.filters.searchText, '$options': 'i'}});
                qf['$or'].push({'information.vehicleNumber': {'$regex': data.filters.searchText, '$options': 'i'}});
                qf['$or'].push({'information.unitNumber': {'$regex': data.filters.searchText, '$options': 'i'}});
              }
              Rooms.paginate(qf, options).then(function (documents) {
                Helper.sendSocketResponse(socket, scb, documents, {event: "sales:room:get:success"});
              });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:room:get:error"});
            }
          });
      });
  });

  socket.on("sales:room:add", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data) {
              if (data._id) {
                Rooms.findOneAndUpdate({
                  _id: data._id,
                  store: store._id,
                  isDeleted: false
                }, data , {new: true})
                  .then(exp => {
                    Helper.sendSocketResponse(socket, scb, exp, {event: "sales:room:add:success"});
                  });
              } else {
                data.store = store._id;
                data.employee = response.user._id;
                Rooms.create(data)
                  .then(exp => {
                    Helper.sendSocketResponse(socket, scb, exp, {event: "sales:room:add:success"});
                  }).catch(err => {
                  _logger.error(err);
                  Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:room:add:error"});
                });
              }

            }
          });
      });
  });
  socket.on("sales:room:delete", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Rooms.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isDeleted: true}, {new: true})
                .then(exp => {
                  Helper.sendSocketResponse(socket, scb, exp, {event: "sales:room:delete:success"});
                })
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {
                message: "Something went wrong. Please try again later.",
                event: "sales:room:delete:error"
              })
            }
          })
      })

  })
};