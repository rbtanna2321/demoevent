'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  Storelocation = require('../api/models/server.store.locations.model');

module.exports.listen = function (io, socket) {

  socket.on("sales:store:location:get", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 0 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {createdAt: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true
              };
              var qf = {store: store._id, isDeleted: false};
              if (data.locationId) {
                qf._id = data.locationId;
              }
              if (data.filters.searchText && data.filters.searchText.length > 0) {
                qf['$or'] = [];
                qf['$or'].push({'name': {'$regex': data.filters.searchText, '$options': 'i'}});
              }
              Storelocation.paginate(qf, options).then(function (documents) {
                socket.emit("sales:store:location:get:success", documents);
              });
            } else {
              socket.emit("sales:store:location:get:error", {message: "Something went wrong. Please try again later."});
            }
          });
      });
  });

  socket.on("sales:store:location:add", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.location) {
              if (data.location._id) {
                Storelocation.findOneAndUpdate({
                  _id: data.location._id,
                  store: store._id,
                  isDeleted: false
                }, data.location, {new: true})
                  .then(exp => {
                    socket.emit("sales:store:location:add:success", exp);
                  });
              } else {
                data.location.store = store._id;
                Storelocation.create(data.location)
                  .then(exp => {
                    socket.emit("sales:store:location:add:success", exp);
                  }).catch(err => {
                  socket.emit("sales:store:location:add:error", {message: "Something went wrong. Please try again later."});
                });
              }
            }
          });
      });
  });

  socket.on("sales:store:location:delete", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Storelocation.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isDeleted: true}, {new: true})
                .then(exp => {
                  socket.emit("sales:store:location:delete:success", exp);
                });
            } else {
              socket.emit("sales:store:location:delete:error", {message: "Something went wrong. Please try again later."});
            }
          });
      });
  });
};