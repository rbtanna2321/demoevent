'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  Forms = require('../api/models/server.forms.model');

module.exports.listen = function (io, socket) {

  socket.on("sales:forms:get", function (data , scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 0 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {createdAt: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true
              };
              var qf = {store: store._id, isDeleted: false};
              if (data.formsId) {
                qf._id = data.formsId;
              }
              if (data.filters.searchText && data.filters.searchText.length > 0) {
                qf['$or'] = [];
                qf['$or'].push({'name': {'$regex': data.filters.searchText, '$options': 'i'}});
              }
              Forms.paginate(qf, options).then(function (documents) {
                Helper.sendSocketResponse(socket, scb, documents, {event: "sales:forms:get:success"});
              });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:forms:get:error"});
            }
          });
      });
  });

  socket.on("sales:forms:add", function (data , scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.forms) {
              if (data.forms._id) {
                Forms.findOneAndUpdate({
                  _id: data.forms._id,
                  store: store._id,
                  isDeleted: false
                }, data.forms, {new: true})
                  .then(exp => {
                    Helper.sendSocketResponse(socket, scb, exp, {event: "sales:forms:add:success"});
                  });
              } else {
                data.forms.store = store._id;
                Forms.create(data.forms)
                  .then(exp => {
                    Helper.sendSocketResponse(socket, scb, exp, {event: "sales:forms:add:success"});
                  }).catch(err => {
                  _logger.error(err);
                  Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:forms:add:error"});
                });
              }
            }
          });
      });
  });

  socket.on("sales:forms:delete", function (data , scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Forms.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isDeleted: true}, {new: true})
                .then(exp => {
                  Helper.sendSocketResponse(socket, scb, exp, {event: "sales:forms:delete:success"});
                });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:forms:delete:error"});
            }
          });
      });
  });
};