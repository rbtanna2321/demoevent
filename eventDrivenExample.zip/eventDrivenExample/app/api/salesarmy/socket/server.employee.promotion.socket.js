'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  async = require("async"),
  mongoose = require("mongoose"),
  PromotionHelper = require('../../salesarmy/socket/promotion/server.promotion.helper'),
  Employee = require('../api/models/server.employee.model'),
  Orders = require('../api/models/server.bulk.order.model'),
  Referrals = require('../api/models/server.referrals.model'),
  Designation = require('../api/models/promotion/server.promoter.designation.model'),
  Product = require('../api/models/server.bulk.product.model'),
  Remittance = require('../api/models/server.remittance.model');

module.exports.listen = function (io, socket) {

  socket.on("remittance:add", function (data) {
    Helper.getStore(socket)
      .then(store => {
        var query = {store: store._id, isDeleted: false};
        if (data.remittance._id && !_.isNull(data.remittance._id)) {
          query._id = data.remittance._id;
          delete data.remittance._id;
          Remittance.findOneAndUpdate(query, data.remittance, {new: true})
            .then(event => {
              socket.emit("remittance:add:success", {_id: query._id});
            })
        } else {
          data.remittance = _.extend(data.remittance, query);
          delete data.remittance._id;
          Remittance.create(data.remittance)
            .then(event => {
              socket.emit("remittance:add:success", {_id: event._id});
            })
        }
      });
  });

  socket.on("remittance:delete", function (data) {
    Remittance.findOneAndUpdate({_id: data._id}, {$set: {isDeleted: true}}, {new: true})
      .then(event => {
        socket.emit("remittance:delete:success", {});
      });
  });

  socket.on("sales:order:mlm:create", function (data) {
    var firstOrder = false;
    Helper.getStore(socket)
      .then(store => {
        Employee.findOne({_id: data.order.employee})
          .then(seller => {
            Employee.findOne({'mlm.referralCode': data.order.buyer}).then(buyer => {
              if (!_.isNull(buyer)) {
                data.order.buyer = buyer._id;
                data.order.store = store._id;
                prepareMLMOrderObj(data.order)
                  .then(order => {
                    data.order = order;
                    if (data.order.score <= seller.mlm.credit) {
                      Orders.countDocuments({buyer: buyer._id})
                        .then(totalOrders => {
                          if (totalOrders == 0) {
                            firstOrder = true;
                          }
                          Orders.create(data.order)
                            .then(od => {
                              Referrals.findOneAndUpdate({
                                employee: buyer._id,
                                store: store._id
                              }, {$inc: {score: od.score}}, {new: true})
                                .then(referral => {
                                  var isActive = false;
                                  var setter = {};
                                  if (referral.score >= store.settings.mlm.activateEmployeeAtPoints && buyer.mlm.isActiveEmployee == false) {
                                    isActive = true;
                                    setter = {'mlm.isActiveEmployee': isActive};
                                  }
                                  Employee.findOneAndUpdate({
                                    _id: buyer._id,
                                    isDeleted: false
                                  }, setter, {new: true})
                                    .then(newBuyer => {
                                      fulfillRemittance(data.order, firstOrder, store, referral, newBuyer, buyer)
                                        .then(ref => {
                                          var creditToReduce = 0 - od.score;
                                          console.log("creditToReduce", creditToReduce);
                                          Employee.findOneAndUpdate({_id: seller._id}, {$inc: {'mlm.credit': creditToReduce}}, {new: true})
                                            .then(seller => {
                                              console.log("process complete", seller.mlm);
                                              socket.emit("sales:order:mlm:create:success", {message: "Order placed successfully."})
                                            }).catch(err => {
                                            socket.emit("sales:order:mlm:create:error", {message: "Something went wrong. Please try again."})
                                          });
                                        });
                                    });
                                })
                            })
                        }).catch(err => {
                        socket.emit("sales:order:mlm:create:error", {message: "Something went wrong. Please try again."})
                      })
                    } else {
                      socket.emit("sales:order:mlm:create:error", {message: "You do not have enough credit to process this order."})
                    }
                  });
              } else socket.emit("sales:order:mlm:create:error", {message: "Referrer not found. Please verify the referral code."})
            });
          });
      });
  });

  socket.on("referrals:update", function (data) {
    Referrals.findOneAndUpdate({_id: data._id}, {$set: {score: data.score}}, {new: true})
      .then(event => {
        var query = {$set: {'mlm.credit': data.credit}};
        if (data.credit == 0) query["$pull"] = {roles: 'store'};
        else query["$addToSet"] = {roles: 'store'};
        Employee.findOneAndUpdate({_id: event.employee}, query)
          .then(emp => {
            socket.emit("referrals:update:success", {});
          });
      });
  });

  socket.on("user:update:kyc", function (data) {
    Employee.findOneAndUpdate({_id: data._id}, {$set: {'mlm.kyc': data.kyc}}, {new: true})
      .then(event => {
        Referrals.findOne({employee: event._id})
          .then(ref => {
            socket.emit("user:update:kyc:success", {mlm: event.mlm, score: ref.score});
          });
      });
  });

  socket.on("user:get:kyc", function (data) {
    Employee.findOne({_id: data._id})
      .then(event => {
        Referrals.findOne({employee: event._id})
          .then(ref => {
            socket.emit("user:get:kyc:success", {mlm: event.mlm, score: ref.score});
          });
      });
  });

  socket.on("employee:get:by:referrer", function (data) {
    Helper.getStore(socket)
      .then(store => {
        if (Helper.checkAddonBoolean(store, "MLM_WALLET")) {
          data.code = Buffer.from(data.code, 'base64');
        }
        Employee.findOne({'mlm.referralCode': data.code}).then(emp => {
          if (!_.isNull(emp)) socket.emit("employee:get:by:referrer:success", {
            name: emp.firstName,
            email: emp.email
          });
          else socket.emit("employee:get:by:referrer:error", {message: "Referrer not found. Please verify the referral code."})
        });
      });
  });

  socket.on("employee:register:by:referrer", function (data) {
    Helper.getStore(socket)
      .then(store => {
        data.employee.store = store._id;
        if (_.isString(data.employee.phone)) data.employee.phone = {number: data.employee.phone.trim()};
        var qf = {store: store._id, isDeleted: false};
        qf['$or'] = [];
        qf['$or'].push({'phone.number': data.employee.phone.number});
        if (Helper.checkAddonBoolean(store, "MLM_WALLET")) {
          data.employee.referrerCode = Buffer.from(data.employee.referrerCode, 'base64');
        } else {
          qf['$or'].push({'email': data.employee.email});
        }
        if (data.employee.referrerCode) {
          Employee.findOne(qf)
            .then(em => {
              if (_.isNull(em)) {
                createMLMEmployee(data.employee, store)
                  .then(function (seller) {
                    socket.emit("employee:register:by:referrer:success", {});
                    return true;
                  }).catch(err => {
                  socket.emit("employee:register:by:referrer:error", {message: err && err.message ? err.message : "Something went wrong. Please try again."});
                });
              } else {
                if (Helper.checkAddonBoolean(store, "MLM_WALLET")) {
                  socket.emit("employee:register:by:referrer:error", {message: "User with same mobile number already exists. Please use another mobile number."});
                } else {
                  socket.emit("employee:register:by:referrer:error", {message: "User with same mobile number or email already exists. Please use another mobile number or email."});
                }
              }
            });
        } else {
          socket.emit("employee:register:by:referrer:error", {message: "Please provide a valid Referrer Code to proceed further."});
        }
      });
  });

  function prepareMLMOrderObj(data) {
    return new Promise(function (resolve, reject) {
      data.total = 0;
      data.score = 0;
      async.forEach(data.items, function (listItem, cb) {
        Product.findOne({_id: listItem.item, isDeleted: false})
          .then(pr => {
            data.total += listItem.quantity * pr.price;
            data.score += listItem.quantity * pr.score;
            cb();
          });
      }, function (err, result) {
        if (err) reject(err);
        else resolve(data)
      })
    });
  }

  function addAmountToTopChain(origin, type, levelsToGo, amount, storeId, cb) {
    var options = {
      page: 1,
      limit: parseInt(1),
      populate: [{path: "parent", model: "Sales-Employee", select: "_id mlm"}]
    };
    var qf = {employee: origin, store: storeId, isDeleted: false};
    Referrals.paginate(qf, options)
      .then(referral => {
        if (referral && referral.docs.length > 0) {
          var parent = referral.docs[0].parent;
          if (parent.mlm && parent.mlm.isActiveEmployee) {
            var inc = {};
            if (_.isNumber(amount)) {
              inc[type] = amount;
            } else {
              inc = amount;
            }
            Referrals.findOneAndUpdate({employee: parent._id, store: storeId}, {$inc: inc}, {new: true})
              .then(t => {
                levelsToGo--;
                addAmountToTopChain(parent._id, type, levelsToGo, amount, storeId, cb);
              });
          } else {
            addAmountToTopChain(parent._id, type, levelsToGo, amount, storeId, cb);
          }
        } else {
          cb()
        }
      });
  }

  function processFirstRemittance(remittance, order, store, referral, cb) {
    var amountToAdd = remittance.remittanceAmount;
    Employee.findOne({_id: referral.referrer, store: store._id})
      .then(emp => {
        if (emp.mlm.isActiveEmployee) {
          Referrals.findOneAndUpdate({employee: referral.referrer, store: store._id}, {$inc: {groupScore: amountToAdd}})
            .then(e => {
              cb();
            });
        } else {
          cb();
        }
      });
  }

  function processSecondRemittance(score, remittance, order, store, cb) {
    var amountToAdd = {
      groupScore: remittance.minTransactionAmount,
      groupHiddenScore: score >= remittance.minTransactionAmount ? (score - remittance.minTransactionAmount) : 0
    };
    addAmountToTopChain(order.buyer, 'groupScore', remittance.numberOfPeople, amountToAdd, store._id, cb)
  }

  function processThirdRemittance(remittance, order, store, cb) {
    addAmountToTopChain(order.buyer, 'groupHiddenScore', remittance.numberOfPeople, order.score, store._id, cb)
  }

  function fulfillRemittance(order, firstOrder, store, referral, newBuyer, oldBuyer) {
    return new Promise(function (resolve, reject) {
      var query = {store: store._id, isDeleted: false};
      var allowThirdRemittance = true;
      Remittance.find(query)
        .sort({type: "asc"})
        .then(remittances => {
          async.eachSeries(remittances, function (remittance, cb) {
            if (referral.score >= store.settings.mlm.activateEmployeeAtPoints && oldBuyer.mlm.isActiveEmployee == false && remittance.type == 1) {
              processFirstRemittance(remittance, order, store, referral, function () {
                cb();
              });
            } else if (referral.score >= remittance.minTransactionAmount && referral.secondRemittanceCompleted == false && remittance.type == 2 && newBuyer.mlm.isActiveEmployee) {
              allowThirdRemittance = false;
              processSecondRemittance(referral.score, remittance, order, store, function () {
                referral.secondRemittanceCompleted = true;
                referral.save().then(s => {
                  cb();
                });
              });
            } else if (remittance.type == 3 && newBuyer.mlm.isActiveEmployee && referral.secondRemittanceCompleted && allowThirdRemittance) {
              processThirdRemittance(remittance, order, store, function () {
                cb();
              });
            } else {
              cb();
            }
          }, function (err, result) {
            if (err) reject(err);
            else resolve(true);
          });
        });
    });
  }

  function getAvailableSlotUnder(referrer, store, nextChecks, resolve) {
    if (referrer.mlm.slotsFilled < 5) {
      resolve(referrer);
    } else {
      var matchQuery = [
        {
          $match: {
            parent: mongoose.Types.ObjectId(referrer._id),
            store: mongoose.Types.ObjectId(store._id)
          }
        },
        {
          "$lookup": {
            "from": "sales-employees",
            "localField": "employee",
            "foreignField": "_id",
            "as": "foundEmployee"
          }
        }
      ];
      Referrals.aggregate(matchQuery).then(s => {
        if (s && s.length > 0) {
          nextChecks = nextChecks || [];
          var slotAvailableUnderThisEmployee = null;
          async.forEach(s, function (emp, cb) {
            if (emp.foundEmployee[0].mlm.slotsFilled < 5) slotAvailableUnderThisEmployee = emp.foundEmployee[0];
            nextChecks.push(emp.foundEmployee[0]);
            cb(null, emp.foundEmployee[0]);
          }, function (err, r) {
            if (slotAvailableUnderThisEmployee == null) {
              var nextCheck = nextChecks[0];
              nextChecks.shift();
              getAvailableSlotUnder(nextCheck, store, nextChecks, resolve);
            } else {
              resolve(slotAvailableUnderThisEmployee);
            }
          });
        } else {
          var nextCheck = nextChecks[0];
          nextChecks.shift();
          getAvailableSlotUnder(nextCheck, store, nextChecks, resolve)
        }
        return true;
      }).catch(r => {
        console.log(r);
      });
    }
  }

  function createMLMEmployee(data, store) {
    var password = null;
    data.roles = ['employee', 'mlm'];
    return new Promise(function (resolve, reject) {
      var referrer = null;
      var slotavailableUnder = null;
      var employee = null;
      var getReferrerEmployee = function (cb) {
        Employee.findOne({'mlm.referralCode': data.referrerCode}).then(emp => {
          if (!_.isNull(emp)) {
            referrer = emp;
            cb();
          } else {
            cb({message: "Referrer not found. Please verify the referral code."})
          }
        });
      };

      var getAvailableSlot = function (cb) {
        if (Helper.checkAddonBoolean(store, "MLM_WALLET")) {
          slotavailableUnder = referrer;
          cb();
        } else {
          getAvailableSlotUnder(referrer, store, [], function (slotavailable) {
            slotavailableUnder = slotavailable;
            cb();
          });
        }
      };

      var createEmployee = function (cb) {
        password = data.password;
        delete data.password;
        var seller = new Employee(data);
        if (Helper.checkAddonBoolean(store, "MLM_WALLET")) {
          Designation.findOne({
            store: store._id,
            minimumReference: 0,
            isDeleted: false
          }).then(designation => {
            seller.mlm.designation = seller.mlm.designation || {};
            seller.mlm.designation.name = designation.designation;
            seller.mlm.designation.limit = designation.rewardLimit;
            seller.setPassword(password);
            seller.saveAsync()
              .then(function (data) {
                employee = data;
                cb(null, data);
                return true;
              })
              .catch(function (err) {
                _logger.error(err);
                cb({message: "Something went wrong. Please try again later."});
              });
          });
        } else {
          seller.setPassword(password);
          seller.saveAsync()
            .then(function (data) {
              employee = data;
              cb(null, data);
              return true;
            })
            .catch(function (err) {
              _logger.error(err);
              cb({message: "Something went wrong. Please try again later."});
            });
        }
      };

      var createReferral = function (cb) {
        if (Helper.checkAddonBoolean(store, "MLM_WALLET")) {
          Referrals.create({
            referrer: referrer._id,
            parent: slotavailableUnder._id,
            employee: employee._id,
            store: store._id
          }).then(re => {
            Referrals.findOneAndUpdate({
              _id: re._id,
              isDeleted: false
            }, {$inc: {score: store.settings.mlm.cashbackToSelf}}, {})
              .then(ref => {
                if (store.settings.mlm.cashbackToReferrerOnRegistration > 0) {
                  Referrals.findOneAndUpdate({
                    employee: referrer._id,
                    isDeleted: false
                  }, {$inc: {score: store.settings.mlm.cashbackToReferrerOnRegistration}})
                    .then(r => {
                      Employee.findOneAndUpdate({_id: slotavailableUnder._id}, {$inc: {'mlm.slotsFilled': 1}})
                        .then(emp => {
                        });
                      cb();
                    });
                } else {
                  cb();
                }
              });
          });
        } else {
          Referrals.create({
            referrer: referrer._id,
            parent: slotavailableUnder._id,
            employee: employee._id,
            store: store._id
          }).then(re => {
            Employee.findOneAndUpdate({_id: slotavailableUnder._id}, {$inc: {'mlm.slotsFilled': 1}})
              .then(emp => {
                cb();
              });
          });
        }
      };

      function updateTreeSlotCount(emp, store, resolve) {
        Referrals.aggregate([
          {
            "$graphLookup": {
              "from": "sales-referrals",
              "startWith": "$parent",
              "connectFromField": "parent",
              "connectToField": "employee",
              "as": "ancestors"
            }
          }, {
            "$match":
              {
                "employee": mongoose.Types.ObjectId(emp),
                "store": mongoose.Types.ObjectId(store._id)
              }
          }, {
            "$addFields": {
              "ancestors": {
                "$reverseArray": {
                  "$map": {
                    "input": "$ancestors",
                    "as": "t",
                    "in": {"employee": "$$t.employee"}
                  }
                }
              }
            }
          }
        ]).then(s => {
          if (s && s.length > 0 && s[0].ancestors && s[0].ancestors.length > 0) {
            var ancestors = _.pluck(s[0].ancestors, 'employee');
            resolve(ancestors);
          } else {
            resolve();
          }
        }).catch(e => {
          console.log("error", e);
        });
      }

      var updateTreeCount = function (cb) {
        var employeeId = employee.toObject ? employee.toObject()._id : employee._id;
        updateTreeSlotCount(employeeId, store, function (ancestors) {
          if (ancestors && ancestors.length > 0) {
            Referrals.updateMany({employee: {$in: ancestors}}, {$inc: {'slotsBelow': 1}}, {multi: true})
              .then(e => {
                return true;
              }).catch(err => {
              console.log(err);
            });
          }
        });
        cb();
      };

      var tasks = [getReferrerEmployee, getAvailableSlot, createEmployee, createReferral];
      if (Helper.checkAddonBoolean(store, "MLM_WALLET")) {
        tasks.push(updateTreeCount);
      }

      async.series(tasks, function (e, result) {
        if (e) reject(e);
        else {
          resolve(result);
          if (Helper.checkAddonBoolean(store, "SMS_CONFIG")) {
            PromotionHelper.sendSMS(store, employee.phone.number, 'registration', {
              password: password,
              designation: employee.mlm.designation.name
            });
          }
        }
      })
    });
  };

};