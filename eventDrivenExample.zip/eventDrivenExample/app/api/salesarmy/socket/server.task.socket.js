'use strict';
var TASK = require("../socket/shared/server.socket.events").TASK,
  Helper = require("../../app/api/shared/server.helper.js"),
  Task = require('../api/models/server.task.model'),
  Controller = require('../api/controllers/server.task.controller'),
  TASK_KEYS = require('../api/shared/server.filter.keys').feed;

module.exports.listen = function (io, socket) {

  socket.on(TASK.ADD.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, TASK_KEYS.add)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            var req = {
              body: data.task,
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : TASK_KEYS.view.guest.keys
            };
            data.filters = data.filters || {};
            data.task.store = store._id;
            store.domain = store.domain ? store.domain : store.subdomain;
            Controller.add(req)
              .then(task => {
                socket.emit(TASK.ADD.SUCCESS, task);
              })
              .catch(error => {
                if (error) {
                  _logger.error(error);
                  socket.emit(TASK.ADD.ERROR, "Error occurred while adding task");
                }
              });
          });
      });
  });

  socket.on(TASK.GET_ALL.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.filters = data.filters || {};
            data.filters.store = store._id;
            var req = {
              query: Helper.createQueryString(socket, data.filters)
            };
            Controller.getAll(req)
              .then(function (body) {
                socket.emit(TASK.GET_ALL.SUCCESS, body);
              })
              .catch(function (error) {
                if (error) {
                  _logger.error(error);
                  socket.emit(TASK.GET_ALL.ERROR, "error occurred while getting a list of tasks");
                }
              })
          });
      });
  });

  socket.on(TASK.GET.EVENT, (data) => {
    var req = {
      body: data,
      query: Helper.createQueryString(socket, data.filters)
    };
    Controller.get(req).then(res => {
      if (res == false) {
        socket.emit(TASK.GET.ERROR, "Error occurred while getting a Task with Id: " + data._id);
      } else {
        socket.emit(TASK.GET.SUCCESS, res);
      }
    }).catch(error => {
      if (error) {
        _logger.error(error);
        socket.emit(TASK.GET.ERROR, "Error occurred while getting a Task with Id: " + data._id);
      }
    });
  });

  socket.on(TASK.UPDATE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, TASK_KEYS.update)
      .then(response => {
        var req = {
          body: data.task,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : TASK_KEYS.view.guest.keys
        };
        Controller.update(req)
          .then(task => {
            socket.emit(TASK.UPDATE.SUCCESS, task);
            return false;
          })
          .catch(error => {
            if (error) {
              _logger.error(error);
              socket.emit(TASK.UPDATE.ERROR, "Error occurred while updating Task with ID: " + data.task._id);
            }
          });
      });
  });

  socket.on(TASK.DELETE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, TASK_KEYS.delete)
      .then(response => {
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : TASK_KEYS.view.guest.keys
        };
        Controller.delete(req)
          .then(task => {
            socket.emit(TASK.DELETE.SUCCESS, task);
          }).catch(error => {
          if (error) {
            _logger.error(error);
            socket.emit(TASK.DELETE.ERROR, "Error occurred while deleting task with Id: " + data._id);
          }
        });
      });
  });

  socket.on(TASK.DELETE.MULTIPLE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, TASK_KEYS.delete)
      .then(response => {
        Task.updateAsync({_id: {$in: data.ids}}, {$set: {isDeleted: true}}, {multi: true})
          .then(function () {
            socket.emit(TASK.DELETE.MULTIPLE.SUCCESS, "Customer Deleted Successfully.");
          })
          .catch(function (error) {
            _logger.error(error);
            socket.emit(TASK.DELETE.MULTIPLE.ERROR, "Error occurred while deleting customer ");
          });
      });
  });

  socket.on(TASK.GET.BY_DATE.EVENT, (data, scb) => {
    var req = {
      body: data,
      query: Helper.createQueryString(socket, data.filters)
    };
    Controller.getTasksByDate(req).then(loc => {
      Helper.sendSocketResponse(socket, scb, loc, {event: TASK.GET.BY_DATE.SUCCESS});
    }).catch(error => {
      if (error) {
        _logger.error(error);
        Helper.sendSocketErrorResponse(socket, scb, "Error occurred while getting a task by date: " + data._id, {event: TASK.GET.BY_DATE.BY_EMPLOYEE.ERROR});
      }
    });
  });
};