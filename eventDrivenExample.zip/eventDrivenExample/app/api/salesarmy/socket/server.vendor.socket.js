'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  FileUploader = require("../../app/api/shared/file.uploader"),
  Vendor = require('../api/models/server.employee.company.model'),
  Excel = require('exceljs'),
  async = require('async'),
  Transaction = require('../api/models/promotion/server.credit.transaction.model'),
  Employee = require('../api/models/server.employee.model');

module.exports.listen = function (io, socket) {

  socket.on("sales:vendor:get", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 0 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {createdAt: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true
              };
              var qf = {store: store._id, isDeleted: false};
              if (data.vendorId) {
                qf._id = data.vendorId;
              }
              if (data.filters.searchText && data.filters.searchText.length > 0) {
                qf['$or'] = [];
                qf['$or'].push({'name': {'$regex': data.filters.searchText, '$options': 'i'}});
              }
              Vendor.paginate(qf, options).then(function (documents) {
                socket.emit("sales:vendor:get:success", documents);
              });
            } else {
              socket.emit("sales:vendor:get:error", {message: "Something went wrong. Please try again later."});
            }
          });
      });
  });

  socket.on("sales:vendor:add", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.vendor) {
              FileUploader.uploadMultipleFile(data.vendor.pictures, store, false)
                .then(d => {
                  data.vendor.pictures = d.idList;
                  if (data.vendor._id) {
                    var creditToSet = data.vendor.credit;
                    delete data.vendor.credit;
                    Vendor.findOneAndUpdate({
                      _id: data.vendor._id,
                      store: store._id,
                      isDeleted: false
                    }, data.vendor, {new: true})
                      .then(exp => {
                        Employee.findOneAndUpdate({_id: exp.owner}, {$set: {'mlm.credit': creditToSet}})
                          .then(r => {
                            socket.emit("sales:vendor:add:success", exp);
                          });
                      }).catch(err => {
                      socket.emit("sales:vendor:add:error", {message: "Something went wrong. Please try again later."});
                    });
                  } else {
                    data.vendor.store = store._id;
                    Employee.findOne({store: store._id, 'mlm.referralCode': data.vendor.owner, isDeleted: false})
                      .then(employee => {
                        if (employee && !_.isNull(employee)) {
                          data.vendor.owner = employee._id;
                          Vendor.findOne({owner: employee._id, isDeleted: false})
                            .then(em => {
                              if (em && !_.isNull(em)) {
                                socket.emit("sales:vendor:add:error", {message: "User already has a ID associated with it by '" + em.name + "'"});
                              } else {
                                Vendor.create(data.vendor)
                                  .then(exp => {
                                    socket.emit("sales:vendor:add:success", exp);
                                  }).catch(err => {
                                  socket.emit("sales:vendor:add:error", {message: "Something went wrong. Please try again later."});
                                });
                              }
                            })
                        }
                      });
                  }
                });
            }
          });
      });
  });

  socket.on("sales:vendor:delete", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Vendor.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isDeleted: true}, {new: true})
                .then(exp => {
                  socket.emit("sales:vendor:delete:success", exp);
                });
            } else {
              socket.emit("sales:vendor:delete:error", {message: "Something went wrong. Please try again later."});
            }
          });
      });
  });

  socket.on("sales:vendor:credit", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              var creditToAdd = Number(data.credit);
              Employee.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {$inc: {'mlm.credit': creditToAdd}}, {new: true})
                .then(exp => {
                  Transaction.create({owner: data._id, amount: creditToAdd, type: "debit"})
                    .then(t => {
                      console.log(t);
                    });

                  socket.emit("sales:vendor:credit:success", exp);
                });
            } else {
              socket.emit("sales:vendor:credit:error", {message: "Something went wrong. Please try again later."});
            }
          });
      });
  });

  socket.on("sales:vendor:payment", function (data) {
    if (data._id) {
      var creditToAdd = Number(data.credit);
      Transaction.create({owner: data._id, amount: creditToAdd, type: "credit"})
        .then(t => {
          console.log(t);
        });
      socket.emit("sales:vendor:payment:success", {success: true});
    } else {
      socket.emit("sales:vendor:payment:error", {message: "Something went wrong. Please try again later."});
    }
  });

  socket.on("sales:vendor:ledger", function (data) {
    if (data._id) {
      Transaction.paginate({owner: data._id, isDeleted: false}, {
        limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
        select: {amount: 1, type: 1, createdAt: 1},
        lean: true
      }).then(data => {
        console.log(data);
        var workbook = new Excel.Workbook();
        workbook.creator = 'Me';
        workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
        workbook.modified = new Date();
        var sheet = workbook.addWorksheet('My Sheet');
        sheet.state = 'visible';
        sheet.columns = [
          {header: 'Date', key: 'createdAt'},
          {header: 'Debit', key: 'debit'},
          {header: 'Credit', key: 'credit'},
          {header: 'Balance', key: 'balance'},
        ];
        async.eachSeries(data.docs, function (row, cb) {
          var balance = 0;
          if (row.type == "credit") {
            balance = 0 - row.amount;
            row.credit = row.amount;
            row.debit = 0;
          } else {
            balance = row.amount;
            row.debit = row.amount;
            row.credit = 0;
          }
          var currentIndex = data.docs.indexOf(row);
          if (data.docs.indexOf(row) > 0) {
            balance = data.docs[currentIndex - 1].balance - row.credit + row.debit;
          }
          row.balance = balance;
          sheet.addRow({
            createdAt: _MOMENT(row.createdAt).format("DD-MM-YYYY [at] hh:mm:ss A"),
            debit: row.debit,
            credit: row.credit,
            balance: row.balance
          }).commit();
          cb();
        }, function (err, result) {
          workbook.xlsx.writeBuffer().then(function (data) {
            socket.emit("sales:vendor:ledger:success", data);
          });
        });
      });
    } else {
      socket.emit("sales:vendor:ledger:error", {message: "Something went wrong. Please try again later."});
    }
  });
};