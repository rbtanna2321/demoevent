'use strict';
var QUIZ_DETAILS = require("../socket/shared/server.socket.events").QUIZ_DETAILS,
  Helper = require("../../app/api/shared/server.helper.js"),
  path = require('path'),
  Controller = require('../api/controllers/server.quiz.details.controller'),
  QUIZ_DETAILS_KEYS = require('../api/shared/server.filter.keys').feed;
var mime = require('mime-types');

module.exports.listen = function (io, socket) {

  socket.on(QUIZ_DETAILS.BATCH.ADD.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, QUIZ_DETAILS_KEYS.add)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            var req = {
              body: data.batchDetail,
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : QUIZ_DETAILS_KEYS.view.guest.keys
            };
            data.filters = data.filters || {};
            data.batchDetail.store = store._id;
            store.domain = store.domain ? store.domain : store.subdomain;
            Controller.add(req)
              .then(batchDetail => {
                socket.emit(QUIZ_DETAILS.BATCH.ADD.SUCCESS, batchDetail);
              })
              .catch(error => {
                if (error) {
                  _logger.error(error);
                  socket.emit(QUIZ_DETAILS.BATCH.ADD.ERROR, "Error occurred while adding batch");
                }
              });
          });
      });
  });


  socket.on(QUIZ_DETAILS.BATCH.GET_ALL.EVENT, function (data, scb) {
    Helper.checkEmployeeAccess(socket, data.auth, QUIZ_DETAILS_KEYS.view)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.filters = data.filters || {};
            data.filters.store = store._id;
            var req = {
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : QUIZ_DETAILS_KEYS.view.guest.keys
            };
            Controller.getAll(req)
              .then(function (body) {
                Helper.sendSocketResponse(socket, scb, body, {event: QUIZ_DETAILS.BATCH.GET_ALL.SUCCESS});
              })
              .catch(function (error) {
                if (error) {
                  _logger.error(error);
                  Helper.sendSocketErrorResponse(socket, scb, "Error occurred while getting a list of employees", {event: QUIZ_DETAILS.BATCH.GET_ALL.ERROR});
                }
              })
          });
      });
  });

  socket.on(QUIZ_DETAILS.BATCH.GET.EVENT, (data) => {
    var req = {
      body: data,
      query: Helper.createQueryString(socket, data.filters)
    };
    Controller.get(req).then(res => {
      if (res == false) {
        socket.emit(QUIZ_DETAILS.BATCH.GET.ERROR, "Error occurred while getting a Employee with Id: " + data._id);
      } else {
        socket.emit(QUIZ_DETAILS.BATCH.GET.SUCCESS, res);
      }
    }).catch(error => {
      if (error) {
        _logger.error(error);
        socket.emit(QUIZ_DETAILS.BATCH.GET.ERROR, "Error occurred while getting a Employee with Id: " + data._id);
      }
    });
  });

  socket.on(QUIZ_DETAILS.BATCH.UPDATE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, QUIZ_DETAILS_KEYS.update)
      .then(response => {
        var req = {
          body: data.batchDetail,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : QUIZ_DETAILS_KEYS.view.guest.keys
        };
        Controller.update(req)
          .then(batchDetail => {
            socket.emit(QUIZ_DETAILS.BATCH.UPDATE.SUCCESS, batchDetail);
            return false;
          })
          .catch(error => {
            if (error) {
              _logger.error(error);
              socket.emit(QUIZ_DETAILS.BATCH.UPDATE.ERROR, "Error occurred while updating Employee with ID: " + data.batchDetail._id);
            }
          });
      });
  });

  socket.on(QUIZ_DETAILS.BATCH.DELETE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, QUIZ_DETAILS_KEYS.delete)
      .then(response => {
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : QUIZ_DETAILS_KEYS.view.guest.keys
        };
        Controller.delete(req)
          .then(employee => {
            socket.emit(QUIZ_DETAILS.BATCH.DELETE.SUCCESS, employee);
          }).catch(error => {
          if (error) {
            _logger.error(error);
            socket.emit(QUIZ_DETAILS.BATCH.DELETE.ERROR, "Error occurred while deleting employee with Id: " + data._id);
          }
        });
      });
  });


  socket.on(QUIZ_DETAILS.RESULTS.ADD.EVENT, function (data, scb) {
    Helper.checkEmployeeAccess(socket, data.auth, QUIZ_DETAILS_KEYS.add)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.filters = data.filters || {};
            data.result.store = store._id;
            var req = {
              body: data.result,
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : QUIZ_DETAILS_KEYS.view.guest.keys
            };
            if (data.result.imgBuffer && data.result.imgBuffer.metadata) {
              var fileExt = path.extname(data.result.imgBuffer.metadata.name);
              var fileMime = mime.lookup(fileExt);
              req.body.imgBuffer = `data:${fileMime};base64,` + data.result.imgBuffer.buffer;
            }
            store.domain = store.domain ? store.domain : store.subdomain;
            Controller.addResult(req)
              .then(result => {
                if (result == true) {
                  Helper.sendSocketResponse(socket, scb, result, {event: QUIZ_DETAILS.RESULTS.ADD.SUCCESS});
                } else {
                  Helper.sendSocketErrorResponse(socket, scb, "Error occurred while adding result", {event: QUIZ_DETAILS.RESULTS.ADD.ERROR});
                }
              })
              .catch(error => {
                if (error) {
                  _logger.error(error);
                  Helper.sendSocketErrorResponse(socket, scb, "Error occurred while adding result", {event: QUIZ_DETAILS.RESULTS.ADD.ERROR});
                }
              });
          });
      });
  });

  socket.on(QUIZ_DETAILS.RESULTS.GET_ALL.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, QUIZ_DETAILS_KEYS.view)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.filters = data.filters || {};
            data.filters.store = store._id;
            var req = {
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : QUIZ_DETAILS_KEYS.view.guest.keys
            };
            Controller.getAllResults(req)
              .then(function (body) {
                socket.emit(QUIZ_DETAILS.RESULTS.GET_ALL.SUCCESS, body);
              })
              .catch(function (error) {
                if (error) {
                  _logger.error(error);
                  socket.emit(QUIZ_DETAILS.RESULTS.GET_ALL.ERROR, "error occurred while getting a list of results");
                }
              })
          });
      });
  });

};