'use strict';
var EXPIRY = require("../socket/shared/server.socket.events").EXPIRY_PRODUCTS,
  Helper = require("../../app/api/shared/server.helper.js"),
  IMEI = require('../api/models/server.imei.model'),
  Controller = require('../api/controllers/server.bulk.product.controller'),
  Orders = require('../api/models/server.bulk.order.model'),
  Product = require('../api/models/server.bulk.product.model'),
  async = require("async"),
  XlsxStreamReader = require("xlsx-stream-reader"),
  PRODUCT_KEYS = require('../api/shared/server.filter.keys').feed;

module.exports.listen = function (io, socket) {

  socket.on("sales:product:add", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.product.store = store._id;
            var req = {
              body: data.product,
              query: Helper.createQueryString(socket, data.filters),
            };
            Controller.add(req)
              .then(product => {
                socket.emit("sales:product:add:success", product);
              })
              .catch(error => {
                if (error) {
                  _logger.error(error);
                  socket.emit("sales:product:add:error", "Error occurred while adding product");
                }
              });
          });
      });
  });

  socket.on(EXPIRY.GET_ALL.EVENT, function (data, scb) {
    Helper.getStore(socket)
      .then(store => {
        data.filters = data.filters || {};
        data.filters.store = store._id;
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters)
        };
        Controller.getAll(req)
          .then(function (data) {
            Helper.sendSocketResponse(socket, scb, data, {event: EXPIRY.GET_ALL.SUCCESS});
          })
          .catch(function (error) {
            _logger.error(error);
            Helper.sendSocketErrorResponse(socket, scb, "Error occurred while getting list of products.", {event: EXPIRY.GET_ALL.ERROR});
          });
      });
  });

  socket.on(EXPIRY.GET_ALL.BY_IMEI.EVENT, function (data) {
    Helper.getStore(socket)
      .then(store => {
        IMEI.findOneAsync({imeiNumber: socket.imeiNumber, isDeleted: false})
          .then(function (deviceInfo) {
            if (deviceInfo) {
              data.filters = data.filters || {};
              data.filters.store = store._id;
              var req = {
                body: data,
                query: Helper.createQueryString(socket, data.filters)
              };
              Controller.getAllForIMEI(req)
                .then(function (data) {
                  socket.emit(EXPIRY.GET_ALL.BY_IMEI.SUCCESS, data);
                })
                .catch(function (error) {
                  _logger.error(error);
                  socket.emit(EXPIRY.GET_ALL.BY_IMEI.ERROR, "Error occurred while getting list of poss.");
                });
            } else {
              socket.emit(EXPIRY.GET_ALL.BY_IMEI.ERROR, {status: 404, message: "User not authenticated."});
            }
          })

      });
  });
  /**
   * get single product using _id
   * Event: "product:get"
   * @param product {}
   * @return {object} product
   */
  socket.on(EXPIRY.GET.EVENT, (data, scb) => {
    Helper.getStore(socket)
      .then(store => {
        var req = {_id: data._id, store: store._id};
        if(_.isArray(data._id)){
          req.multiple = true;
        }
        Controller.get(req).then(product => {
          Helper.sendSocketResponse(socket, scb, product, {event: "expiry:get:success"});
        }).catch(error => {
          if (error) {
            _logger.error(error);
            Helper.sendSocketErrorResponse(socket, scb, error, {event: "expiry:get:error"});
          }
        });
      });
  });

  /**
   * update product using _id
   * Event: "product:update"
   * @param product
   * @return {object} product
   */
  socket.on("sales:product:update", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, PRODUCT_KEYS.update)
      .then(response => {
        var req = {
          body: data.product,
          query: Helper.createQueryString(socket, data.filters),
        };
        Controller.update(req)
          .then(product => {
            socket.emit("sales:product:update:success", product);
          })
          .catch(error => {
            if (error) {
              _logger.error(error);
              socket.emit("sales:product:update:error", "Error occurred while updating product with ID: " + data.product._id);
            }
          });
      })
  });

  socket.on(EXPIRY.UPDATE.SALE_COUNT.EVENT, function (data) {
    Helper.getStore(socket)
      .then(store => {
        IMEI.findOneAsync({imeiNumber: socket.imeiNumber, isDeleted: false})
          .then(function (deviceInfo) {
            if (deviceInfo) {
              var req = {
                body: data.product,
                query: Helper.createQueryString(socket, data.filters),
              };
              Controller.updateSalesCount(req)
                .then(product => {
                  socket.emit(EXPIRY.UPDATE.SALE_COUNT.SUCCESS, product);
                })
                .catch(error => {
                  if (error) {
                    _logger.error(error);
                    socket.emit(EXPIRY.UPDATE.SALE_COUNT.ERROR, "Error occurred while updating product with ID: " + data.product._id);
                  }
                });
            } else {
              socket.emit(EXPIRY.GET_ALL.BY_IMEI.ERROR, {status: 404, message: "User not authenticated."});
            }
          });

      })
  });

  /**
   * delete product using _id
   * Event: "product:delete"
   * @param product {}
   */
  socket.on("sales:product:delete", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, PRODUCT_KEYS.delete)
      .then(response => {
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : PRODUCT_KEYS.view.guest.keys
        };
        Controller.delete(req)
          .then(product => {
            socket.emit("sales:product:delete:success", product);
          }).catch(error => {
          if (error) {
            _logger.error(error);
            socket.emit("sales:product:delete:error", "Error occurred while deleting product with Id: " + data._id);
          }
        });
      });
  });
  var stream = require('stream');
  socket.on("sales:product:import", function (data, scb) {
    Helper.checkEmployeeAccess(socket, data.auth, PRODUCT_KEYS.delete)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data && data.buffer && data.buffer.length > 0 && data.metadata && data.metadata.size && ((data.metadata.size / 1024) / 1024) < _CONFIG.MEDIA.MAX_LIMIT) {
              var bufferStream = new stream.PassThrough();
              data.buffer = Buffer.from(data.buffer, 'base64');
              bufferStream.end(data.buffer);
              var workBookReader = new XlsxStreamReader();
              workBookReader.on('error', function (error) {
                socket.emit("sales:product:import:error", {});
              });
              workBookReader.on('worksheet', function (workSheetReader) {
                if (workSheetReader.id > 1) {
                  workSheetReader.skip();
                  return;
                }
                var rows = [];
                var sampleObject = {};
                workSheetReader.on('row', function (row) {
                  if (row.attributes.r == 1) {
                    row.values.forEach(function (rowVal, colNum) {
                      sampleObject[colNum] = {column: rowVal, value: null};
                    });
                  } else {
                    var r = new Product();
                    row.values.forEach(function (rowVal, colNum) {
                      r = r || new Product();
                      switch (sampleObject[colNum].column.toLowerCase()) {
                        case "name" :
                          r.name = rowVal;
                          break;
                        case "sku":
                          r.sku = rowVal;
                          break;
                        case "price":
                          r.price = Number(rowVal);
                          break;
                        case "quantity":
                          r.qty = Number(rowVal);
                          break;
                        case "description":
                          r.description = rowVal;
                          break;
                      }
                      r.store = store._id;
                      r.employee = response.user._id;
                    });
                    rows.push(r);
                  }
                });
                workSheetReader.on('end', function () {
                  var productsToCreate = [];
                  async.each(rows, function (r, cb) {
                    Product.findOne({sku: r.sku, isDeleted: false, store: store._id, employee: response.user._id})
                      .then(pr => {
                        if (pr && pr.sku && !_.isNull(pr)) {
                          pr.name = r.name;
                          pr.price = r.price;
                          pr.qty = r.qty;
                          pr.description = r.description;
                          pr.save();
                        } else {
                          if (r.sku && r.sku.length > 0) {
                            productsToCreate.push(r);
                          }
                        }
                        cb();
                      });
                  }, function (err, result) {
                    if (productsToCreate.length > 0) {
                      Product.create(productsToCreate).then(s => {

                      })
                    }
                  });
                });
                workSheetReader.process();
              });
              bufferStream.pipe(workBookReader);
              socket.emit("sales:product:import:success", {});
            } else {
              socket.emit("sales:product:import:error", {});
            }
          });
      });
  });

  function prepareOrderObj(data) {
    return new Promise(function (resolve, reject) {
      data.total = 0;
      data.score = 0;
      async.forEach(data.items, function (listItem, cb) {
        Product.findOne({_id: listItem.item, isDeleted: false})
          .then(pr => {
            listItem.price = pr.price;
            data.total += listItem.quantity * pr.price;
            cb();
          });
      }, function (err, result) {
        if (err) reject(err);
        else resolve(data)
      })
    });
  }

  socket.on("sales:orders:create", function (data, scb) {
    Helper.getStore(socket)
      .then(store => {
        prepareOrderObj(data.order)
          .then(order => {
            order.store = store._id;
            Orders.create(order)
              .then(d => {
                if (Helper.checkAddonBoolean(store, "SALES_MANAGE_INVENTORY")) {
                  var products = d.items;
                  _.each(products, function (product) {
                    Product.findOneAndUpdate({_id: product.item}, {$inc: {qty: 0 - product.quantity}}, {new: true})
                      .then(r => {
                        //add code to send out of stock alert
                      });
                  })
                }
                Helper.sendSocketResponse(socket, scb, d, {event: "sales:orders:create:success"});
              })
              .catch(() => {
                Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:orders:create:error"});
              });
          })
      });
  });

  socket.on("sales:order:delivered", function (data, scb) {
    Helper.getStore(socket)
      .then(store => {
        var id = data.order._id;
        Orders.findOneAndUpdate({_id: id, store: store._id, isDeleted: false}, {
          $set: {
            items: data.order.items,
            status: data.order.status
          }
        }, {new: true})
          .then(d => {
            Helper.sendSocketResponse(socket, scb, d, {event: "sales:order:delivered:success"});
          })
          .catch(() => {
            Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:order:delivered:error"});
          });
      });
  });

  socket.on("sales:orders:get", function (data, scb) {
    Helper.checkEmployeeAccess(socket, {}, PRODUCT_KEYS.delete)
      .then(response => {
        Helper.getStore(socket).then(function (store) {
          var page = _.isUndefined(data.filters.page) ? data.filters.page : 1;
          var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
          var sort = {createdAt: "desc"};
          if (!_.isUndefined(data.filters.limit)) {
            if (parseInt(data.filters.limit) === -1) {
              limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
            } else {
              if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                limit = data.filters.limit;
              } else {
                limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              }
            }
          }
          var options = {
            page: parseInt(page),
            limit: parseInt(limit),
            sort: sort,
            lean: true,
            populate: [{
              path: 'client',
              select: '_id name'
            }, {
              path: 'items.item',
              select: 'name price description'
            }]
          };
          var qf = {store: store._id, isDeleted: false, employee: data.filters.employee || response.user._id};
          if (data.filters && data.filters.client) qf.client = data.filters.client;
          if (data.filters && data.filters.start && data.filters.end) {
            qf["createdAt"] = {
              $gte: new Date(_MOMENT(data.filters.start).startOf('day')),
              $lte: new Date(_MOMENT(data.filters.end).endOf('day'))
            };
          }
          Orders.paginate(qf, options).then(function (documents) {
            Helper.sendSocketResponse(socket, scb, documents, {event: "sales:orders:get:success"});
          });
        });
      });
  });

  socket.on("employee:orders:availability", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        var query = {
          employee: data.employee || response.user._id,
          createdAt: {
            $gte: _MOMENT(data.start).startOf("day").toISOString(),
            $lte: _MOMENT(data.end).endOf("day").toISOString()
          },
          isDeleted: false
        };
        Orders.paginate(query, {
          lean: true,
          limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
          select : 'createdAt _id'
        }).then(function (res) {
          if (res.docs && res.docs.length > 0) {
            var returnObj = _.uniq(_.map(res.docs, function (d) {
              return _MOMENT(d.createdAt).format("DD/MM/YYYY");
            }));
            Helper.sendSocketResponse(socket, scb, returnObj, {event: "employee:orders:availability:success"});
          } else {
            Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:orders:availability:error"});
          }
        }).catch(function (err) {
          _logger.error(err);
          Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:orders:availability:error"});
        });
      });
  });
};