'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  FileUploader = require("../../app/api/shared/file.uploader"),
  Attendance = require('../api/models/server.attendance.log.model'),
  FullAttendance = require('../api/models/server.attendance.model'),
  Controller = require('../api/controllers/server.employee.controller'),
  EMPLOYEE_KEYS = require('../api/shared/server.filter.keys').feed;

module.exports.listen = function (io, socket) {

  socket.on("attendance:add", function (data, scb) {
    Helper.checkEmployeeAccess(socket, data.auth, EMPLOYEE_KEYS.add)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.filters = data.filters || {};
            data.attendance.store = store._id;
            var req = {
              body: data.attendance,
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : EMPLOYEE_KEYS.view.guest.keys,
              store: store
            };
            if (data.attendance.imgBuffer) {
              FileUploader.uploadFile(data.attendance.imgBuffer, store, false)
                .then(function (file) {
                  req.body.image = file._id;
                  Controller.addAttendance(req)
                    .then(attendance => {
                      Helper.sendSocketResponse(socket, scb, attendance, {event: "attendance:add:success"});
                    })
                    .catch(error => {
                      if (error) {
                        _logger.error(error);
                        Helper.sendSocketErrorResponse(socket, scb, "Error occurred while adding attendance", {event: "attendance:add:error"});
                      }
                    });
                });
            } else {
              Controller.addAttendance(req)
                .then(attendance => {
                  Helper.sendSocketResponse(socket, scb, attendance, {event: "attendance:add:success"});
                })
                .catch(error => {
                  if (error) {
                    _logger.error(error);
                    Helper.sendSocketErrorResponse(socket, scb, "Error occurred while adding attendance", {event: "attendance:add:error"});
                  }
                });
            }
          });
      });
  });

  socket.on("employee:attendance:availability", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        var query = {
          employee: data.employee || response.user._id,
          attendanceDate: {
            $gte: _MOMENT(data.start).startOf("day").toISOString(),
            $lte: _MOMENT(data.end).endOf("day").toISOString()
          },
          isDeleted: false
        };
        Attendance.paginate(query, {
          lean: true,
          limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
          select : 'attendanceDate _id'
        }).then(function (res) {
          if (res.docs && res.docs.length > 0) {
            var returnObj = _.uniq(_.map(res.docs, function (d) {
              return _MOMENT(d.attendanceDate).format("DD/MM/YYYY");
            }));
            Helper.sendSocketResponse(socket, scb, returnObj, {event: "employee:attendance:availability:success"});
          } else {
            Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:attendance:availability:error"});
          }
        }).catch(function (err) {
          _logger.error(err);
          Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:attendance:availability:error"});
        });
      });
  });

  socket.on("employee:attendance:get", function (data, scb) {
    data.filters = data.filters || {};
    var page = _.isUndefined(data.filters.page) ? 1 : data.filters.page;
    var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
    if (!_.isUndefined(data.filters.limit)) {
      if (parseInt(data.filters.limit) === -1) {
        limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      } else {
        if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
          limit = data.filters.limit;
        } else {
          limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        }
      }
    }
    var options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: '-createdAt',
      lean: true,
      select: 'attendanceDate isStart'
    };
    var qf = {
      employee: data.filters.employee || data.employee,
      isDeleted: false
    };
    if (data.filters && data.filters.start && data.filters.end) {
      qf["createdAt"] = {
        $gte: _MOMENT(data.filters.start).startOf('day').toISOString(),
        $lte: _MOMENT(data.filters.end).endOf('day').toISOString()
      };
    }
    Attendance.paginate(qf, options).then(function (result) {
      if (result) {
        Helper.sendSocketResponse(socket, scb, result, {event: "employee:attendance:get:success"});
      } else {
        Helper.sendSocketErrorResponse(socket, scb, {
          err: true,
          message: "No Data found."
        }, {event: "employee:attendance:get:error"});
      }
    }).catch(function (err) {
      _logger.error(err);
      Helper.sendSocketErrorResponse(socket, scb, {
        err: true,
        message: "No Data found."
      }, {event: "employee:attendance:get:error"});
    });
  });

  socket.on("employee:full:attendance:get", function (data, scb) {
    data.filters = data.filters || {};
    var page = _.isUndefined(data.filters.page) ? 1 : data.filters.page;
    var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
    if (!_.isUndefined(data.filters.limit)) {
      if (parseInt(data.filters.limit) === -1) {
        limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      } else {
        if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
          limit = data.filters.limit;
        } else {
          limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        }
      }
    }
    var options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: '-createdAt',
      lean: true,
      select: 'createdAt isStart image',
      populate: {path: "image", model: "PrivateFile", select: '_id metadata fileId url store'}
    };
    var qf = {
      employee: data.employee,
      isDeleted: false
    };
    FullAttendance.paginate(qf, options).then(function (result) {
      if (result) {
        Helper.sendSocketResponse(socket, scb, result, {event: "employee:full:attendance:get:success"});
      } else {
        Helper.sendSocketErrorResponse(socket, scb, {
          err: true,
          message: "No Data found."
        }, {event: "employee:full:attendance:get:error"});
      }
    }).catch(function (err) {
      _logger.error(err);
      Helper.sendSocketErrorResponse(socket, scb, {
        err: true,
        message: "No Data found."
      }, {event: "employee:full:attendance:get:error"});
    });
  });

};