'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  async = require("async"),
  moment = require("moment"),
  mongoose = require("mongoose"),
  path = require("path"),
  fs = require("fs"),
  crypto = require("crypto"),
  uuid = require("node-uuid"),
  Support = require('../api/models/server.support.model'),
  SupportMessages = require('../api/models/server.support.message.model'),
  mime = require('mime-types');
module.exports.listen = function (io, socket) {

  socket.on("sales:tickets:getAll", function (data) {
    Helper.getStore(socket)
      .then(store => {
        if (typeof store !== 'undefined' && store._id) {
          var page = _.isUndefined(data.filters.page) ? 1 : data.filters.page;
          var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
          var sort = {createdAt: "desc"};
          if (!_.isUndefined(data.filters.limit)) {
            if (parseInt(data.filters.limit) === -1) {
              limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
            } else {
              if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                limit = data.filters.limit;
              } else {
                limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              }
            }
          }
          var options = {
            page: parseInt(page),
            limit: parseInt(limit),
            sort: sort,
            lean: true,
            populate: {path: "customer", model: "Customer", select: "_id firstName lastName email mobile"}
          };
          var qf = {store: store._id, isDeleted: false};
          Support.paginate(qf, options).then(function (documents) {
            socket.emit("sales:tickets:getAll:success", documents);
          });
        }
      });
  });

  socket.on("sales:tickets:get", function (data) {
    Helper.getStore(socket)
      .then(store => {
        if (typeof store !== 'undefined' && store._id) {
          var options = {
            page: parseInt(1),
            limit: parseInt(1),
            lean: true,
            populate: [{path: "customer", model: "Customer", select: "_id firstName lastName email mobile"}, "messages.from"]
          };
          var qf = {_id: data._id, store: store._id, isDeleted: false};
          Support.paginate(qf, options).then(function (documents) {
            if (documents.docs && documents.docs.length > 0) socket.emit("sales:tickets:get:success", documents.docs[0]);
          });
        }
      });
  });

  socket.on("sales:ticket:messages:get", function (data) {
    Helper.getStore(socket)
      .then(store => {
        if (typeof store !== 'undefined' && store._id) {
          var options = {
            page: data.page || 1,
            limit: 10,
            lean: true,
            populate: [
              {path : "from", select: "_id firstName lastName email"},
              {path : "pictures", model: "File",select: '_id metadata fileId url store'}
            ]
          };
          var qf = {ticket: data.ticketId, store: store._id, isDeleted: false};
          SupportMessages.paginate(qf, options).then(function (documents) {
            if (documents.docs && documents.docs.length > 0) {
              socket.emit("sales:ticket:messages:get:success", documents);
            }
          });
        }
      });
  });
  socket.on("sales:tickets:reply", function (data, scb) {
    console.log(data)
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.store = store._id;
            SupportMessages.create(data)
              .then(exp => {
                Helper.sendSocketResponse(socket, scb, exp, {event: "sales:tickets:reply:success"});
              }).catch(err => {
              _logger.error(err);
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:tickets:reply:error"});
            });
          });
      });
  });
  socket.on("sales:tickets:mark:as-closed", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Support.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {$set: {markAsClosed: data.markAsClosed}}, {new: true})
                .then(exp => {
                  Helper.sendSocketResponse(socket, scb, exp, {event: "sales:tickets:mark:as-closed:success"});
                });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:tickets:mark:as-closed:error"});
            }
          });
      });
  });
  socket.on("sales:tickets:mark:as-opened", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Support.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {$set: {markAsClosed: data.markAsClosed}}, {new: true})
                .then(exp => {
                  Helper.sendSocketResponse(socket, scb, exp, {event: "sales:tickets:mark:as-opened:success"});
                });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:tickets:mark:as-opened:error"});
            }
          });
      });
  });
  socket.on("sales:tickets:priority", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Support.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {$set: {priority: data.priority}}, {new: true})
                .then(exp => {
                  Helper.sendSocketResponse(socket, scb, exp, {event: "sales:tickets:priority:success"});
                });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:tickets:priority:error"});
            }
          });
      });
  });
};