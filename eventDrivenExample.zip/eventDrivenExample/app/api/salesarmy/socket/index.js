'use strict';
module.exports = function (io, socket) {
  require('./shared/requirer')({
    dirname: _ROOT_DIRECTORY + "/salesarmy/socket/",
    filter: /^server.*socket\.js/,
    resolve: function (Controller) {
      Controller.listen(io, socket);
    }
  });
};