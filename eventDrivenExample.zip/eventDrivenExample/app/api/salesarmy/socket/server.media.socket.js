'use strict';
var Helper = require("../../app/api/shared/server.helper.js");
var File = require("../../app/api/models/server.file.model");
var Folder = require("../../app/api/models/server.folder.model");
var SolrHelper = require("../../app/api/shared/server.solr.search.helper");
var async = require("async");
var SearchController = require('../../app/api/controllers/server.search.controller');

module.exports.listen = function (io, socket) {

  socket.on("media:files:get", function (data, scb) {
    Helper.getStore(socket)
      .then(function (store) {
        data.filters = data.filters || {};
        data.filters.store = data.hasOwnProperty('seo_store') ? data.seo_store : store._id;
        var req = {
          query: Helper.searchString(socket, data.filters)
        };
        Helper.checkEmployeeAccess(socket, {})
          .then(response => {
            if (store.owner._id != response.user._id && store.settings.salesarmy.showMediaAddedByOtherEmployees != true) req.query.uploaderId = response.user._id;
            SearchController.getAllWithPagination(req)
              .then(function (body) {
                if (!_.isUndefined(data.filters.folder)) {
                  var folderFileLink = [];
                  Folder.findOneAsync({_id: data.filters.folder, isDeleted: false})
                    .then(function (result) {
                      folderFileLink.push({
                        name: result.name,
                        id: result._id
                      });
                      if (result.parent !== 'empty') {
                        Folder.populate(result, {
                          path: 'parent',
                          model: 'Folder'
                        }, function (err, parentResult) {
                          folderFileLink.unshift({
                            name: parentResult.parent.name,
                            id: parentResult.parent._id
                          });
                          body.folderFileLink = folderFileLink;
                          scb(body);
                        });
                      } else {
                        body.folderFileLink = folderFileLink;
                        scb(body);
                      }
                    });
                } else {
                  scb(body);
                }
              })
              .catch(function (error) {
                if (error) {
                  _logger.error(error);
                  scb(body);
                }
              });
          });
      });
  });

  socket.on("media:folders:create", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            Folder.createAsync({name: data.name, parent: data.parent, store: store._id})
              .then(function (folder) {
                SolrHelper.addOrUpdateFolder(folder);
                socket.emit("media:folders:create:success", folder);
              }).catch(function (error) {
              _logger.error(error);
            });
          })
      });
  });

  socket.on("media:files:move", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            async.forEach(data.ids, function (id, cb) {
              File.findOneAndUpdate({_id: id, store: store._id}, {folder: data.to}, {new: true})
                .then(s => {
                  SolrHelper.addOrUpdateFile(s);
                  cb();
                });
            });
          })
      });
  });

  socket.on("media:files:rename", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            File.findOneAndUpdate({_id: data.id, store: store._id}, {'metadata.name': data.name}, {new: true})
              .then(s => {
                SolrHelper.addOrUpdateFile(s);
                socket.emit("media:files:rename:success", s);
              }).catch(function (error) {
              _logger.error(error);
              socket.emit("media:files:rename:error", {message: "Something went wrong. Please try again later."});
            });
          })
      });
  });

  socket.on("media:folders:rename", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            Folder.findOneAndUpdate({_id: data.id, store: store._id}, {'name': data.name}, {new: true})
              .then(s => {
                SolrHelper.addOrUpdateFolder(s);
                socket.emit("media:folders:rename:success", s);
              }).catch(function (error) {
              _logger.error(error);
              socket.emit("media:folders:rename:error", {message: "Something went wrong. Please try again later."});
            });
          })
      });
  });

  socket.on("media:folders:delete", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            async.forEach(data.ids, function (id, cb) {
              Folder.findOneAndUpdate({_id: id, store: store._id}, {isDeleted: true}, {new: true})
                .then(s => {
                  SolrHelper.delete(_CONFIG.solr.cores.files, s._id);
                  cb();
                }).catch(function (error) {
                _logger.error(error);
                cb();
              });
            }, function (e) {
              socket.emit("media:folders:delete:success", data.ids);
            });
          })
      });
  });
  socket.on("media:files:delete", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            async.forEach(data.ids, function (id, cb) {
              File.findOneAndUpdate({_id: id, store: store._id}, {isDeleted: true}, {new: true})
                .then(s => {
                  SolrHelper.delete(_CONFIG.solr.cores.files, s._id);
                  cb();
                }).catch(function (error) {
                _logger.error(error);
              });
            }, function (e) {
              socket.emit("media:files:delete:success", data.ids);
            });
          })
      });
  });

};