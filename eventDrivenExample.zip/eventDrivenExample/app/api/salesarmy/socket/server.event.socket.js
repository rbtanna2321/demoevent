'use strict';
var EVENT = require("../socket/shared/server.socket.events").EVENT,
  Helper = require("../../app/api/shared/server.helper.js"),
  Event = require('../api/models/server.event.model'),
  Controller = require('../api/controllers/server.event.controller'),
  EVENT_KEYS = require('../api/shared/server.filter.keys').feed;

module.exports.listen = function (io, socket) {

  socket.on(EVENT.ADD.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, EVENT_KEYS.add)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            var req = {
              body: data.event,
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : EVENT_KEYS.view.guest.keys
            };
            data.filters = data.filters || {};
            data.event.store = store._id;
            store.domain = store.domain ? store.domain : store.subdomain;
            Controller.add(req)
              .then(event => {
                socket.emit(EVENT.ADD.SUCCESS, event);
              })
              .catch(error => {
                if (error) {
                  _logger.error(error);
                  socket.emit(EVENT.ADD.ERROR, "Error occurred while adding event");
                }
              });
          });
      });
  });

  socket.on(EVENT.GET_ALL.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, EVENT_KEYS.view)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.filters = data.filters || {};
            data.filters.store = store._id;
            var req = {
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : EVENT_KEYS.view.guest.keys
            };
            Controller.getAll(req)
              .then(function (body) {
                socket.emit(EVENT.GET_ALL.SUCCESS, body);
              })
              .catch(function (error) {
                if (error) {
                  _logger.error(error);
                  socket.emit(EVENT.GET_ALL.ERROR, "error occurred while getting a list of events");
                }
              })
          });
      });
  });

  socket.on(EVENT.GET.EVENT, (data) => {
    var req = {
      body: data,
      query: Helper.createQueryString(socket, data.filters)
    };
    Controller.get(req).then(res => {
      if (res == false) {
        socket.emit(EVENT.GET.ERROR, "Error occurred while getting a Event with Id: " + data._id);
      } else {
        socket.emit(EVENT.GET.SUCCESS, res);
      }
    }).catch(error => {
      if (error) {
        _logger.error(error);
        socket.emit(EVENT.GET.ERROR, "Error occurred while getting a Event with Id: " + data._id);
      }
    });
  });

  socket.on(EVENT.UPDATE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, EVENT_KEYS.update)
      .then(response => {
        var req = {
          body: data.event,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : EVENT_KEYS.view.guest.keys
        };
        Controller.update(req)
          .then(event => {
            socket.emit(EVENT.UPDATE.SUCCESS, event);
            return false;
          })
          .catch(error => {
            if (error) {
              _logger.error(error);
              socket.emit(EVENT.UPDATE.ERROR, "Error occurred while updating Event with ID: " + data.event._id);
            }
          });
      });
  });

  socket.on(EVENT.DELETE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, EVENT_KEYS.delete)
      .then(response => {
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : EVENT_KEYS.view.guest.keys
        };
        Controller.delete(req)
          .then(event => {
            socket.emit(EVENT.DELETE.SUCCESS, event);
          }).catch(error => {
          if (error) {
            _logger.error(error);
            socket.emit(EVENT.DELETE.ERROR, "Error occurred while deleting event with Id: " + data._id);
          }
        });
      });
  });

  socket.on(EVENT.DELETE.MULTIPLE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, EVENT_KEYS.delete)
      .then(response => {
        Event.updateAsync({_id: {$in: data.ids}}, {$set: {isDeleted: true}}, {multi: true})
          .then(function () {
            socket.emit(EVENT.DELETE.MULTIPLE.SUCCESS, "Customer Deleted Successfully.");
          })
          .catch(function (error) {
            _logger.error(error);
            socket.emit(EVENT.DELETE.MULTIPLE.ERROR, "Error occurred while deleting customer ");
          });
      });
  });

};