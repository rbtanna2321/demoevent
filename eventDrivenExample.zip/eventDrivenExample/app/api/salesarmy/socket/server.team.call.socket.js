var TeamController = require('../api/controllers/server.team.controller'),
  Team = require('../api/models/server.team.model'),
  TeamRelation = require('../api/models/server.team.relation.model'),
  Helper = require('../../app/api/shared/server.helper'),
  Chat = require('../api/models/server.chat.model'),
  ChatMessage = require('../api/models/server.chat.message.model'),
  Employee = require('../api/models/server.employee.model');

module.exports.listen = function (io, socket) {

  socket.on('disconnect', function () {
    for (var channel in socket.channels) {
      part(channel);
    }
    delete _SOCKETS[socket.id];
  });

  socket.on('call-user', function (config) {
    _SOCKET_PENDING_REQUESTS[config.channel] = _SOCKET_PENDING_REQUESTS[config.channel] || [];
    config.socket = socket;
    _SOCKET_PENDING_REQUESTS[config.channel].push(config);
    io.sockets.in(config.channel + ":chat").emit('call-request', config.userdata);
  });

  socket.on('allow-call', function (config) {
    _SOCKET_PENDING_REQUESTS[config.channel] = _SOCKET_PENDING_REQUESTS[config.channel] || [];
    var index = _.findIndex(_SOCKET_PENDING_REQUESTS[config.channel], function (request) {
      return request.userdata._id == config.userdata._id;
    });
    var request = _SOCKET_PENDING_REQUESTS[config.channel][index];
    if (request) {
      var channel = config.channel + ":channel";
      if (!(channel in _SOCKET_CHANNELS)) {
        _SOCKET_CHANNELS[channel] = {};
      }
      for (id in _SOCKET_CHANNELS[channel]) {
        _SOCKET_CHANNELS[channel][id].emit('addPeer-room', {
          'peer_id': request.socket.id,
          'should_create_offer': false
        });
      }
      _SOCKET_CHANNELS[channel][request.socket.id] = request.socket;
      request.socket.emit('addPeer-room', {'peer_id': socket.id, 'should_create_offer': true});
      _SOCKET_PENDING_REQUESTS[config.channel].splice(index, 1);
    }
  });

  socket.on('decline-call', function (config) {
    _SOCKET_PENDING_REQUESTS[config.channel] = _SOCKET_PENDING_REQUESTS[config.channel] || [];
    var index = _.findIndex(_SOCKET_PENDING_REQUESTS[config.channel], function (request) {
      return request.userdata._id == config.userdata._id;
    });
    var request = _SOCKET_PENDING_REQUESTS[config.channel][index];
    if (request) {
      request.socket.emit('call-declined', {'peer_id': config.channel});
      _SOCKET_PENDING_REQUESTS[config.channel].splice(index, 1);
    }
  });

  socket.on('end-call', function (config) {
    var channel = config.channel + ":channel";
    for (id in _SOCKET_CHANNELS[channel]) {
      _SOCKET_CHANNELS[channel][id].emit('call-ended', {'peer_id': socket.id});
      delete _SOCKET_CHANNELS[channel][id];
    }
    delete _SOCKET_PENDING_REQUESTS[config.channel];
  });

  socket.on('disconnect-call', function (config) {
    _SOCKET_PENDING_REQUESTS[config.channel] = _SOCKET_PENDING_REQUESTS[config.channel] || [];
    delete _SOCKET_PENDING_REQUESTS[config.channel];
    io.sockets.in(config.channel + ":chat").emit('disconnect-request', {});

  });

  socket.on('join-room', function (config, scb) {
    if (config) {
      var channel = config.channel + ":channel";
      if (channel in socket.channels) {
        if (scb) scb();
        return;
      }
      _SOCKET_CHANNELS[channel] = {};
      _SOCKET_CHANNELS[channel][socket.id] = socket;
      socket.channels[channel] = channel;
      if (scb) scb();
    }
  });

  function part(channel) {
    delete socket.channels[channel];
    delete _SOCKET_CHANNELS[channel][socket.id];
    for (id in _SOCKET_CHANNELS[channel]) {
      _SOCKET_CHANNELS[channel][id].emit('removePeer', {'peer_id': socket.id});
      socket.emit('removePeer', {'peer_id': id});
    }
  }

  socket.on('part', part);

  socket.on('relayICECandidate-room', function (config) {
    var peer_id = config.peer_id;
    var ice_candidate = config.ice_candidate;
    if (peer_id in _SOCKETS) {
      _SOCKETS[peer_id].emit('iceCandidate-room', {'peer_id': socket.id, 'ice_candidate': ice_candidate});
    }
  });

  socket.on('relaySessionDescription-room', function (config) {
    var peer_id = config.peer_id;
    var session_description = config.session_description;
    if (peer_id in _SOCKETS) {
      _SOCKETS[peer_id].emit('sessionDescription-room', {
        'peer_id': socket.id,
        'session_description': session_description
      });
    }
  });
};