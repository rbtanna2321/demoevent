'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  async = require("async"),
  mongoose = require("mongoose"),
  Employee = require('../api/models/server.employee.model'),
  GPSLog = require('../api/models/server.gps.log.model'),
  MockLog = require('../api/models/server.mock.log.model'),
  WiFiLog = require('../api/models/server.wifi.log.model'),
  History = require('../api/models/server.history.model'),
  EMPLOYEE_KEYS = require('../api/shared/server.filter.keys').feed,
  Notification = require('../../app/api/shared/server.push.notification.helper'),
  Geofence = require('../api/models/server.geofence.model');

module.exports.listen = function (io, socket) {

  socket.on("location:updates", function (data) {
    console.log("updates", data);
    if (_.isUndefined(io.sockets.adapter.rooms[data.employee + ":location"]) || (io.sockets.adapter.rooms[data.employee + ":location"] && io.sockets.adapter.rooms[data.employee + ":location"].length === 0)) {
      socket.emit("location:updates:end", {});
    } else {
      console.log("users in room " + io.sockets.adapter.rooms[data.employee + ":location"].length);
      io.sockets.in(data.employee + ":location").emit("location:updates", data);
    }
    var query = {
      $set: {
        currentLocation: {
          latitude: data.loc[data.loc.length - 1].position.coordinates[0],
          longitude: data.loc[data.loc.length - 1].position.coordinates[1],
          address: data.loc[data.loc.length - 1].address
        },
        battery: data.loc[data.loc.length - 1].battery,
        batteryChargeStatus: data.loc[data.loc.length - 1].batteryChargeStatus,
        lastUpdatedAt: data.loc[data.loc.length - 1].lastUpdatedAt
      }
    };
    if (data.loc[data.loc.length - 1].settings) {
      query.$set.settings = query.$set.settings || {};
      query.$set.settings = data.loc[data.loc.length - 1].settings;
    }
    if (data.loc[data.loc.length - 1].lastUpdatedAt) {
      query['$set'].lastUpdatedAt = data.loc[data.loc.length - 1].lastUpdatedAt;
      query['$set'].lastActiveAt = data.loc[data.loc.length - 1].lastUpdatedAt;
    }
    Employee.findOneAndUpdateAsync({_id: data.employee}, query)
      .then(function (employee) {
      });
  });

  socket.on("location:updates:sync", function (data, scb) {
    Helper.checkEmployeeAccess(socket, data.auth, EMPLOYEE_KEYS.view)
      .then(response => {
        if (data && data.notification && data.notification.to) {
          if (!_.isUndefined(io.sockets.adapter.rooms[data.notification.to + ":service"]) || (io.sockets.adapter.rooms[data.notification.to + ":service"] && io.sockets.adapter.rooms[data.notification.to + ":service"].length === 1)) {
            io.sockets.in(data.notification.to + ":service").emit("location:updates:start", {});
          } else if (_.isUndefined(io.sockets.adapter.rooms[data.notification.to + ":location"]) || (io.sockets.adapter.rooms[data.notification.to + ":location"] && io.sockets.adapter.rooms[data.notification.to + ":location"].length === 0)) {
            data.notification.type = "synclocation";
            Notification.send(data);
          }
          socket.join(data.notification.to + ":location");
          Helper.sendSocketResponse(socket, scb, {}, {
            event: "location:updates:sync:success"
          })
        } else {
          Helper.sendSocketErrorResponse(socket, scb, {error: 404}, {event: "location:updates:sync:error"})
        }
      });
  });

  socket.on("location:updates:end", function (data) {
    socket.leave(data.employee + ":location");
  });

  socket.on("employee:history:update", function (data, scb) {
    console.log("history update", data);
    Helper.checkEmployeeAccess(socket, {}, EMPLOYEE_KEYS.update)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            var employeeId = response.user._id;
            var employeeTeams = data.teams || data.team || [];
            if (data.multiLoc && data.multiLoc.length > 0) {
              var locationItemToConsider = data.multiLoc[data.multiLoc.length - 1];
              var query = {
                $set: {
                  currentLocation: {
                    latitude: locationItemToConsider.loc[locationItemToConsider.loc.length - 1].position.coordinates[0],
                    longitude: locationItemToConsider.loc[locationItemToConsider.loc.length - 1].position.coordinates[1],
                    address: locationItemToConsider.loc[locationItemToConsider.loc.length - 1].address
                  },
                  battery: locationItemToConsider.loc[locationItemToConsider.loc.length - 1].battery,
                  batteryChargeStatus: locationItemToConsider.loc[locationItemToConsider.loc.length - 1].batteryChargeStatus,
                  lastUpdatedAt: locationItemToConsider.loc[locationItemToConsider.loc.length - 1].lastUpdatedAt,
                }
              };
              if (locationItemToConsider.loc[locationItemToConsider.loc.length - 1].settings) {
                query.$set.settings = query.$set.settings || {};
                query.$set.settings = locationItemToConsider.loc[locationItemToConsider.loc.length - 1].settings;
              }
              if (locationItemToConsider.loc[locationItemToConsider.loc.length - 1].lastUpdatedAt) {
                query['$set'].lastUpdatedAt = locationItemToConsider.loc[locationItemToConsider.loc.length - 1].lastUpdatedAt;
                query['$set'].lastActiveAt = locationItemToConsider.loc[locationItemToConsider.loc.length - 1].lastUpdatedAt;
              }
              Employee.findOneAndUpdateAsync({_id: employeeId}, query, {new: true})
                .then(function (employee) {
                  if (!_.isNull(employee)) {
                    var tasks = [];
                    async.eachSeries(data.multiLoc, function (mainLocationItem, callback) {
                      var task = function (cb) {
                        if (mainLocationItem._id) {
                          History.findOneAndUpdate({
                            employee: employeeId,
                            _id: mainLocationItem._id
                          }, {
                            $inc: {distanceTravelled: mainLocationItem.distanceTravelled},
                            $push: {loc: {$each: mainLocationItem.loc}}
                          }, {new: true}).then(s => {
                            cb(null, s);
                          });
                        } else {
                          checkForGeofence(mainLocationItem.loc, store)
                            .then(loc => {
                              History.create({
                                employee: employeeId,
                                loc: loc,
                                isTrip: mainLocationItem.isTrip,
                                distanceTravelled: mainLocationItem.distanceTravelled,
                                nearestClient: mainLocationItem.nearestClient,
                                inTime: mainLocationItem.loc[mainLocationItem.loc.length - 1].inTime,
                                outTime: mainLocationItem.loc[mainLocationItem.loc.length - 1].outTime,
                                team: employeeTeams,
                                day: _MOMENT(mainLocationItem.loc[0].inTime).format("D"),
                                month: _MOMENT(mainLocationItem.loc[0].inTime).format("M"),
                                year: _MOMENT(mainLocationItem.loc[0].inTime).format("YYYY")
                              }).then(s => {
                                cb(null, s);
                              });
                            });
                        }
                      };
                      tasks.push(task);
                      callback();
                    }, function () {
                      async.parallel(tasks, function (err, result) {
                        var lastTrip = result[result.length - 1];
                        var ob = {
                          _id: lastTrip._id,
                          isTrip: lastTrip.isTrip,
                          loc: [lastTrip.loc[lastTrip.loc.length - 1]]
                        };
                        Helper.sendSocketResponse(socket, scb, ob, {event: "employee:history:update:success"});
                      });
                    });
                  }
                });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {status: 404}, {event: "employee:history:update:error"});
            }
          });
      }).catch(er=>{
        console.log(er);
    });
  });

  socket.on("employee:history:availability", function (data, scb) {
    var query = {
      employee: data.employee,
      "createdAt": {$gt: _MOMENT().subtract(_CONFIG.SALESARMY.HISTORY.LIMIT, 'M').startOf('day')}
    };
    History.findAsync(query, {
      employee: 0,
      createdAt: 0,
      updatedAt: 0,
      __v: 0,
      loc: 0,
      inTime: 0,
      outTime: 0,
      distanceTravelled: 0,
      team: 0,
      isTrip: 0,
      _id: 0
    }).then(function (res) {
      if (res && res.length > 0) {
        var returnObj = _.uniq(_.map(res, function (d) {
          return d.day + "/" + d.month + "/" + d.year;
        }));
        Helper.sendSocketResponse(socket, scb, returnObj, {event: "employee:history:availability:success"});
      } else {
        Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:history:availability:error"});
      }
    }).catch(function (err) {
      _logger.error(err);
      Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:history:availability:error"});
    });
  });

  socket.on("employee:history:get", function (data, scb) {
    Helper.getStore(socket)
      .then(store => {
        data.filters = data.filters || {};
        var page = _.isUndefined(data.filters.page) ? 1 : data.filters.page;
        var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        if (!_.isUndefined(data.filters.limit)) {
          if (parseInt(data.filters.limit) === -1) {
            limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
          } else {
            if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
              limit = data.filters.limit;
            } else {
              limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
            }
          }
        }
        var options = {
          page: parseInt(page),
          limit: parseInt(limit),
          sort: '-inTime',
          lean: true,
          select: '-employee -__v -day -month -year -createdAt -updatedAt -team'
        };
        if (Helper.checkAddonBoolean(store, "SALES_CUSTOM_PLACES")) {
          options.populate = options.populate || [];
          options.populate.push({
            path: "loc.fence",
            model: "Sales-Geofence",
            select: "_id name"
          })
        }
        var qf = {
          employee: data.employee,
          day: data.day,
          month: data.month,
          year: data.year
        };
        History.paginate(qf, options).then(function (result) {
          if (result) {
            Helper.sendSocketResponse(socket, scb, result, {
              event: "employee:history:get:success",
              forceCallback: true
            });
          } else {
            Helper.sendSocketErrorResponse(socket, scb, {
              err: true,
              message: "No Data found."
            }, {event: "employee:history:get:error", forceCallback: true});
          }
        }).catch(function (err) {
          _logger.error(err);
          Helper.sendSocketErrorResponse(socket, scb, {
            err: true,
            message: "No Data found."
          }, {event: "employee:history:get:error", forceCallback: true});
        });
      });
  });

  socket.on("employee:gps:set", function (data) {
    Helper.getStore(socket)
      .then(store => {
        Employee.findOne({_id: data.employee})
          .then(em => {
            if (em && !_.isNull(em)) {
              em.settings = em.settings || {};
              if (em.settings.gps != data.gps) {
                em.settings.gps = data.gps;
                if (Helper.checkAddonBoolean(store, "SALES_NOTIFICATION")) {
                  Notification.sendToManagersAndLeader(data.employee, "text", {
                    title: "GPS Alert",
                    subtitle: `${em.firstName} ${em.lastName} has turned GPS ${data.gps ? "ON" : "OFF"} on ${em.gender ? (em.gender == "male" ? "his" : "her") : "their"} device.`
                  });
                }
                em.save()
                  .then(r => {
                  })
              }
            } else {
              // socket.emit("employee:gps:set:error", {status: 404, message: "Employee does not exist. Please log out."});
            }
          });
      });
  });


  socket.on("sales:wifi:log:update", function (data, scb) {
    Helper.getStore(socket)
      .then(store => {
        var obj = {store: store._id};
        data = _.extend(data, obj);
        WiFiLog.create(obj).then(created => {
        });
      });
  });

  socket.on("sales:gps:log:update", function (data, scb) {
    Helper.getStore(socket)
      .then(store => {
        var obj = {store: store._id};
        data = _.extend(data, obj);
        GPSLog.create(obj).then(created => {
        });
      });
  });

  socket.on("sales:mock:log:update", function (data, scb) {
    Helper.getStore(socket)
      .then(store => {
        var obj = {store: store._id};
        data = _.extend(data, obj);
        MockLog.create(obj).then(created => {
        });
      });
  });

  socket.on("employee:wifi:set", function (data) {
    Helper.getStore(socket)
      .then(store => {
        Employee.findOne({_id: data.employee})
          .then(em => {
            if (em && !_.isNull(em)) {
              em.settings = em.settings || {};
              if (em.settings.wifi != data.wifi) {
                em.settings.wifi = data.wifi;
                // if (Helper.checkAddonBoolean(store, "SALES_NOTIFICATION")) {
                // Notification.sendToManagersAndLeader(data.employee, "text", {
                //   title: "WiFi Alert",
                //   subtitle: em.firstName + " " + em.lastName + " has turned their WiFi " + (data.gps ? "ON" : "OFF")
                // });
                // }
                em.save()
                  .then(r => {
                  })
              }
            } else {
              // socket.emit("employee:wifi:set:error", {status: 404, message: "Employee does not exist. Please log out."});
            }
          });
      });
  });

  socket.on("employee:history:out", function (data) {
    Employee.findOneAsync({_id: data.empId})
      .then(function (doc) {
        if (!_.isNull(doc)) {
          async.each(data.updateId, function (itemId, cb) {
            var obj = {employee: data.empId, _id: itemId};
            History.update(obj, {$set: {outTime: data.outTime}})
              .then(function () {
                cb();
              }).catch(err => {
              socket.emit("employee:history:out:error", {
                status: 404,
                message: "Employee does not exist. Please log out."
              });
            });
          }, function (err, result) {
            socket.emit("employee:history:out:success", {});
          })
        } else {
          socket.emit("employee:history:out:error", {status: 404, message: "Employee does not exist. Please log out."});
        }
      });
  });

  function checkForGeofence(location, store) {
    return new Promise((resolve, reject) => {
      if (Helper.checkAddonBoolean(store, "SALES_CUSTOM_PLACES")) {
        if (location.length == 1) {
          Geofence.aggregate([
            {
              "$geoNear": {
                "near": {
                  "type": "Point",
                  "coordinates": [location[0].position.coordinates[0], location[0].position.coordinates[1]]
                },
                "distanceField": "distance",
                "query": {store: mongoose.Types.ObjectId(store._id), isDeleted: false}
              }
            },
            {
              "$redact": {
                "$cond": {
                  "if": {"$gt": ["$distance", "$radius"]},
                  "then": "$$PRUNE",
                  "else": "$$KEEP"
                }
              }
            },
            {
              $limit: 1
            }
          ]).then(d => {
            if (d && d.length > 0) {
              location[0].fence = d[0]._id;
              resolve(location);
            } else {
              resolve(location);
            }
          });
        } else {
          resolve(location)
        }
      } else {
        resolve(location);
      }
    });
  }

};