'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  Invoice = require('../api/models/server.invoice.model'),
  Email = require("../../app/api/shared/server.email.helper"),
  smsService = require('../../app/api/shared/server.sms.helper'),
  PaymentLink = require('../../app/api/models/server.paymentlinks.model');

module.exports.listen = function (io, socket) {

  socket.on("sales:invoice:get", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 0 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {createdAt: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true
              };
              var qf = {store: store._id, isDeleted: false};
              if (data.invoiceId) {
                qf._id = data.invoiceId;
              }
              if (data.filters.searchText && data.filters.searchText.length > 0) {
                qf['$or'] = [];
                qf['$or'].push({'name': {'$regex': data.filters.searchText, '$options': 'i'}});
              }
              Invoice.paginate(qf, options).then(function (documents) {
                Helper.sendSocketResponse(socket, scb, documents, {event: "sales:invoice:get:success"});
              });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:invoice:get:error"});
            }
          });
      });
  });

  socket.on("sales:invoice:add", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            console.log(data.invoice);
            if (data.invoice) {
              if (data.invoice._id) {
                Invoice.findOneAndUpdate({
                  _id: data.invoice._id,
                  store: store._id,
                  isDeleted: false
                }, data.invoice, {new: true})
                  .then(exp => {
                    Helper.sendSocketResponse(socket, scb, exp, {event: "sales:invoice:add:success"});
                  });
              } else {
                data.invoice.store = store._id;
                data.invoice.employee = response.user._id;
                Invoice.create(data.invoice)
                  .then(exp => {
                    Helper.sendSocketResponse(socket, scb, exp, {event: "sales:invoice:add:success"});
                  }).catch(err => {
                  _logger.error(err);
                  Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:invoice:add:error"});
                });
              }
            }
          });
      });
  });


  socket.on("sales:invoice:send:payment:link", function (data, scb) {
    console.log(data);
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.invoice) {
              if (data.invoice._id) {
                Invoice.paginate({
                  _id: data.invoice._id,
                  store: store._id,
                  isDeleted: false
                }, {
                  lean: true, populate: [{
                    path: "client", model: "Sales-Distributor", select: "name email mobile"
                  }]
                })
                  .then(exp => {
                    if (exp && exp.docs.length > 0) {
                      var document = exp.docs[0];
                      PaymentLink.create({
                        name: document.client.name,
                        orderId: document.invoiceNumber,
                        mobile: document.client.mobile,
                        amount: document.total,
                        email: document.client.email,
                        description: "Payment for " + document.invoiceNumber,
                        paymentOptions: {
                          wallet: true,
                          upi: true,
                          card: true,
                          netBanking: true
                        },
                        store: store._id
                      }).then(link => {
                        Invoice.findOneAndUpdate({_id: document._id}, {$set: {link: link._id}})
                          .then(e => {
                            Helper.sendSocketResponse(socket, scb, exp, {event: "sales:invoice:send:payment:link:success"});
                          });
                        var message = store.name + " has requested a payment of ₹" + link.amount + " for you purchase at store. Please click on the link below to pay now. " + (store.domain || store.subdomain)  + "/payment/" + link.link;
                      var body = {};
                        body.text = message;
                        Email.send(null, null, link.email, 'Payment to be made to ' + store.name, body)
                          .then(function () {
                          }).catch(function () {
                        });
                        smsService.sendSms({number: link.mobile, text: message});
                      });
                    }
                  });
              }
            }
          });
      });
  });

  socket.on("sales:invoice:resend:payment:link", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.invoice) {
              if (data.invoice._id) {
                Invoice.paginate({
                  _id: data.invoice._id,
                  store: store._id,
                  isDeleted: false
                }, {
                  lean: true, populate: [{
                    path: "link", model: "paymentLinks", select: "amount link mobile email _id"
                  }]
                })
                  .then(exp => {
                    if (exp && exp.docs.length > 0) {
                      var document = exp.docs[0];
                      var link = document.link;
                      Helper.sendSocketResponse(socket, scb, exp, {event: "sales:invoice:resend:payment:link:success"});
                      var message = store.name + " has requested a payment of ₹" + link.amount + " for you purchase at store. Please click on the link below to pay now. " + (store.domain || store.subdomain) + "/payment/" + link.link;
                      var body = {};
                      body.text = message;
                      Email.send(null, null, link.email, 'Payment to be made to ' + store.name, body)
                        .then(function () {
                        }).catch(function () {
                      });
                      smsService.sendSms({number: link.mobile, text: message});
                    }
                  });
              }
            }
          });
      });
  });

  socket.on("sales:invoice:delete", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Invoice.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isDeleted: true}, {new: true})
                .then(exp => {
                  Helper.sendSocketResponse(socket, scb, exp, {event: "sales:invoice:delete:success"});
                });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:invoice:delete:error"});
            }
          });
      });
  });
};