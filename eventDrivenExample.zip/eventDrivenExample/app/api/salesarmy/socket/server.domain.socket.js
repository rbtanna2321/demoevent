'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  ejs = require("ejs"),
  path = require("path"),
  Domain = require("../../app/api/models/server.domain.model");

module.exports.listen = function (io, socket) {

  socket.on("sales:domain:record:add", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.record) {
              Domain.findOne({_id: data.domain, isDeleted: false, store: store._id})
                .then(dom => {
                  if (dom && !_.isNull(dom)) {
                    var recordType = data.record.type;
                    switch (recordType) {
                      case "MX":
                        data.record.data = data.record.data[data.record.data.length - 1] == "." ? data.record.data : (data.record.data + ".");
                        break;
                    }
                    console.log(data);
                    _DIGITALOCEAN.domains.createRecord(dom.name, data.record)
                      .then(res => {
                        console.log(res);
                        if (res) {
                          ejs.renderFile(path.join(_SERVER_ROOT, `/public/salesarmy/views/domains/listing-item.ejs`), {
                            domainName: dom.name, records: [{
                              id: res.id,
                              data: res.data,
                              name: res.name,
                              ttl: res.ttl,
                              type: recordType,
                              priority: res.priority
                            }]
                          }, function (err, result) {
                            socket.emit("sales:domain:record:add:success", result);
                          });
                        } else {
                          socket.emit("sales:domain:record:add:error", {message: "Something went wrong. Please try again later."});
                        }
                      }).catch(err => {
                      if (err) {
                        console.log(err);
                        socket.emit("sales:domain:record:add:error", {message: err.message});
                      }
                    });
                  } else {
                    socket.emit("sales:domain:record:add:error", {message: "Something went wrong. Please try again later."});
                  }
                });
            } else {
              socket.emit("sales:domain:record:add:error", {message: "Something went wrong. Please try again later."});
            }
          });
      });
  });

  socket.on("sales:domain:record:update", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.record && data.record.id) {
              Domain.findOne({_id: data.domain, isDeleted: false, store: store._id})
                .then(dom => {
                  if (dom && !_.isNull(dom)) {
                    if (data.record) {
                      var recordId = data.record.id;
                      delete data.record.id;
                      var recordType = data.record.type;
                      delete data.record.type;
                      switch (recordType) {
                        case "MX":
                          data.record.data = data.record.data[data.record.data.length - 1] == "." ? data.record.data : (data.record.data + ".");
                          break;
                      }
                      _DIGITALOCEAN.domains.updateRecord(dom.name, recordId, data.record)
                        .then(res => {
                          if (res) {
                            socket.emit("sales:domain:record:update:success", {
                              data: res.data,
                              ttl: res.ttl,
                              priority: res.priority
                            });
                          } else {
                            socket.emit("sales:domain:record:update:error", {message: "Something went wrong. Please try again later."});
                          }
                        }).catch(err => {
                        if (err) {
                          console.log(err);
                          socket.emit("sales:domain:record:update:error", {message: "Something went wrong. Please try again later."});
                        }
                      });
                    }
                  } else {
                    socket.emit("sales:domain:record:update:error", {message: "Something went wrong. Please try again later."});
                  }
                });
            }
          });
      });
  });

  socket.on("sales:domain:record:delete", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.record && data.record.id) {
              Domain.findOne({_id: data.domain, isDeleted: false, store: store._id})
                .then(dom => {
                  if (dom && !_.isNull(dom)) {
                    if (data.record) {
                      var recordId = data.record.id;
                      _DIGITALOCEAN.domains.deleteRecord(dom.name, recordId)
                        .then(res => {
                          if (res) {
                            socket.emit("sales:domain:record:delete:success", {success: true});
                          } else {
                            socket.emit("sales:domain:record:delete:error", {message: "Something went wrong. Please try again later."});
                          }
                        }).catch(err => {
                        if (err) {
                          console.log(err);
                          socket.emit("sales:domain:record:delete:error", {message: "Something went wrong. Please try again later."});
                        }
                      });
                    }
                  } else {
                    socket.emit("sales:domain:record:delete:error", {message: "Something went wrong. Please try again later."});
                  }
                });
            }
          });
      });
  });
};