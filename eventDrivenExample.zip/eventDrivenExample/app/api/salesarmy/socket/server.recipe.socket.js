'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  Recipe = require('../api/models/server.recipes.model');

module.exports.listen = function (io, socket) {

  socket.on("sales:recipe:get", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 0 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {createdAt: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true
              };
              var qf = {store: store._id, isDeleted: false};
              if (data.recipeId) {
                qf._id = data.recipeId;
              }
              if (data.filters.searchText && data.filters.searchText.length > 0) {
                qf['$or'] = [];
                qf['$or'].push({'name': {'$regex': data.filters.searchText, '$options': 'i'}});
              }
              Recipe.paginate(qf, options).then(function (documents) {
                Helper.sendSocketResponse(socket, scb, documents, {event: "sales:recipe:get:success"});
              });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:recipe:get:error"});
            }
          });
      });
  });

  socket.on("sales:recipe:add", function (data, scb) {
    console.log(data)
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.recipe) {
              if (data.recipe._id) {
                Recipe.findOneAndUpdate({
                  _id: data.recipe._id,
                  store: store._id,
                  isDeleted: false
                }, data.recipe, {new: true})
                  .then(exp => {
                    Helper.sendSocketResponse(socket, scb, exp, {event: "sales:recipe:add:success"});
                  });
              } else {
                data.recipe.store = store._id;
                Recipe.create(data.recipe)
                  .then(exp => {
                    Helper.sendSocketResponse(socket, scb, exp, {event: "sales:recipe:add:success"});
                  }).catch(err => {
                  _logger.error(err);
                  Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:recipe:add:error"});
                });
              }
            }
          });
      });
  });

  socket.on("sales:recipe:delete", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Recipe.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isDeleted: true}, {new: true})
                .then(exp => {
                  Helper.sendSocketResponse(socket, scb, exp, {event: "sales:recipe:delete:success"});
                });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:recipe:delete:error"});
            }
          });
      });
  });
};