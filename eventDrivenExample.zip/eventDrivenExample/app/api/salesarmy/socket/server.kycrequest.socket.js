'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  FileUploader = require("../../app/api/shared/file.uploader"),
  KYCRequest = require('../api/models/promotion/server.kyc.requests.model'),
  Employee = require('../api/models/server.employee.model');

module.exports.listen = function (io, socket) {

  socket.on("employee:kyc:upload", function (data) {
    if (data && ['bank', 'pan', 'aadhar'].indexOf(data.fileType) > -1) {
      Helper.getAccessTokenPromised(socket, {})
        .then(response => {
          Helper.getStore(socket)
            .then(store => {
              FileUploader.uploadFile(data.file, store, false)
                .then(file => {
                  Employee.findOne({_id: response.user._id, store: store._id, isDeleted: false})
                    .then(emp => {
                      var index = _.findIndex(emp.mlm.kyc.media, function (m) {
                        return m.fileType == data.fileType;
                      });
                      if (index > -1) {
                        emp.mlm.kyc.media[index].file = file._id;
                        emp.mlm.kyc.media[index].isApproved = false;
                      } else {
                        emp.mlm.kyc.media.push({file: file._id, fileType: data.fileType});
                      }
                      KYCRequest.create({
                        employee: response.user._id,
                        file: file._id,
                        store: store._id,
                        fileType: data.fileType
                      }).then(r => {
                        emp.save().then(e => {
                          socket.emit("employee:kyc:upload:success", {success: true});
                        });
                      });
                    });
                })
            });
        });
    } else {
      socket.emit("employee:kyc:upload:error", {message: "Something went wrong. Please try again later."});
    }
  });

  socket.on("kycrequest:approve", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              KYCRequest.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isPending: false, isApproved: true}, {new: true})
                .then(exp => {
                  var options = {
                    limit: 1,
                    select: '-password -salt -createdAt -updatedAt -__v -username -pwdRecoveryId -invitationId -isDeleted -chatAlert -devices -addresses -notificationHistories -promotionalNotifications -roles',
                    lean: true,
                    populate: {
                      path: 'mlm.kyc.media.file',
                      model: 'PrivateFile',
                      select: '_id metadata fileId url store'
                    }
                  };
                  var qf = {_id: exp.employee, store: store._id, isDeleted: false};
                  Employee.paginate(qf, options)
                    .then(emp => {
                      if (emp && emp.docs && emp.docs.length > 0) {
                        emp = emp.docs[0];
                        var index = _.findIndex(emp.mlm.kyc.media, function (m) {
                          return m.fileType == exp.fileType && (m.file._id + "") == (exp.file + "");
                        });
                        if (index > -1) {
                          var setter = {};
                          setter['mlm.kyc.media.' + index + '.isApproved'] = true;
                          Employee.findOneAndUpdate({_id: emp._id}, {$set: setter})
                            .then(e => {
                              socket.emit("kycrequest:approve:success", {success: true});
                            });
                        } else {
                          socket.emit("kycrequest:approve:error", {message: "Something went wrong. Please try again later."});
                        }
                      } else {
                        socket.emit("kycrequest:approve:error", {message: "Something went wrong. Please try again later."});
                      }
                    });
                });
            } else {
              socket.emit("kycrequest:approve:error", {message: "Something went wrong. Please try again later."});
            }
          });
      });
  });

  socket.on("kycrequest:disapprove", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              KYCRequest.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isPending: false, isApproved: false}, {new: true})
                .then(exp => {
                  var options = {
                    limit: 1,
                    select: '-password -salt -createdAt -updatedAt -__v -username -pwdRecoveryId -invitationId -isDeleted -chatAlert -devices -addresses -notificationHistories -promotionalNotifications -roles',
                    lean: true,
                    populate: {
                      path: 'mlm.kyc.media.file',
                      model: 'PrivateFile',
                      select: '_id metadata fileId url store'
                    }
                  };
                  var qf = {_id: exp.employee, store: store._id, isDeleted: false};
                  Employee.paginate(qf, options)
                    .then(emp => {
                      if (emp && emp.docs && emp.docs.length > 0) {
                        emp = emp.docs[0];
                        var index = _.findIndex(emp.mlm.kyc.media, function (m) {
                          return m.fileType == exp.fileType && (m.file._id + "") == (exp.file + "");
                        });
                        if (index > -1) {
                          var setter = {};
                          setter['mlm.kyc.media.' + index + '.isApproved'] = false;
                          Employee.findOneAndUpdate({_id: emp._id}, {$set: setter})
                            .then(e => {
                              socket.emit("kycrequest:disapprove:success", {success: true});
                            });
                          FileUploader.deleteFiles([emp.mlm.kyc.media[index].file], store)
                        } else {
                          socket.emit("kycrequest:disapprove:error", {message: "Something went wrong. Please try again later."});
                        }
                      } else {
                        socket.emit("kycrequest:disapprove:error", {message: "Something went wrong. Please try again later."});
                      }
                    });
                });
            } else {
              socket.emit("kycrequest:disapprove:error", {message: "Something went wrong. Please try again later."});
            }
          });
      });
  });
};