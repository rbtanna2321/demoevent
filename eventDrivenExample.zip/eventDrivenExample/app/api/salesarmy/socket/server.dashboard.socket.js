'use strict';
var Helper = require("../../app/api/shared/server.helper.js");
var async = require("async");
var Employee = require('../api/models/server.employee.model');
var Expenses = require('../api/models/server.expenses.model');
var Meetings = require('../api/models/server.calendar.model');
var Orders = require('../api/models/server.bulk.order.model');
var Leaves = require('../api/models/server.employee.leave.model');
var PaymentLinks = require('../../app/api/models/server.paymentlinks.model');
var AttendanceLog = require('../api/models/server.attendance.model');
var TeamRelation = require('../api/models/server.team.relation.model');

function checkForTeamOrEmployee(data) {
  return new Promise((resolve, reject) => {
    if (data.team) {
      var query = {team: data.team, isDeleted: false};
      TeamRelation.paginate(query, {
        limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
        select: {employee: 1, team: 1},
        lean: true,
        populate: [{path: "team", model: "Sales-Team", select: "name"}]
      }).then(teamData => {
        var teamName = teamData.docs.length > 0 ? teamData.docs[0].team.name : "Team";
        var employeeIds = _.map(teamData.docs, function (o) {
          return o.employee + "";
        });
        resolve({teamName: teamName, employees: employeeIds});
      });
    } else if (data.employee) {
      resolve({employees: [data.employee]});
    } else {
      resolve({employees: []});
    }
  });
}

module.exports.listen = function (io, socket) {

  socket.on("company:employee:status", function (data) {
    Helper.getStore(socket)
      .then(store => {
        checkForTeamOrEmployee(data)
          .then(q => {
            var allEmployees = [];
            var allEmployeeIds = [];
            var presentEmployees = [];
            var absentEmployees = [];
            var employeeTask = function (cb) {
              var options = {
                limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                lean: true,
                select: '_id phone email firstName lastName currentLocation lastUpdatedAt'
              };
              var employeeQuery = {store: store._id, isDeleted: false};
              if (q && q.employees && q.employees.length > 0) {
                employeeQuery._id = null;
                if (q.employees.length == 1) {
                  employeeQuery._id = q.employees[0];
                } else {
                  employeeQuery._id = {$in: q.employees};
                }
              }
              Employee.paginate(employeeQuery, options)
                .then(function (documents) {
                  allEmployees = documents.docs;
                  allEmployeeIds = _.map(allEmployees, function (e) {
                    return e._id + "";
                  });
                  cb(null, documents);
                });
            };

            var presentEmployeeTask = function (cb) {
              var options = {
                limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                lean: true,
                select: '_id employee'
              };

              var attendanceQuery = {
                store: store._id,
                isDeleted: false,
                isStart: true
              };
              var startDate = null;
              var endDate = null;
              if (data.date) {
                startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day").toISOString();
                endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day").toISOString()
              } else if (data.range) {
                startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day").toISOString();
                endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day").toISOString();
              } else {
                startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month").toISOString();
                endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month").toISOString();
              }
              attendanceQuery.createdAt = {
                $gte: startDate,
                $lte: endDate
              };
              if (q && q.employees && q.employees.length > 0) {
                attendanceQuery.employee = null;
                if (q.employees.length == 1) {
                  attendanceQuery.employee = q.employees[0];
                } else {
                  attendanceQuery.employee = {$in: q.employees};
                }
              }
              AttendanceLog.paginate(attendanceQuery, options)
                .then(function (attendanceLog) {
                  presentEmployees = _.uniq(_.map(attendanceLog.docs, function (em) {
                    return em.employee + "";
                  }));
                  cb(null, attendanceLog);
                });
            };

            async.parallel([employeeTask, presentEmployeeTask], function (err, result) {
              absentEmployees = _.difference(allEmployeeIds, presentEmployees);
              socket.emit("company:employee:status:success", {
                allEmployees: allEmployees,
                presentEmployees: presentEmployees,
                absentEmployees: absentEmployees
              });
            })
          });
      });
  });
  socket.on("company:expenses:status", function (data) {
    Helper.getStore(socket)
      .then(store => {
        checkForTeamOrEmployee(data)
          .then(q => {
            var approvedExpenses = [];
            var disApprovedExpenses = [];
            var pendingExpenses = [];
            var options = {
              limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
              lean: true,
              select: '_id amount isApproved'
            };
            var expenseQuery = {
              store: store._id,
              isDeleted: false
            };
            var startDate = null;
            var endDate = null;
            if (data.date) {
              startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day").toISOString();
              endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day").toISOString()
            } else if (data.range) {
              startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day").toISOString();
              endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day").toISOString();
            } else {
              startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month").toISOString();
              endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month").toISOString();
            }
            expenseQuery.createdAt = {
              $gte: startDate,
              $lte: endDate
            };
            if (q && q.employees && q.employees.length > 0) {
              expenseQuery.employee = null;
              if (q.employees.length == 1) {
                expenseQuery.employee = q.employees[0];
              } else {
                expenseQuery.employee = {$in: q.employees};
              }
            }
            Expenses.paginate(expenseQuery, options)
              .then(function (expenses) {
                  approvedExpenses = _.filter(expenses.docs, function (exp) {
                    return exp.isApproved
                  });
                  disApprovedExpenses = _.filter(expenses.docs, function (exp) {
                    return exp.isApproved == false
                  });
                  pendingExpenses = _.filter(expenses.docs, function (exp) {
                    return _.isNull(exp.isApproved) || _.isUndefined(exp.isApproved);
                  });
                approvedExpenses = _.sum(approvedExpenses, 'amount');
                disApprovedExpenses = _.sum(disApprovedExpenses, 'amount');
                pendingExpenses = _.sum(pendingExpenses, 'amount');
                socket.emit("company:expenses:status:success", {
                  approvedExpenses: approvedExpenses,
                  pendingExpenses: pendingExpenses,
                  disApprovedExpenses: disApprovedExpenses
                });
              });
          });
      });
  });
  socket.on("company:leaves:status", function (data) {
    Helper.getStore(socket)
      .then(store => {
        checkForTeamOrEmployee(data)
          .then(q => {
            var allLeaves = [];
            var approvedLeaves = [];
            var disApprovedLeaves = [];
            var pendingLeaves = [];
            var options = {
              limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
              lean: true,
              select: '_id employee isApproved reason dateFrom dateTo',
              populate: [{
                path: "employee",
                model: "Sales-Employee",
                select: "_id firstName lastName currentLocation email mobile "
              }]
            };
            var leaveQuery = {
              store: store._id,
              isDeleted: false
            };
            var startDate = null;
            var endDate = null;
            if (data.date) {
              startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day").toISOString();
              endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day").toISOString()
            } else if (data.range) {
              startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day").toISOString();
              endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day").toISOString();
            } else {
              startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month").toISOString();
              endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month").toISOString();
            }
            leaveQuery.dateFrom = {
              $lte: endDate
            };
            leaveQuery.dateTo = {
              $gte: startDate
            };
            if (q && q.employees && q.employees.length > 0) {
              leaveQuery.employee = null;
              if (q.employees.length == 1) {
                leaveQuery.employee = q.employees[0];
              } else {
                leaveQuery.employee = {$in: q.employees};
              }
            }
            Leaves.paginate(leaveQuery, options)
              .then(function (leaves) {
                allLeaves = leaves.docs;
                approvedLeaves = _.filter(leaves.docs, function (leave) {
                  return leave.isApproved == true
                });
                disApprovedLeaves = _.filter(leaves.docs, function (leave) {
                  return leave.isApproved == false
                });
                pendingLeaves = _.filter(leaves.docs, function (leave) {
                  return _.isNull(leave.isApproved) || _.isUndefined(leave.isApproved);
                });
                approvedLeaves = _.uniq(_.map(approvedLeaves, function (em) {
                  return em._id;
                }));
                disApprovedLeaves = _.uniq(_.map(disApprovedLeaves, function (em) {
                  return em._id;
                }));
                pendingLeaves = _.uniq(_.map(pendingLeaves, function (em) {
                  return em._id;
                }));
                socket.emit("company:leaves:status:success", {
                  allLeaves: allLeaves,
                  approvedLeaves: approvedLeaves,
                  pendingLeaves: pendingLeaves,
                  disApprovedLeaves: disApprovedLeaves
                });
              });
          });
      });
  });
  socket.on("company:meeting:status", function (data) {
    Helper.getStore(socket)
      .then(store => {
        checkForTeamOrEmployee(data)
          .then(q => {
            var allMeeting = [];
            var completedMeeting = [];
            var notInterestedMeeting = [];
            var pendingMeeting = [];
            var options = {
              limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
              lean: true,
              select: '_id employee companyName status remarks location address title',
              populate: [{
                path: "employee",
                model: "Sales-Employee",
                select: "_id firstName lastName currentLocation email mobile "
              }]
            };
            var meetingQuery = {
              store: store._id,
              isDeleted: false,
            };
            var startDate = null;
            var endDate = null;
            if (data.date) {
              startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day").toISOString();
              endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day").toISOString()
            } else if (data.range) {
              startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day").toISOString();
              endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day").toISOString();
            } else {
              startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month").toISOString();
              endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month").toISOString();
            }
            meetingQuery.start = {
              $lte: endDate
            };
            meetingQuery.end = {
              $gte: startDate
            };
            if (q && q.employees && q.employees.length > 0) {
              meetingQuery.employee = null;
              if (q.employees.length == 1) {
                meetingQuery.employee = q.employees[0];
              } else {
                meetingQuery.employee = {$in: q.employees};
              }
            }
            Meetings.paginate(meetingQuery, options)
              .then(function (meetings) {
                allMeeting = meetings.docs;
                completedMeeting = _.filter(meetings.docs, function (meeting) {
                  return meeting.status == "completed";
                });
                notInterestedMeeting = _.filter(meetings.docs, function (meeting) {
                  return meeting.status == "not-interested";
                });
                pendingMeeting = _.filter(meetings.docs, function (meeting) {
                  return meeting.status == "pending";
                });
                completedMeeting = _.uniq(_.map(completedMeeting, function (em) {
                  return em._id;
                }));
                notInterestedMeeting = _.uniq(_.map(notInterestedMeeting, function (em) {
                  return em._id;
                }));
                pendingMeeting = _.uniq(_.map(pendingMeeting, function (em) {
                  return em._id;
                }));
                socket.emit("company:meeting:status:success", {
                  allMeeting: allMeeting,
                  completedMeeting: completedMeeting,
                  notInterestedMeeting: notInterestedMeeting,
                  pendingMeeting: pendingMeeting
                });
              });
          });
      });
  });
  socket.on("company:order:status", function (data) {
    Helper.getStore(socket)
      .then(store => {
        checkForTeamOrEmployee(data)
          .then(q => {
            var totalOrders = [];
            var completedOrders = [];
            var pendingOrders = [];
            var completedOrderSum = [];
            var pendingOrderSum = [];
            var totalOrderSum = [];
            var options = {
              limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
              lean: true,
              select: '_id employee total status createdAt orderId client',
              populate: [{
                path: "employee",
                model: "Sales-Employee",
                select: "_id firstName lastName currentLocation email mobile "
              }, {
                path: "client",
                model: "Sales-Distributor",
                select: "_id name "
              }]
            };
            var orderQuery = {
              store: store._id,
              isDeleted: false
            };
            var startDate = null;
            var endDate = null;
            if (data.date) {
              startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day").toISOString();
              endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day").toISOString()
            } else if (data.range) {
              startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day").toISOString();
              endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day").toISOString();
            } else {
              startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month").toISOString();
              endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month").toISOString();
            }
            orderQuery.createdAt = {
              $gte: startDate,
              $lte: endDate
            };
            if (q && q.employees && q.employees.length > 0) {
              orderQuery.employee = null;
              if (q.employees.length == 1) {
                orderQuery.employee = q.employees[0];
              } else {
                orderQuery.employee = {$in: q.employees};
              }
            }
            Orders.paginate(orderQuery, options)
              .then(function (order) {
                totalOrders = order.docs;
                totalOrderSum = _.sum(totalOrders, 'total');
                if (Helper.checkAddonBoolean(store, "SALES_ORDER_PROCESS")) {
                  pendingOrders = _.filter(order.docs, function (ordr) {
                    return ordr.status == "pending";
                  });
                  completedOrders = _.filter(order.docs, function (ordr) {
                    return ordr.status == "complete";
                  });
                  completedOrderSum = _.sum(completedOrders, 'total');
                  pendingOrderSum = _.sum(pendingOrders, 'total');
                  pendingOrders = _.uniq(_.map(pendingOrders, function (em) {
                    return em._id;
                  }));
                  completedOrders = _.uniq(_.map(completedOrders, function (em) {
                    return em._id;
                  }));
                }
                var returnObj = {
                  totalOrder: totalOrders,
                  totalOrderSum: totalOrderSum
                };
                if (Helper.checkAddonBoolean(store, "SALES_ORDER_PROCESS")) {
                  returnObj = _.extend(returnObj, {
                    completedOrder: completedOrders,
                    pendingOrder: pendingOrders,
                    completedOrderSum: completedOrderSum,
                    pendingOrderSum: pendingOrderSum
                  })
                }
                socket.emit("company:order:status:success", returnObj);
              });
          });
      });
  });
  socket.on("company:payment-link:status", function (data) {
    Helper.getStore(socket)
      .then(store => {
        checkForTeamOrEmployee(data)
          .then(q => {
            var totalPaymentLinks = [];
            var completedPaymentLinks = [];
            var pendingPaymentLinks = [];
            var options = {
              limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
              lean: true,
              select: '_id amount name mobile email status createdAt orderId',
            };
            var paymentLinksQuery = {
              store: store._id,
              isDeleted: false
            };
            var startDate = null;
            var endDate = null;
            if (data.date) {
              startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day").toISOString();
              endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day").toISOString()
            } else if (data.range) {
              startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day").toISOString();
              endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day").toISOString();
            } else {
              startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month").toISOString();
              endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month").toISOString();
            }
            paymentLinksQuery.createdAt = {
              $gte: startDate,
              $lte: endDate
            };
            if (q && q.employees && q.employees.length > 0) {
              paymentLinksQuery.employee = null;
              if (q.employees.length == 1) {
                paymentLinksQuery.employee = q.employees[0];
              } else {
                paymentLinksQuery.employee = {$in: q.employees};
              }
            }
            PaymentLinks.paginate(paymentLinksQuery, options)
              .then(function (paymentlink) {
                totalPaymentLinks = paymentlink.docs;

                pendingPaymentLinks = _.filter(paymentlink.docs, function (link) {
                  return link.status == "pending";
                });
                completedPaymentLinks = _.filter(paymentlink.docs, function (link) {
                  return link.status == "paid";
                });
                pendingPaymentLinks = _.uniq(_.map(pendingPaymentLinks, function (em) {
                  return em._id;
                }));
                completedPaymentLinks = _.uniq(_.map(completedPaymentLinks, function (em) {
                  return em._id;
                }));
                var returnObj = {
                  totalPaymentLinks: totalPaymentLinks,
                  completedPaymentLinks: completedPaymentLinks,
                  pendingPaymentLinks: pendingPaymentLinks
                };
                socket.emit("company:payment-link:status:success", returnObj);
              });
          });
      });
  });
};