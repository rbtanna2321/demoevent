'use strict';
var async = require("async"),
  Excel = require('exceljs'),
  s = require('underscore.string'),
  FullAttendance = require('../api/models/server.attendance.model'),
  TeamRelation = require('../api/models/server.team.relation.model'),
  Orders = require('../api/models/server.bulk.order.model'),
  StoreOrders = require('../../app/api/models/server.order.model'),
  Employee = require('../api/models/server.employee.model'),
  EmployeeLeave = require('../api/models/server.employee.leave.model'),
  EmployeeExpenses = require('../api/models/server.expenses.model'),
  Meetings = require('../api/models/server.calendar.model'),
  PaymentLinks = require('../../app/api/models/server.paymentlinks.model'),
  Payout = require('../../app/api/models/server.order.model'),
  Visitors = require('../api/models/server.visitor.model'),
  GPS = require('../api/models/server.gps.log.model'),
  WiFi = require('../api/models/server.gps.log.model'),
  Clients = require('../api/models/server.distributor.model'),
  PaymentCollection = require('../api/models/server.payment.collection.model'),
  ApplicationUsage = require('../api/models/server.application.usage.model'),
  Subscription = require('../../app/api/models/server.customer.group.relation.model');

var STATUS_COLORS = {
  default: "ffffffff",
  pending: "fff1c40f",
  disapproved: "ffe74c3c",
  paid: "ff2ecc71",
  approved: "ff2ecc71",
  danger: "ffe74c3c",
  cancelled: "ffe74c3c",
  hot: "ffddddd",
  cold: "ffdaeffd",
  notInterested: "ffd8dadc",
  postponed: "fff0f0f0",
  complete: "ffcff5f2"
}

var getDateArray = function (start, end) {
  var arr = new Array();
  var dt = new Date(start);
  while (dt <= end) {
    arr.push(new Date(dt).toISOString());
    dt.setDate(dt.getDate() + 1);
  }
  return arr;
};

function parseDuration(duration) {
  let remain = duration

  let days = Math.floor(remain / (1000 * 60 * 60 * 24))
  remain = remain % (1000 * 60 * 60 * 24)

  let hours = Math.floor(remain / (1000 * 60 * 60))
  remain = remain % (1000 * 60 * 60)

  let minutes = Math.floor(remain / (1000 * 60))
  remain = remain % (1000 * 60)

  let seconds = Math.floor(remain / (1000))
  remain = remain % (1000)

  let milliseconds = remain

  return {
    days,
    hours,
    minutes,
    seconds,
    milliseconds
  };
}

function formatTime(o, useMilli = false) {
  let parts = []
  if (o.days) {
    let ret = o.days + ' day'
    if (o.days !== 1) {
      ret += 's'
    }
    parts.push(ret)
  }
  if (o.hours) {
    let ret = o.hours + ' hour'
    if (o.hours !== 1) {
      ret += 's'
    }
    parts.push(ret)
  }
  if (o.minutes) {
    let ret = o.minutes + ' minute'
    if (o.minutes !== 1) {
      ret += 's'
    }
    parts.push(ret)

  }
  if (o.seconds) {
    let ret = o.seconds + ' second'
    if (o.seconds !== 1) {
      ret += 's'
    }
    parts.push(ret)
  }
  if (useMilli && o.milliseconds) {
    let ret = o.milliseconds + ' millisecond'
    if (o.milliseconds !== 1) {
      ret += 's'
    }
    parts.push(ret)
  }
  if (parts.length === 0) {
    return 'No Usage'
  } else {
    return parts.join(' ')
  }
}

function formatDuration(duration, useMilli = false) {
  let time = parseDuration(duration)
  return formatTime(time, useMilli)
}


function checkLeaveStatus(date, row) {
  return new Promise((resolve, reject) => {
    EmployeeLeave.findOne({
      employee: row._id, dateFrom: {
        $lte: _MOMENT(date).toDate()
      }, dateTo: {
        $gte: _MOMENT(date).toDate()
      }
    }, '_id reason approvalDate isApproved', {lean: true}).then(leave => {
      if (leave && !_.isNull(leave)) {
        resolve({leave: leave, row: row});
      } else {
        resolve({leave: null, row: row});
      }
    })
  });
}

function checkOrderStatus(date, row) {
  return new Promise((resolve, reject) => {
    StoreOrders.findOne({
      order: row._id, dateFrom: {
        $lte: _MOMENT(date).toDate()
      }, dateTo: {
        $gte: _MOMENT(date).toDate()
      }
    }, '_id name quantity', {lean: true}).then(product => {
      if (product && !_.isNull(product)) {
        resolve({order: product, row: row});
      } else {
        resolve({order: null, row: row});
      }
    })
  });
}


function addLeaveData(workbook, employeeData, store) {
  return new Promise((resolve, reject) => {
    var sheet = workbook.addWorksheet('Leave Report');
    sheet.state = 'visible';
    sheet.columns = [
      {header: 'Employee', key: 'employee'},
      {header: 'Date', key: 'date'},
      {header: 'Status', key: 'status'},
      {header: 'Reason', key: 'reason'}
    ];
    async.eachSeries(employeeData, function (row, cb) {
      if (row.employee) {
        async.eachSeries(row.unattended, function (unattended, callb) {
          checkLeaveStatus(unattended, row)
            .then(om => {
              var leave = om.leave;
              row = om.row;
              var object = {
                employee: row.employee ? {formula: 'HYPERLINK("http://' + (store.domain ? store.domain : store.subdomain) + '/manage/employees/view/' + row.employee._id + '", "' + row.employee.firstName + " " + row.employee.lastName + '")'} : "-",
                date: _MOMENT(unattended).format("DD-MM-YYYY"),
                status: "-",
                reason: "-"
              };
              if (leave) {
                object.status = leave.isApproved == true ? "Approved" : "Disapproved";
                object.reason = leave.reason ? leave.reason : "-";
              } else {
                object.status = "No Leave Application";
              }
              var row = sheet.addRow(object);
              var cell = row.getCell(1);
              var color = STATUS_COLORS.default;
              switch (cell.value) {
                case "Approved":
                  color = STATUS_COLORS.approved;
                  break;
                case "Disapproved":
                  color = STATUS_COLORS.disapproved;
                  break;
              }
              cell.fill = {
                type: 'pattern',
                pattern: 'darkVertical',
                fgColor: {argb: color}
              };
              row.commit();
              callb();
            });
        }, function (err, res) {
          cb();
        });
      } else {
        Employee.findOne({_id: row._id}, '_id firstName lastName', {lean: true})
          .then(em => {
            async.eachSeries(row.unattended, function (unattended, callb) {
              checkLeaveStatus(unattended, row)
                .then(om => {
                  var leave = om.leave;
                  var object = {
                    employee: em.firstName + " " + em.lastName,
                    date: _MOMENT(unattended).format("DD-MM-YYYY"),
                    status: "-",
                    reason: "-"
                  };
                  if (leave) {
                    object.status = leave.isApproved == true ? "Approved" : "Disapproved";
                    object.reason = leave.reason ? leave.reason : "-";
                  } else {
                    object.status = "No Leave Application";
                  }
                  var row = sheet.addRow(object);
                  var cell = row.getCell(1);
                  var color = STATUS_COLORS.default;
                  switch (cell.value) {
                    case "Approved":
                      color = STATUS_COLORS.approved;
                      break;
                    case "Disapproved":
                      color = STATUS_COLORS.disapproved;
                      break;
                  }
                  cell.fill = {
                    type: 'pattern',
                    pattern: 'darkVertical',
                    fgColor: {argb: color}
                  };
                  row.commit();
                  callb();
                });
            }, function (err, res) {
              cb();
            });
          })
      }
    }, function (err, result) {
      resolve(workbook);
    });
  });
}

function addOrderData(workbook, orderData, store) {
  return new Promise((resolve, reject) => {
    var sheet = workbook.addWorksheet('Detail Order Report');
    sheet.state = 'visible';
    sheet.columns = [
      {header: 'Order Id', key: 'orderId'},
      {header: 'Create date', key: 'catetedAt'},
      {header: 'Create Time', key: 'createdAtTime'},
      {header: 'Status', key: 'status'},
      {header: 'Customer Name', key: 'cName'},
      {header: 'Customer Mobile No', key: 'cNumber'},
      {header: 'Address', key: 'cAddress'},
      {header: 'City', key: 'city'},
      {header: 'State', key: 'state'},
      {header: 'Pin Code', key: 'zip'},
      {header: 'Country', key: 'country'},
      {header: 'Item In Order', key: 'itemInOrder'},
      {header: 'Shipping Charges', key: 'shippingCharge'},
      {header: 'Amount', key: 'amount'},
      {header: 'Product Name', key: 'pName'},
      {header: 'Product Quantity', key: 'pQty'},
      {header: 'Payment Method', key: 'paymentMethod'},
      {header: 'Payment Id', key: 'paymentId'},
      {header: 'Gateway Charges', key: 'gatewayCharge'},
      {header: 'Settled Amount', key: 'settledAmount'},
      {header: 'Discount Type', key: 'discountType'},
      {header: 'Value', key: 'value'}
    ];
    async.eachSeries(orderData, function (row, cb) {
      async.eachSeries(row.items, function (product, callb) {
        sheet.addRow({
          orderId: row.orderId,
          createdAt: _MOMENT(row.createdAt).format("DD-MM-YYYY"),
          createdAtTime: _MOMENT(row.createdAt).format("hh:mm A"),
          status: row.status,
          cName: row.customer ? "" + row.customer.firstName + "" + row.customer.lastName : '-',
          cNumber: row.customer ? row.customer.mobile : '-',
          cAddress: row.shippingAddress ? row.shippingAddress.address1 : '-',
          city: row.shippingAddress ? row.shippingAddress.city : '-',
          state: row.shippingAddress ? row.shippingAddress.state : '-',
          zip: row.shippingAddress ? row.shippingAddress.zip : '-',
          country: row.shippingAddress ? row.shippingAddress.country : '-',
          itemInOrder: row.items.quantity,
          shippingCharge: row.shippingCharge,
          amount: row.amount,
          pName: product.item.product.name,
          pQty: product.item.quantity,
          paymentMethod: row.paymentType,
          paymentId: row.gateway.response.razorpay_payment_id,
          gatewayCharge: row.gateway.response.totalFee,
          settledAmount: row.gateway.response.totalFee ? (row.amount - (row.gateway.response.totalFee + row.discount.value)) : "-",
          discountType: row.discountValue ? row.discountValue : "-",
          value: row.value ? row.value : "-"
        }).commit();
      });
      cb();
    }, function (err, result) {
      var row = sheet.addRow(object);
      row.commit();
      callb();
    })
  });
}


function checkForTeamOrEmployee(data) {
  return new Promise((resolve, reject) => {
    if (data.team) {
      var query = {team: data.team, isDeleted: false};
      TeamRelation.paginate(query, {
        limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
        select: {employee: 1, team: 1},
        lean: true,
        populate: [{path: "team", model: "Sales-Team", select: "name"}]
      }).then(teamData => {
        var teamName = teamData.docs.length > 0 ? teamData.docs[0].team.name : "Team";
        var employeeIds = _.map(teamData.docs, function (o) {
          return o.employee + "";
        });
        resolve({teamName: teamName, employees: employeeIds});
      });
    } else if (data.employee) {
      resolve({employees: [data.employee]});
    } else {
      resolve({employees: []});
    }
  });
}

function getAllEmployeeIds(q, store) {
  return new Promise((resolve, reject) => {
    if (q.employees && q.employees.length == 0) {
      Employee.paginate({store: store._id, isDeleted: false}, {
        limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
        select: {_id: 1},
        lean: true
      }).then(teamData => {
        resolve(_.pluck(teamData.docs, '_id'));
      });
    } else {
      resolve(q.employees);
    }
  });
}

module.exports.listen = function (io, socket) {

  socket.on("sales:attendance:report", function (data) {
    _HELPER.getStore(socket)
      .then(store => {
        checkForTeamOrEmployee(data)
          .then(q => {
            getAllEmployeeIds(q, store)
              .then(employeeIds => {
                var attendanceQuery = {isDeleted: false, store: store._id};
                if (q.employees && q.employees.length > 0) {
                  attendanceQuery.employee = {$in: q.employees};
                }
                var startDate = null;
                var endDate = null;
                if (data.date) {
                  startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
                } else if (data.range) {
                  startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                } else if (data.month) {
                  startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
                  endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
                }
                attendanceQuery.createdAt = {
                  $gte: startDate.toISOString(),
                  $lte: endDate.toISOString()
                };
                FullAttendance.paginate(attendanceQuery, {
                  limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                  select: {latitude: 1, longitude: 1, createdAt: 1, image: 1, isStart: 1},
                  lean: true,
                  populate: [{path: "image", model: "PrivateFile", select: '_id url'},
                    {path: "employee", model: "Sales-Employee", select: '_id firstName lastName'}]
                })
                  .then(result => {
                    var groupedByEmployee = _.groupBy(result.docs, function (r) {
                      return r.employee._id
                    });
                    var dateArr = getDateArray(startDate, endDate);
                    var dateListGroupedByEmployee = _.map(employeeIds, function (emp) {
                      if (groupedByEmployee[emp]) {
                        groupedByEmployee[emp].attended = [];
                        _.each(groupedByEmployee[emp], function (attended) {
                          if (attended.isStart) {
                            groupedByEmployee[emp].attended = _.union(groupedByEmployee[emp].attended, [_MOMENT(attended.createdAt).startOf("day").toISOString()]);
                          }
                        });
                        return {
                          _id: emp,
                          attended: groupedByEmployee[emp].attended,
                          unattended: _.difference(dateArr, groupedByEmployee[emp].attended),
                          employee: groupedByEmployee[emp][0].employee
                        };
                      } else {
                        return {
                          _id: emp,
                          attended: [],
                          unattended: dateArr,
                          employee: null
                        };
                      }
                    });
                    var workbook = new Excel.Workbook();
                    workbook.creator = 'Me';
                    workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
                    workbook.modified = new Date();
                    var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
                    if (data.date) {
                      sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day").format("DD-MM-YYYY");
                    } else if (data.range) {
                      startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                      endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                      sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
                    }
                    var sheet = workbook.addWorksheet('Attendance Report - ' + sheetName);
                    sheet.state = 'visible';
                    sheet.columns = [
                      {header: 'Employee', key: 'employee'},
                      {header: 'Date', key: 'createdAt'},
                      {header: 'Time', key: 'createdAtTime'},
                      {header: 'Status', key: 'status'},
                      {header: 'Image', key: 'image'},
                      {header: 'Location', key: 'location'}
                    ];
                    async.eachSeries(result.docs, function (row, cb) {
                      var row = sheet.addRow({
                        employee: row.employee ? {formula: 'HYPERLINK("http://' + (store.domain ? store.domain : store.subdomain) + '/manage/employees/view/' + row.employee._id + '", "' + row.employee.firstName + " " + row.employee.lastName + '")'} : "-",
                        createdAt: _MOMENT(row.createdAt).format("DD-MM-YYYY"),
                        createdAtTime: _MOMENT(row.createdAt).format("hh:mm:ss A"),
                        location: {formula: 'HYPERLINK("https://maps.google.com?q=' + row.latitude + ',' + row.longitude + '", "Open in Maps")'},
                        status: row.isStart ? "Checked In" : "Checked Out",
                        image: row.image ? {formula: 'HYPERLINK("' + row.image.url + '", "Open in Browser")'} : ""

                      });
                      var cell = row.getCell(4);
                      var color = STATUS_COLORS.default;
                      switch (cell.value) {
                        case "Checked Out":
                          color = STATUS_COLORS.disapproved;
                          break;
                        case "Checked In":
                          color = STATUS_COLORS.approved;
                          break;
                      }
                      cell.fill = {
                        type: 'pattern',
                        pattern: 'darkVertical',
                        fgColor: {argb: color}
                      };
                      row.commit();
                      cb();
                    }, function (err, result) {
                      addLeaveData(workbook, dateListGroupedByEmployee, store)
                        .then(workbookUpdated => {
                          workbookUpdated.xlsx.writeBuffer().then(function (data) {
                            socket.emit("sales:attendance:report:success", {
                              buffer: data,
                              teamName: q.teamName
                            });
                          });
                        });
                    });
                  });
              });
          });
      });
  });

  socket.on("sales:order:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            checkForTeamOrEmployee(data)
              .then(q => {
                var orderQuery = {isDeleted: false, store: store._id};
                var startDate = null;
                var endDate = null;
                if (data.date) {
                  startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
                } else if (data.range) {
                  startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                } else if (data.month) {
                  startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
                  endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
                }
                orderQuery.createdAt = {
                  $gte: startDate.toISOString(),
                  $lte: endDate.toISOString()
                };
                if (q && q.employees && q.employees.length > 0) {
                  orderQuery.employee = null;
                  if (q.employees.length == 1) {
                    orderQuery.employee = q.employees[0];
                  } else {
                    orderQuery.employee = {$in: q.employees};
                  }
                }
                if (!store.settings.salesarmy.showOrdersAddedByOtherEmployees && response.user._id != store.owner._id) {
                  orderQuery['employee'] = response.user._id;
                }
                Orders.paginate(orderQuery, {
                  limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                  lean: true,
                  populate: [{
                    path: 'client',
                    model: "Sales-Distributor",
                    select: '_id name'
                  }, {
                    path: 'employee',
                    model: "Sales-Employee",
                    select: '_id firstName lastName email'
                  }, {
                    path: 'items.item',
                    model: "Sales-Product",
                    select: 'name sku'
                  }]
                })
                  .then(result => {
                    var orders = result.docs;
                    var workbook = new Excel.Workbook();
                    workbook.creator = 'Me';
                    workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
                    workbook.modified = new Date();
                    var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
                    if (data.date) {
                      sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                    } else if (data.range) {
                      startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                      endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                      sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
                    }
                    var sheet = workbook.addWorksheet(sheetName);
                    sheet.state = 'visible';
                    if (_HELPER.checkAddonBoolean(store, "SALES_ORDER_PROCESS")) {
                      sheet.columns = [
                        {header: 'Date', key: 'createdAt'},
                        {header: 'Time', key: 'createdAtTime'},
                        {header: 'Order ID', key: 'orderId'},
                        {header: 'Client', key: 'client'},
                        {header: 'Employee', key: 'employee'},
                        {header: 'Status', key: 'status'},
                        {header: 'Product', key: 'product'},
                        {header: 'SKU', key: 'sku'},
                        {header: 'Rate', key: 'rate'},
                        {header: 'Quantity', key: 'quantity'},
                        {header: 'Delivered', key: 'delivered'},
                        {header: 'Sub Total', key: 'subtotal'},
                        {header: 'Order Total', key: 'total'},
                        {header: 'Note', key: 'note'}
                      ];
                    } else {
                      sheet.columns = [
                        {header: 'Date', key: 'createdAt'},
                        {header: 'Time', key: 'createdAtTime'},
                        {header: 'Order ID', key: 'orderId'},
                        {header: 'Client', key: 'client'},
                        {header: 'Employee', key: 'employee'},
                        {header: 'Product', key: 'product'},
                        {header: 'SKU', key: 'sku'},
                        {header: 'Rate', key: 'rate'},
                        {header: 'Quantity', key: 'quantity'},
                        {header: 'Sub Total', key: 'subtotal'},
                        {header: 'Order Total', key: 'total'},
                        {header: 'Note', key: 'note'}
                      ];
                    }
                    async.each(orders, function (row, cb) {
                      _.each(row.items, function (product) {
                        sheet.addRow({
                          createdAt: _MOMENT(row.createdAt).format("DD-MM-YYYY"),
                          createdAtTime: _MOMENT(row.createdAt).format("hh:mm A"),
                          orderId: row.orderId,
                          client: row.client ? row.client.name : '-',
                          employee: row.employee ? {formula: 'HYPERLINK("http://' + (store.domain ? store.domain : store.subdomain) + '/manage/employees/view/' + row.employee._id + '", "' + row.employee.firstName + " " + row.employee.lastName + '")'} : "-",
                          status: product.quantity == product.delivered ? "Complete" : "Pending",
                          product: product.item.name,
                          sku: product.item.sku,
                          rate: product.price,
                          quantity: product.quantity,
                          delivered: product.delivered,
                          subtotal: product.price * product.quantity,
                          total: row.total,
                          row: row.note
                        }).commit();
                      });
                      cb();
                    }, function (err, result) {
                      workbook.xlsx.writeBuffer().then(function (data) {
                        var returnObj = {buffer: data};
                        if (q.teamName) {
                          returnObj.teamName = q.teamName;
                        }
                        socket.emit("sales:order:report:success", returnObj);
                      });
                    });
                  });
              });
          });
      });
  });

  socket.on("sales:storearmyOrder:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            checkForTeamOrEmployee(data)
              .then(q => {
                var orderQuery = {isDeleted: false, store: store._id};
                var startDate = null;
                var endDate = null;
                if (data.date) {
                  startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
                } else if (data.range) {
                  startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                } else if (data.month) {
                  startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
                  endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
                }
                orderQuery.createdAt = {
                  $gte: startDate.toISOString(),
                  $lte: endDate.toISOString()
                };
                if (q && q.employees && q.employees.length > 0) {
                  orderQuery.employee = null;
                  if (q.employees.length == 1) {
                    orderQuery.employee = q.employees[0];
                  } else {
                    orderQuery.employee = {$in: q.employees};
                  }
                }
                if (!store.settings.salesarmy.showOrdersAddedByOtherEmployees && response.user._id != store.owner._id) {
                  orderQuery['employee'] = response.user._id;
                }
                StoreOrders.paginate(orderQuery, {
                  limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                  lean: true,
                  populate: [{
                    path: 'customer',
                    model: "Customer",
                    select: '_id firstName lastName gender dob mobile'
                  }, {
                    path: 'items.item.product',
                    model: "Product",
                  }, {
                    path: 'transactions',
                    model: "Transaction",
                  }, {
                    path: 'shippingAddress',
                    model: "Address",
                  }]
                })
                  .then(result => {
                    var orders = result.docs;
                    var workbook = new Excel.Workbook();
                    workbook.creator = 'Me';
                    workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
                    workbook.modified = new Date();
                    var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
                    if (data.date) {
                      sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                    } else if (data.range) {
                      startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                      endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                      sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
                    }
                    var sheet = workbook.addWorksheet(sheetName);
                    sheet.state = 'visible';
                    sheet.columns = [
                      {header: 'Order Id', key: 'orderId'},
                      {header: 'Create date', key: 'createdAt'},
                      {header: 'Create Time', key: 'createdAtTime'},
                      {header: 'Status', key: 'status'},
                      {header: 'Customer Name', key: 'cName'},
                      {header: 'Customer Mobile No', key: 'cNumber'},
                      {header: 'Address', key: 'cAddress'},
                      {header: 'City', key: 'city'},
                      {header: 'State', key: 'state'},
                      {header: 'Pin Code', key: 'zip'},
                      {header: 'Country', key: 'country'},
                      {header: 'Item In Order', key: 'itemInOrder'},
                      {header: 'Shipping Charges', key: 'shippingCharge'},
                      {header: 'Amount', key: 'amount'},
                      {header: 'Payment Method', key: 'paymentMethod'},
                      {header: 'Payment Id', key: 'paymentId'},
                      {header: 'Gateway Charges', key: 'gatewayCharge'},
                      {header: 'Settled Amount', key: 'settledAmount'},
                      {header: 'Discount Type', key: 'discountType'},
                      {header: 'Value', key: 'value'}
                    ];
                    async.each(orders, function (row, cb) {
                      var paymentDetail = JSON.parse(row.gateway.response);
                      _.each(row.items, function (product) {
                        sheet.addRow({
                          orderId: row.orderId,
                          createdAt: _MOMENT(row.createdAt).format("DD-MM-YYYY"),
                          createdAtTime: _MOMENT(row.createdAt).format("hh:mm A"),
                          status: row.status,
                          cName: row.customer ? "" + row.customer.firstName + "" + row.customer.lastName : '-',
                          cNumber: row.customer ? row.customer.mobile : '-',
                          cAddress: row.shippingAddress ? row.shippingAddress.address1 + "" + row.shippingAddress.address2 : '-',
                          city: row.shippingAddress ? row.shippingAddress.city : '-',
                          state: row.shippingAddress ? row.shippingAddress.state : '-',
                          zip: row.shippingAddress ? row.shippingAddress.zip : '-',
                          country: row.shippingAddress ? row.shippingAddress.country : '-',
                          itemInOrder: row.items ? row.items.quantity : "-",
                          shippingCharge: row.shippingCharge ? row.shippingCharge : "-",
                          amount: row.amount,
                          pName: product.item.product.name,
                          pQty: product.item.quantity,
                          paymentMethod: row.paymentType,
                          paymentId: paymentDetail.razorpay_payment_id,
                          gatewayCharge: paymentDetail.totalFee,
                          settledAmount: paymentDetail.discountValue ? Math.floor(row.amount - row.discountValue - paymentDetail.totalFee) : Math.floor(row.amount - paymentDetail.totalFee),
                          discountType: row.discountType ? row.discountType : "-",
                          value: row.discountValue ? row.discountValue : "-"
                        }).commit();
                      });
                      cb();
                    }, function (err, result) {
                      // workbook.xlsx.writeBuffer().then(function (data) {
                      //   var returnObj = {buffer: data};
                      //   if (q.teamName) {
                      //     returnObj.teamName = q.teamName;
                      //   }
                      //   socket.emit("sales:storearmyOrder:report:success", returnObj);
                      // });
                      addOrderData(workbook, orderData, store)
                        .then(workbookUpdated => {
                          workbookUpdated.xlsx.writeBuffer().then(function (data) {
                            socket.emit("sales:storearmyOrder:report:success", {
                              buffer: data,
                              teamName: q.teamName
                            });
                          });
                        });
                    });
                  });
              });
          });
      });
  });

  socket.on("sales:application:usage:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            checkForTeamOrEmployee(data)
              .then(q => {
                var appUsageQuery = {isDeleted: false};
                var startDate = null;
                var endDate = null;
                if (data.date) {
                  startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
                } else if (data.range) {
                  startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                } else if (data.month) {
                  startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
                  endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
                }
                appUsageQuery.createdAt = {
                  $gte: startDate.toISOString(),
                  $lte: endDate.toISOString()
                };
                if (q && q.employees && q.employees.length > 0) {
                  appUsageQuery.employee = null;
                  if (q.employees.length == 1) {
                    appUsageQuery.employee = q.employees[0];
                  } else {
                    appUsageQuery.employee = {$in: q.employees};
                  }
                }
                if (!store.settings.salesarmy.showOrdersAddedByOtherEmployees && response.user._id != store.owner._id) {
                  appUsageQuery['employee'] = response.user._id;
                }
                ApplicationUsage.paginate(appUsageQuery, {
                  limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                  lean: true,
                  populate: [{
                    path: 'applications.application',
                    model: "Sales-Application",
                    select: '_id name packageId genre url'
                  }, {
                    path: 'employee',
                    model: "Sales-Employee",
                    select: '_id firstName lastName email'
                  }]
                })
                  .then(result => {
                    var applicationUsage = result.docs;
                    var workbook = new Excel.Workbook();
                    workbook.creator = 'Me';
                    workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
                    workbook.modified = new Date();
                    var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
                    if (data.date) {
                      sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                    } else if (data.range) {
                      startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                      endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                      sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
                    }
                    var sheet = workbook.addWorksheet(sheetName);
                    sheet.state = 'visible';
                    sheet.columns = [
                      {header: 'Employee', key: 'employee'},
                      {header: 'App Name', key: 'appName'},
                      {header: 'Type', key: 'genre'},
                      {header: 'Duration', key: 'time'},
                      {header: 'Date', key: 'createdAt'},
                      {header: 'URL', key: 'url'}
                    ];
                    async.each(applicationUsage, function (row, cb) {
                      _.each(row.applications, function (app) {
                        sheet.addRow({
                          time: formatDuration(app.time),
                          createdAt: _MOMENT(row.createdAt).format("DD-MM-YYYY"),
                          genre: app.application ? s.humanize(app.application.genre) : '-',
                          appName: app.application ? app.application.name : '-',
                          employee: row.employee ? {formula: 'HYPERLINK("http://' + (store.domain ? store.domain : store.subdomain) + '/manage/employees/view/' + row.employee._id + '", "' + row.employee.firstName + " " + row.employee.lastName + '")'} : "-",
                          url: app.application ? {formula: 'HYPERLINK("' + (app.application.url) + '", "View on Play Store")'} : "-",
                        }).commit();
                      });
                      cb();
                    }, function (err, result) {
                      workbook.xlsx.writeBuffer().then(function (data) {
                        var returnObj = {buffer: data};
                        if (q.teamName) {
                          returnObj.teamName = q.teamName;
                        }
                        socket.emit("sales:application:usage:report:success", returnObj);
                      });
                    });
                  });
              });
          });
      });
  });

  socket.on("sales:expenses:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            checkForTeamOrEmployee(data)
              .then(q => {
                var expensesQuery = {isDeleted: false, store: store._id};
                var startDate = null;
                var endDate = null;
                if (data.date) {
                  startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
                } else if (data.range) {
                  startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                } else if (data.month) {
                  startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
                  endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
                }
                expensesQuery.createdAt = {
                  $gte: startDate.toISOString(),
                  $lte: endDate.toISOString()
                };
                if (q && q.employees && q.employees.length > 0) {
                  expensesQuery.employee = null;
                  if (q.employees.length == 1) {
                    expensesQuery.employee = q.employees[0];
                  } else {
                    expensesQuery.employee = {$in: q.employees};
                  }
                }
                EmployeeExpenses.paginate(expensesQuery, {
                  limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                  lean: true,
                  populate: [{
                    path: 'employee',
                    select: '_id firstName lastName email phone'
                  }, {
                    path: 'attachments',
                    select: '_id url'
                  }]
                }).then(result => {
                  var EmployeeExpenses = result.docs;
                  var workbook = new Excel.Workbook();
                  workbook.creator = 'Me';
                  workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
                  workbook.modified = new Date();
                  var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
                  if (data.date) {
                    sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  } else if (data.range) {
                    startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                    endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                    sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
                  }
                  var sheet = workbook.addWorksheet(sheetName);
                  sheet.state = 'visible';
                  sheet.columns = [
                    {header: 'Name', key: 'name'},
                    {header: 'Email', key: 'email'},
                    {header: 'Number', key: 'mobile'},
                    {header: 'Company', key: 'company'},
                    {header: 'Date', key: 'dateOfExpense'},
                    {header: 'Time', key: 'time'},
                    {header: 'Category', key: 'category'},
                    {header: 'Amount', key: 'amount'},
                    {header: 'Note', key: 'note'},
                    {header: 'Comment', key: 'comment'},
                    {header: 'Status', key: 'isApproved'},
                    {header: 'Image', key: 'attachment'}
                  ];
                  async.each(EmployeeExpenses, function (row, cb) {
                    var row = sheet.addRow({
                      name: row.employee ? {formula: 'HYPERLINK("http://' + (store.domain ? store.domain : store.subdomain) + '/manage/employees/view/' + row.employee._id + '", "' + row.employee.firstName + " " + row.employee.lastName + '")'} : "-",
                      email: row.employee.email,
                      mobile: row.employee.phone.number,
                      company: row.company,
                      dateOfExpense: _MOMENT(row.dateOfExpense).format("DD-MM-YYYY"),
                      time: _MOMENT(row.dateOfExpense).format("hh:mm A"),
                      category: row.category,
                      amount: row.amount,
                      note: row.note,
                      comment: row.comment,
                      isApproved: row.hasOwnProperty("isApproved") ? (row.isApproved ? "Approved" : "Disapproved") : "Pending",
                      attachment: row.attachments && row.attachments.length > 0 ? {formula: 'HYPERLINK("' + row.attachments[0].url + '", "Open in Browser")'} : ""
                    });
                    var cell = row.getCell(11);
                    var color = STATUS_COLORS.default;
                    switch (cell.value) {
                      case "Pending":
                        color = STATUS_COLORS.disapproved;
                        break;
                      case "Approved":
                        color = STATUS_COLORS.approved;
                        break;
                      case "Disapproved":
                        color = STATUS_COLORS.danger;
                        break;
                    }
                    cell.fill = {
                      type: 'pattern',
                      pattern: 'darkVertical',
                      fgColor: {argb: color}
                    };
                    row.commit();
                    cb();
                  }, function (err, result) {
                    workbook.xlsx.writeBuffer().then(function (data) {
                      var returnObj = {buffer: data};
                      if (q.teamName) {
                        returnObj.teamName = q.teamName;
                      }
                      socket.emit("sales:expenses:report:success", returnObj);
                    });
                  });
                });
              });
          })
      });
  });

  socket.on("sales:meetings:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            checkForTeamOrEmployee(data)
              .then(q => {
                var meetingsQuery = {isDeleted: false, store: store._id};
                var startDate = null;
                var endDate = null;
                if (data.date) {
                  startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day")
                } else if (data.range) {
                  startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                } else {
                  startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
                  endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
                }
                meetingsQuery.start = {
                  $lte: endDate.toISOString()
                };
                meetingsQuery.end = {
                  $gte: startDate.toISOString()
                };
                if (q && q.employees && q.employees.length > 0) {
                  meetingsQuery.employee = null;
                  if (q.employees.length == 1) {
                    meetingsQuery.employee = q.employees[0];
                  } else {
                    meetingsQuery.employee = {$in: q.employees};
                  }
                }
                Meetings.paginate(meetingsQuery, {
                  limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                  lean: true,
                  select: '_id companyName address start end status remarks title isDeleted color location contactPerson',
                  populate: [{
                    path: 'employee',
                    model: "Sales-Employee",
                    select: '_id firstName lastName email phone'
                  }]
                }).then(result => {
                  var meetings = result.docs;
                  var workbook = new Excel.Workbook();
                  workbook.creator = 'Me';
                  workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
                  workbook.modified = new Date();
                  var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
                  if (data.date) {
                    sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  } else if (data.range) {
                    startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                    endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                    sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
                  }
                  var sheet = workbook.addWorksheet(sheetName);
                  sheet.state = 'visible';
                  sheet.columns = [
                    {header: 'Status', key: 'status'},
                    {header: 'Title', key: 'title'},
                    {header: 'Company Name', key: 'companyName'},
                    {header: 'Contact Person', key: 'personName'},
                    {header: 'Contact Number', key: 'personNumber'},
                    {header: 'Address', key: 'address'},
                    {header: 'Date', key: 'date'},
                    {header: 'Time', key: 'time'},
                    {header: 'Remarks', key: 'remarks'},
                    {header: 'Location', key: 'location'},
                    {header: 'Employee Name', key: 'name'},
                    {header: 'Employee Email', key: 'email'},
                    {header: 'Employee Number', key: 'mobile'}
                  ];
                  async.each(meetings, function (row, cb) {
                    var row = sheet.addRow({
                      companyName: row.companyName,
                      name: row.employee ? (row.employee ? {formula: 'HYPERLINK("http://' + (store.domain ? store.domain : store.subdomain) + '/manage/employees/view/' + row.employee._id + '", "' + row.employee.firstName + " " + row.employee.lastName + '")'} : "-") : "-",
                      email: row.employee ? row.employee.email : "-",
                      mobile: row.employee ? row.employee.phone.number : "-",
                      personName: row.contactPerson.name,
                      personNumber: row.contactPerson.phoneNumber,
                      address: row.address,
                      date: _MOMENT(row.start).format("DD-MM-YYYY"),
                      time: _MOMENT(row.start).format("hh:mm A") + " to " + _MOMENT(row.end).format("hh:mm A"),
                      status: s.humanize(row.status),
                      remarks: row.remarks,
                      title: row.title,
                      location: row.location ? {formula: 'HYPERLINK("https://maps.google.com?q=' + row.location.coordinates.latitude + ',' + row.location.coordinates.longitude + '", "Open in Maps")'} : "-"
                    });
                    var cell = row.getCell(1);
                    var color = STATUS_COLORS.default;
                    switch (s.humanize(cell.value)) {
                      case "Pending":
                        color = STATUS_COLORS.pending;
                        break;
                      case "Hot":
                        color = STATUS_COLORS.hot;
                        break;
                      case "Cold":
                        color = STATUS_COLORS.cold;
                        break;
                      case "Not interested":
                        color = STATUS_COLORS.notInterested;
                        break;
                      case "Postponed":
                        color = STATUS_COLORS.postponed;
                        break;
                      case "Completed":
                        color = STATUS_COLORS.complete;
                        break;
                    }
                    cell.fill = {
                      type: 'pattern',
                      pattern: 'darkVertical',
                      fgColor: {argb: color}
                    };
                    row.commit();
                    cb();
                  }, function (err, result) {
                    workbook.xlsx.writeBuffer().then(function (data) {
                      var returnObj = {buffer: data};
                      if (q.teamName) {
                        returnObj.teamName = q.teamName;
                      }
                      socket.emit("sales:meetings:report:success", returnObj);
                    });
                  });
                });
              });
          });
      });
  });

  socket.on("sales:payout:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            var payoutQuery = {
              paymentType: {$in: ['paytm', 'Online', 'online & superwallet', 'online & wallet']},
              status: {$nin: ["cancelled"]},
              paymentProcessed: true,
              isDeleted: false
            };
            var startDate = null;
            var endDate = null;
            if (data.date) {
              startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
              endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
            } else if (data.range) {
              startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
              endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
            } else if (data.month) {
              startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
              endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
            }
            payoutQuery.createdAt = {
              $gte: startDate.toISOString(),
              $lte: endDate.toISOString()
            };
            if (!_HELPER.checkAddonBoolean(store, "MANAGE_TRANSACTIONS")) {
              payoutQuery.store = store._id;
            }
            Payout.paginate(payoutQuery, {
              limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
              lean: true,
              populate: [{
                path: "employee",
                model: "Sales-Employee",
                select: "_id firstName lastName email"
              }, {
                path: "store",
                model: "Store",
                select: "_id name subdomain"
              }]
            }).then(result => {
              var payout = result.docs;
              var workbook = new Excel.Workbook();
              workbook.creator = 'Me';
              workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
              workbook.modified = new Date();

              var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
              if (data.date) {
                sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
              } else if (data.range) {
                startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
              }
              var sheet = workbook.addWorksheet(sheetName);
              sheet.state = 'visible';
              sheet.columns = [
                {header: 'Order Id', key: 'orderId'},
                {header: 'Transaction Id', key: 'txnId'},
                {header: 'Payout Status', key: 'payoutStatus'},
                {header: 'Payment Gateway', key: 'gateway'},
                {header: 'Amount', key: 'amount'},
                {header: 'Store Name', key: 'store'},
                {header: 'Sub Domain', key: 'subDomain'},
                {header: 'Created At', key: 'createdAt'}
              ];
              async.each(payout, function (row, cb) {
                var row = sheet.addRow({
                  orderId: row.orderId,
                  store: row.store.name,
                  txnId: row.gateway.txnId,
                  gateway: row.gateway.name,
                  amount: row.amount,
                  subDomain: row.store.subdomain,
                  payoutStatus: s.humanize(row.payoutStatus),
                  createdAt: row.createdAt ? _MOMENT(row.createdAt).format("DD-MM-YYYY [at] hh:mm A") : "-"
                });
                var cell = row.getCell(3);
                var color = STATUS_COLORS.default;
                switch (cell.value) {
                  case "Pending":
                    color = STATUS_COLORS.pending;
                    break;
                  case "Fullfilled":
                    color = STATUS_COLORS.complete;
                    break;
                  case "Cancelled":
                    color = STATUS_COLORS.cancelled;
                    break;
                }
                cell.fill = {
                  type: 'pattern',
                  pattern: 'darkVertical',
                  fgColor: {argb: color}
                };
                row.commit();
                cb();
              }, function (err, result) {
                workbook.xlsx.writeBuffer().then(function (data) {
                  var returnObj = {buffer: data};
                  socket.emit("sales:payout:report:success", returnObj);
                });
              });
            });
          });
      });
  });

  socket.on("sales:payment-link:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            checkForTeamOrEmployee(data)
              .then(q => {
                var paymentLinkQuery = {isDeleted: false, store: store._id};
                var startDate = null;
                var endDate = null;
                if (data.date) {
                  startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
                } else if (data.range) {
                  startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                } else if (data.month) {
                  startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
                  endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
                }
                paymentLinkQuery.createdAt = {
                  $gte: startDate.toISOString(),
                  $lte: endDate.toISOString()
                };
                if (q && q.employees && q.employees.length > 0) {
                  paymentLinkQuery.employee = null;
                  if (q.employees.length == 1) {
                    paymentLinkQuery.employee = q.employees[0];
                  } else {
                    paymentLinkQuery.employee = {$in: q.employees};
                  }
                }
                PaymentLinks.paginate(paymentLinkQuery, {
                  limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                  lean: true,
                  populate: [{
                    path: "employee",
                    model: "Sales-Employee",
                    select: "_id firstName lastName email"
                  }]
                }).then(result => {
                  var paymentLinks = result.docs;
                  var workbook = new Excel.Workbook();
                  workbook.creator = 'Me';
                  workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
                  workbook.modified = new Date();
                  var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
                  if (data.date) {
                    sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  } else if (data.range) {
                    startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                    endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                    sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
                  }
                  var sheet = workbook.addWorksheet(sheetName);
                  sheet.state = 'visible';
                  sheet.columns = [
                    {header: 'Date', key: 'createdAt'},
                    {header: 'Time', key: 'createdAtTime'},
                    {header: 'Status', key: 'status'},
                    {header: 'Customer Name', key: 'name'},
                    {header: 'Email', key: 'email'},
                    {header: 'Mobile', key: 'mobile'},
                    {header: 'Description', key: 'description'},
                    {header: 'Amount', key: 'amount'},
                    {header: 'Comment', key: 'comment'},
                    {header: 'Payment Link', key: 'link'},
                    {header: 'Employee Name', key: 'employeeName'},
                    {header: 'Employee Email', key: 'employeeEmail'}
                  ];
                  async.each(paymentLinks, function (row, cb) {
                    var row = sheet.addRow({
                      name: row.name,
                      email: row.email,
                      mobile: row.mobile,
                      amount: row.amount,
                      status: s.humanize(row.status),
                      link: row.link ? {formula: 'HYPERLINK("' + (store.domain ? store.domain : store.subdomain) + '/payment/' + row.link + '", "Open in Browser")'} : "-",
                      description: row.description,
                      createdAt: row.createdAt ? _MOMENT(row.createdAt).format("DD-MM-YYYY") : "-",
                      createdAtTime: row.createdAt ? _MOMENT(row.createdAt).format("hh:mm A") : "-",
                      comment: row.comment ? row.comment : "-",
                      employeeName: row.employee ? {formula: 'HYPERLINK("http://' + (store.domain ? store.domain : store.subdomain) + '/manage/employees/view/' + row.employee._id + '", "' + row.employee.firstName + " " + row.employee.lastName + '")'} : "-",
                      employeeEmail: row.employee ? row.employee.email : "-"
                    });
                    var cell = row.getCell(3);
                    var color = STATUS_COLORS.default;
                    switch (cell.value) {
                      case "Pending":
                        color = STATUS_COLORS.pending;
                        break;
                      case "Paid":
                        color = STATUS_COLORS.paid;
                        break;
                    }
                    cell.fill = {
                      type: 'pattern',
                      pattern: 'darkVertical',
                      fgColor: {argb: color}
                    };
                    row.commit();
                    cb();
                  }, function (err, result) {
                    workbook.xlsx.writeBuffer().then(function (data) {
                      var returnObj = {buffer: data};
                      if (q.teamName) {
                        returnObj.teamName = q.teamName;
                      }
                      socket.emit("sales:payment-link:report:success", returnObj);
                    });
                  });
                });
              });
          });
      });
  });

  socket.on("sales:gps:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            var gpsQuery = {isDeleted: false, store: store._id};
            var startDate = null;
            var endDate = null;
            if (data.date) {
              startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
              endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
            } else if (data.range) {
              startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
              endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
            } else if (data.month) {
              startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
              endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
            }
            gpsQuery.createdAt = {
              $gte: startDate.toISOString(),
              $lte: endDate.toISOString()
            };
            if (!_HELPER.checkAddonBoolean(store, "MANAGE_ALL_TRANSACTIONS")) {
              gpsQuery.store = store._id;
            }
            GPS.paginate(gpsQuery, {
              limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
              lean: true,
              populate: {
                path: "employee",
                model: "Sales-Employee",
                select: "_id firstName lastName email"
              }
            }).then(result => {
              var gpsLog = result.docs;
              var workbook = new Excel.Workbook();
              workbook.creator = 'Me';
              workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
              workbook.modified = new Date();

              var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
              if (data.date) {
                sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
              } else if (data.range) {
                startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
              }
              var sheet = workbook.addWorksheet(sheetName);
              sheet.state = 'visible';
              sheet.columns = [
                {header: 'Employee Name', key: 'empName'},
                {header: 'GPS On Date', key: 'locationOnDate'},
                {header: 'GPS On Time', key: 'locationOnTime'},
                {header: 'GPS Off Date', key: 'locationOffDate'},
                {header: 'GPS Off Time', key: 'locationOffTime'},
                {header: 'Switch On Location', key: 'switchOnLocation'},
                {header: 'Switch Off Location', key: 'switchOffLocation'}
              ];
              async.each(gpsLog, function (row, cb) {
                var row = sheet.addRow({
                  empName: row.employee.firstName + " " + row.employee.lastName,
                  locationOnDate: _MOMENT(row.locationOnDate).format("DD-MM-YYYY"),
                  locationOnTime: _MOMENT(row.locationOnDate).format("hh:mm A"),
                  locationOffDate: _MOMENT(row.locationOffDate).format("DD-MM-YYYY"),
                  locationOffTime: _MOMENT(row.locationOffDate).format("hh:mm A"),
                  switchOnLocation: row.switchOnLocation ? {formula: 'HYPERLINK("https://maps.google.com?q=' + row.switchOnLocation.latitude + ',' + row.switchOnLocation.longitude + '", "' + row.switchOnLocation.address + '")'} : "-",
                  switchOffLocation: row.switchOffLocation ? {formula: 'HYPERLINK("https://maps.google.com?q=' + row.switchOffLocation.latitude + ',' + row.switchOffLocation.longitude + '", "' + row.switchOffLocation.address + '")'} : "-",
                });
                row.commit();
                cb();
              }, function (err, result) {
                workbook.xlsx.writeBuffer().then(function (data) {
                  var returnObj = {buffer: data};
                  socket.emit("sales:gps:report:success", returnObj);
                });
              });
            });
          });
      });
  });

  socket.on("sales:wifi:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            var wifiQuery = {isDeleted: false, store: store._id};
            var startDate = null;
            var endDate = null;
            if (data.date) {
              startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
              endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
            } else if (data.range) {
              startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
              endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
            } else if (data.month) {
              startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
              endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
            }
            wifiQuery.createdAt = {
              $gte: startDate.toISOString(),
              $lte: endDate.toISOString()
            };
            if (!_HELPER.checkAddonBoolean(store, "MANAGE_ALL_TRANSACTIONS")) {
              wifiQuery.store = store._id;
            }
            WiFi.paginate(wifiQuery, {
              limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
              lean: true,
              populate: {
                path: "employee",
                model: "Sales-Employee",
                select: "_id firstName lastName email"
              }
            }).then(result => {
              var WiFiLog = result.docs;
              var workbook = new Excel.Workbook();
              workbook.creator = 'Me';
              workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
              workbook.modified = new Date();

              var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
              if (data.date) {
                sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
              } else if (data.range) {
                startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
              }
              var sheet = workbook.addWorksheet(sheetName);
              sheet.state = 'visible';
              sheet.columns = [
                {header: 'Employee Name', key: 'empName'},
                {header: 'WiFi On Date', key: 'locationOnDate'},
                {header: 'WiFi On Time', key: 'locationOnTime'},
                {header: 'WiFi Off Date', key: 'locationOffDate'},
                {header: 'WiFi Off Time', key: 'locationOffTime'},
                {header: 'Switch On Location', key: 'switchOnLocation'},
                {header: 'Switch Off Location', key: 'switchOffLocation'}
              ];
              async.each(WiFiLog, function (row, cb) {
                var row = sheet.addRow({
                  empName: row.employee.firstName + " " + row.employee.lastName,
                  locationOnDate: _MOMENT(row.locationOnDate).format("DD-MM-YYYY"),
                  locationOnTime: _MOMENT(row.locationOnDate).format("hh:mm A"),
                  locationOffDate: _MOMENT(row.locationOffDate).format("DD-MM-YYYY"),
                  locationOffTime: _MOMENT(row.locationOffDate).format("hh:mm A"),
                  switchOnLocation: row.switchOnLocation ? {formula: 'HYPERLINK("https://maps.google.com?q=' + row.switchOnLocation.latitude + ',' + row.switchOnLocation.longitude + '", "' + row.switchOnLocation.address + '")'} : "-",
                  switchOffLocation: row.switchOffLocation ? {formula: 'HYPERLINK("https://maps.google.com?q=' + row.switchOffLocation.latitude + ',' + row.switchOffLocation.longitude + '", "' + row.switchOffLocation.address + '")'} : "-",
                });
                row.commit();
                cb();
              }, function (err, result) {
                workbook.xlsx.writeBuffer().then(function (data) {
                  var returnObj = {buffer: data};
                  socket.emit("sales:wifi:report:success", returnObj);
                });
              });
            });
          });
      });
  });

  socket.on("sales:payment-collection:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            checkForTeamOrEmployee(data)
              .then(q => {
                var paymentCollectionQuery = {isDeleted: false, store: store._id};
                var startDate = null;
                var endDate = null;
                if (data.date) {
                  startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
                } else if (data.range) {
                  startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                } else if (data.month) {
                  startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
                  endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
                }
                paymentCollectionQuery.createdAt = {
                  $gte: startDate.toISOString(),
                  $lte: endDate.toISOString()
                };
                if (q && q.employees && q.employees.length > 0) {
                  paymentCollectionQuery.employee = null;
                  if (q.employees.length == 1) {
                    paymentCollectionQuery.employee = q.employees[0];
                  } else {
                    paymentCollectionQuery.employee = {$in: q.employees};
                  }
                }
                PaymentCollection.paginate(paymentCollectionQuery, {
                  limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                  lean: true,
                  populate: [{
                    path: 'employee',
                    model: "Sales-Employee",
                    select: '_id firstName lastName email phone'
                  }, {
                    path: 'attachments',
                    select: '_id url'
                  }]
                }).then(result => {
                  var paymentCollection = result.docs;
                  var workbook = new Excel.Workbook();
                  workbook.creator = 'Me';
                  workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
                  workbook.modified = new Date();
                  var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
                  if (data.date) {
                    sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  } else if (data.range) {
                    startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                    endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                    sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
                  }
                  var sheet = workbook.addWorksheet(sheetName);
                  sheet.state = 'visible';
                  sheet.columns = [
                    {header: 'Company Name', key: 'companyName'},
                    {header: 'Amount', key: 'amount'},
                    {header: 'Date', key: 'dateOfPayment'},
                    {header: 'Time', key: 'timeOfPayment'},
                    {header: 'Category', key: 'category'},
                    {header: 'Comment', key: 'comment'},
                    {header: 'Note', key: 'note'},
                    {header: 'Employee Name', key: 'name'},
                    {header: 'Employee Email', key: 'email'},
                    {header: 'Employee Number', key: 'mobile'},
                    {header: 'Image', key: 'attachment'}
                  ];
                  async.each(paymentCollection, function (row, cb) {
                    sheet.addRow({
                      companyName: row.company,
                      name: row.employee ? row.employee ? {formula: 'HYPERLINK("http://' + (store.domain ? store.domain : store.subdomain) + '/manage/employees/view/' + row.employee._id + '", "' + row.employee.firstName + " " + row.employee.lastName + '")'} : "-" : "-",
                      email: row.employee ? row.employee.email : "-",
                      mobile: row.employee ? row.employee.phone.number : "-",
                      amount: row.amount,
                      dateOfPayment: _MOMENT(row.dateOfPayment).format("DD-MM-YYYY"),
                      timeOfPayment: _MOMENT(row.dateOfPayment).format("hh:mm A"),
                      category: row.category,
                      comment: row.comment,
                      note: row.note,
                      attachment: row.attachments && row.attachments.length > 0 ? {formula: 'HYPERLINK("' + row.attachments[0].url + '", "Open in Browser")'} : ""
                    }).commit();
                    cb();
                  }, function (err, result) {
                    workbook.xlsx.writeBuffer().then(function (data) {
                      var returnObj = {buffer: data};
                      if (q.teamName) {
                        returnObj.teamName = q.teamName;
                      }
                      socket.emit("sales:payment-collection:report:success", returnObj);
                    });
                  });
                });
              });
          });
      });
  });

  socket.on("sales:visitors:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            checkForTeamOrEmployee(data)
              .then(q => {
                var visitorsQuery = {isDeleted: false, store: store._id};
                var startDate = null;
                var endDate = null;
                if (data.date) {
                  startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
                } else if (data.range) {
                  startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                } else if (data.month) {
                  startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
                  endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
                }
                visitorsQuery.createdAt = {
                  $gte: startDate.toISOString(),
                  $lte: endDate.toISOString()
                };
                if (q && q.employees && q.employees.length > 0) {
                  visitorsQuery.employee = null;
                  if (q.employees.length == 1) {
                    visitorsQuery.employee = q.employees[0];
                  } else {
                    visitorsQuery.employee = {$in: q.employees};
                  }
                }
                Visitors.paginate(visitorsQuery, {

                  limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                  lean: true,
                  populate: [{
                    path: 'file',
                    model: 'PrivateFile',
                    select: '_id url'
                  }]
                }).then(result => {
                  var visitors = result.docs;
                  var workbook = new Excel.Workbook();
                  workbook.creator = 'Me';
                  workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
                  workbook.modified = new Date();
                  var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
                  if (data.date) {
                    sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  } else if (data.range) {
                    startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                    endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                    sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
                  }
                  var sheet = workbook.addWorksheet(sheetName);
                  sheet.state = 'visible';
                  sheet.columns = [
                    {header: 'Unit Number', key: 'unitNumber'},
                    {header: 'Visitor Name', key: 'name'},
                    {header: 'Mobile', key: 'mobile'},
                    {header: 'Vehicle Number', key: 'vehicleNumber'},
                    {header: 'Visitor Service', key: 'purpose'},
                    {header: 'Date', key: 'outDate'},
                    {header: 'Time', key: 'outTime'},
                    {header: 'Image', key: 'attachment'}
                  ];
                  async.each(visitors, function (row, cb) {
                    sheet.addRow({
                      unitNumber: row.unitNumber,
                      name: row.name,
                      mobile: row.mobile,
                      vehicleNumber: row.information.vehicleNumber,
                      purpose: row.information.purpose ? row.information.purpose : "-",
                      outDate: _MOMENT(row.out).format("DD-MM-YYYY"),
                      outTime: _MOMENT(row.out).format("hh:mm A"),
                      attachment: row.file && row.file.length > 0 ? {formula: 'HYPERLINK("' + row.file[0].url + '", "Open in Browser")'} : ""
                    }).commit();
                    cb();
                  }, function (err, result) {
                    workbook.xlsx.writeBuffer().then(function (data) {
                      var returnObj = {buffer: data};
                      if (q.teamName) {
                        returnObj.teamName = q.teamName;
                      }
                      socket.emit("sales:visitors:report:success", returnObj);
                    });
                  });
                });
              });
          });
      });
  });

  socket.on("sales:leave:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            checkForTeamOrEmployee(data)
              .then(q => {
                var leaveQuery = {isDeleted: false};
                var startDate = null;
                var endDate = null;
                if (data.date) {
                  startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
                } else if (data.range) {
                  startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                } else if (data.month) {
                  startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
                  endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
                }
                leaveQuery.createdAt = {
                  $gte: startDate.toISOString(),
                  $lte: endDate.toISOString()
                };
                if (q && q.employees && q.employees.length > 0) {
                  leaveQuery.employee = null;
                  if (q.employees.length == 1) {
                    leaveQuery.employee = q.employees[0];
                  } else {
                    leaveQuery.employee = {$in: q.employees};
                  }
                }
                EmployeeLeave.paginate(leaveQuery, {
                  limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                  lean: true,
                  populate: [{
                    path: "employee",
                    model: "Sales-Employee",
                    select: "_id firstName lastName email phone"
                  }]
                }).then(result => {
                  var leaves = result.docs;
                  var workbook = new Excel.Workbook();
                  workbook.creator = 'Me';
                  workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
                  workbook.modified = new Date();
                  var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
                  if (data.date) {
                    sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  } else if (data.range) {
                    startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                    endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                    sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
                  }
                  var sheet = workbook.addWorksheet(sheetName);
                  sheet.state = 'visible';
                  sheet.columns = [
                    {header: 'Type Of Leave', key: 'typeOfLeave'},
                    {header: 'From', key: 'from'},
                    {header: 'To', key: 'to'},
                    {header: 'Employee', key: 'employee'},
                    {header: 'Reason', key: 'reason'},
                    {header: 'Approved', key: 'isApproved'},
                    {header: 'Approved By', key: 'approvedBy'},
                    {header: 'Remarks', key: 'remarks'}
                  ];
                  async.each(leaves, function (row, cb) {
                    var row = sheet.addRow({
                      employee: row.employee ? {formula: 'HYPERLINK("http://' + (store.domain ? store.domain : store.subdomain) + '/manage/employees/view/' + row.employee._id + '", "' + row.employee.firstName + " " + row.employee.lastName + '")'} : "-",
                      typeOfLeave: row.typeOfLeave ? row.typeOfLeave : "-",
                      from: _MOMENT(row.dateFrom).format("DD-MM-YYYY"),
                      to: _MOMENT(row.dateTo).format("DD-MM-YYYY"),
                      isApproved: row.hasOwnProperty("isApproved") ? (row.isApproved ? "Approved" : "Disapproved") : "Pending",
                      approvedBy: row.approvedBy ? row.approvedBy : "-",
                      reason: row.reason ? row.reason : "-",
                      remarks: row.remarks ? row.remarks : "-",
                    });
                    var cell = row.getCell(6);
                    var color = STATUS_COLORS.default;
                    switch (cell.value) {
                      case "Pending":
                        color = STATUS_COLORS.pending;
                        break;
                      case "Approved":
                        color = STATUS_COLORS.approved;
                        break;
                      case "Disapproved":
                        color = STATUS_COLORS.danger;
                        break;
                    }
                    cell.fill = {
                      type: 'pattern',
                      pattern: 'darkVertical',
                      fgColor: {argb: color}
                    };
                    row.commit();
                    cb();
                  }, function (err, result) {
                    workbook.xlsx.writeBuffer().then(function (data) {
                      var returnObj = {buffer: data};
                      if (q.teamName) {
                        returnObj.teamName = q.teamName;
                      }
                      socket.emit("sales:leave:report:success", returnObj);
                    });
                  });
                });
              });
          });
      });
  });

  socket.on("sales:client:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            checkForTeamOrEmployee(data)
              .then(q => {
                var clientQuery = {isDeleted: false, store: store._id};
                var startDate = null;
                var endDate = null;
                if (data.date) {
                  startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
                } else if (data.range) {
                  startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                } else if (data.month) {
                  startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
                  endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
                }
                clientQuery.createdAt = {
                  $gte: startDate.toISOString(),
                  $lte: endDate.toISOString()
                };
                if (q && q.employees && q.employees.length > 0) {
                  clientQuery.employee = null;
                  if (q.employees.length == 1) {
                    clientQuery.employee = q.employees[0];
                  } else {
                    clientQuery.employee = {$in: q.employees};
                  }
                }
                Clients.paginate(clientQuery, {
                  limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                  lean: true,
                  populate: [{
                    path: "addedByEmployee",
                    model: "Sales-Employee",
                    select: "_id firstName lastName email phone"
                  }]
                }).then(result => {
                  var clients = result.docs;
                  var workbook = new Excel.Workbook();
                  workbook.creator = 'Me';
                  workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
                  workbook.modified = new Date();
                  var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
                  if (data.date) {
                    sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  } else if (data.range) {
                    startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                    endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                    sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
                  }
                  var sheet = workbook.addWorksheet(sheetName);
                  sheet.state = 'visible';
                  sheet.columns = [
                    {header: 'Client Name', key: 'name'},
                    {header: 'Email', key: 'email'},
                    {header: 'Mobile', key: 'mobile'},
                    {header: 'Description', key: 'description'},
                    {header: 'Address', key: 'address'},
                    {header: 'Location', key: 'location'},
                    {header: 'Employee Name', key: 'employee'},
                    {header: 'Employee Email', key: 'empEmail'},
                    {header: 'Employee Mobile', key: 'empMobile'}
                  ];
                  async.each(clients, function (row, cb) {
                    sheet.addRow({
                      name: row.name,
                      email: row.email ? row.email : "-",
                      mobile: row.mobile ? row.mobile : "-",
                      description: row.description ? row.description : "-",
                      address: row.address.address1 ? row.address.address2 : "-",
                      location: row.location ? {formula: 'HYPERLINK("https://maps.google.com?q=' + row.location.latitude + ',' + row.location.longitude + '", "Open in Maps")'} : "-",
                      employee: row.addedByEmployee ? {formula: 'HYPERLINK("http://' + (store.domain ? store.domain : store.subdomain) + '/manage/employees/view/' + row.addedByEmployee._id + '", "' + row.addedByEmployee.firstName + " " + row.addedByEmployee.lastName + '")'} : "-",
                      empEmail: row.addedByEmployee.email,
                      empMobile: row.addedByEmployee.phone.number
                    }).commit();
                    cb();
                  }, function (err, result) {
                    workbook.xlsx.writeBuffer().then(function (data) {
                      var returnObj = {buffer: data};
                      if (q.teamName) {
                        returnObj.teamName = q.teamName;
                      }
                      socket.emit("sales:client:report:success", returnObj);
                    });
                  });
                });
              });
          });
      });
  });

  socket.on("sales:attendance:emp:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            checkForTeamOrEmployee(data)
              .then(q => {
                var attendanceEmpQuery = {store: store._id, isDeleted: false};
                var startDate = null;
                var endDate = null;
                if (data.date) {
                  startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
                } else if (data.range) {
                  startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                } else if (data.month) {
                  startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
                  endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
                }
                attendanceEmpQuery.createdAt = {
                  $gte: startDate.toISOString(),
                  $lte: endDate.toISOString()
                };
                if (q && q.employees && q.employees.length > 0) {
                  attendanceEmpQuery.employee = null;
                  if (q.employees.length == 1) {
                    attendanceEmpQuery.employee = q.employees[0];
                  } else {
                    attendanceEmpQuery.employee = {$in: q.employees};
                  }
                }
                FullAttendance.paginate(attendanceEmpQuery, {
                  limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                  lean: true,
                  populate: [{
                    path: "employee",
                    model: "Sales-Employee",
                    select: "_id firstName lastName email phone"
                  }]
                }).then(result => {
                  var employees = _.map(result.docs, function (em) {
                    em.employee._id = em.employee._id + "";
                    return em.employee;
                  });
                  employees = _.uniq(employees, function (emp) {
                    return emp._id;
                  });
                  result.docs = _.map(result.docs, function (em) {
                    em.employee = em.employee._id;
                    return em;
                  });
                  var groupedbyEmployees = _.groupBy(result.docs, 'employee');
                  var employeeAndTime = [];
                  async.each(employees, function (employee, cb) {
                    var empId = employee._id;
                    var times = [];
                    for (var i = 0; i < groupedbyEmployees[empId].length; i++) {
                      var slot = groupedbyEmployees[empId][i];
                      var nextSlot = groupedbyEmployees[empId][i + 1];
                      if (slot.isStart && nextSlot) {
                        var start = _MOMENT(slot.createdAt);
                        var end = _MOMENT(nextSlot.createdAt);
                        var duration = _MOMENT.duration(end.diff(start));
                        var hours = parseInt(duration.asHours());
                        var minutes = parseInt(duration.asMinutes()) % 60;
                        times.push(hours + ":" + minutes);
                      }
                    }
                    var time = _.reduce(times, function (time1, time2) {
                      return addTimes(time1, time2);
                    });
                    employeeAndTime.push(_.extend(employee, {
                      time: time
                    }));
                    cb();
                  }, function (err, result) {
                    var workbook = new Excel.Workbook();
                    workbook.creator = 'Me';
                    workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
                    workbook.modified = new Date();
                    var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
                    if (data.date) {
                      sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                    } else if (data.range) {
                      startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                      endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                      sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
                    }
                    var sheet = workbook.addWorksheet(sheetName);
                    sheet.state = 'visible';
                    sheet.columns = [
                      {header: 'Employee', key: 'employee'},
                      {header: 'Email', key: 'email'},
                      {header: 'Mobile', key: 'mobile'},
                      {header: 'Total Hours', key: 'time'}
                    ];
                    async.each(employeeAndTime, function (row, cb) {
                      sheet.addRow({
                        employee: row.firstName + " " + row.lastName,
                        email: row.email ? row.email : "-",
                        mobile: row.phone.number ? row.phone.number : "-",
                        time: row.time
                      }).commit();
                      cb();
                    }, function (err, result) {
                      workbook.xlsx.writeBuffer().then(function (data) {
                        var returnObj = {buffer: data};
                        if (q.teamName) {
                          returnObj.teamName = q.teamName;
                        }
                        socket.emit("sales:attendance:emp:report:success", returnObj);
                      });
                    });
                  });
                });
              });
          });
      });
  });

  socket.on("sales:subscription:report", function (data) {
    _HELPER.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        _HELPER.getStore(socket)
          .then(store => {
            checkForTeamOrEmployee(data)
              .then(q => {
                var subscriptionQuery = {store: store._id, isDeleted: false};
                var startDate = null;
                var endDate = null;
                if (data.date) {
                  startDate = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.date, "DD-MM-YYYY").endOf("day");
                } else if (data.range) {
                  startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                  endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                } else if (data.month) {
                  startDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").startOf("month");
                  endDate = _MOMENT("01-" + data.month + "-" + data.year, "DD-MM-YYYY").endOf("month");
                }
                subscriptionQuery.createdAt = {
                  $gte: startDate.toISOString(),
                  $lte: endDate.toISOString()
                };
                if (q && q.employees && q.employees.length > 0) {
                  subscriptionQuery.employee = null;
                  if (q.employees.length == 1) {
                    subscriptionQuery.employee = q.employees[0];
                  } else {
                    subscriptionQuery.employee = {$in: q.employees};
                  }
                }
                Subscription.paginate(subscriptionQuery, {
                  limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
                  lean: true,
                  populate: [{
                    path: 'customer',
                    model: "Customer",
                    select: "_id firstName lastName  mobile email"
                  }, {
                    path: 'type',
                    model: "CustomerGroup",
                    select: "_id name"
                  }]
                }).then(result => {
                  var membership = result.docs;
                  var workbook = new Excel.Workbook();
                  workbook.creator = 'Me';
                  workbook.created = new Date(_MOMENT().format("YYYY"), _MOMENT().format("MM"), _MOMENT().format("DD"));
                  workbook.modified = new Date();
                  var sheetName = startDate.format("MMMM") + " " + startDate.format("YYYY");
                  if (data.date) {
                    sheetName = _MOMENT(data.date, "DD-MM-YYYY").startOf("day");
                  } else if (data.range) {
                    startDate = _MOMENT(data.range.from, "DD-MM-YYYY").startOf("day");
                    endDate = _MOMENT(data.range.to, "DD-MM-YYYY").endOf("day");
                    sheetName = startDate.format("DD-MM-YYYY") + " - " + endDate.format("DD-MM-YYYY");
                  }
                  var sheet = workbook.addWorksheet(sheetName);
                  sheet.state = 'visible';
                  sheet.columns = [
                    {header: 'Customer', key: 'name'},
                    {header: 'Mobile', key: 'mobile'},
                    {header: 'Email', key: 'email'},
                    {header: 'Type', key: 'customerGroup'},
                    {header: 'Purchase Date', key: 'purchaseDate'},
                    {header: 'Expiry Date', key: 'expiryDate'},
                    {header: 'Status', key: 'status'}
                  ];
                  async.each(membership, function (row, cb) {
                    sheet.addRow({
                      name: row.customer.firstName + " " + row.customer.lastName,
                      mobile: row.customer.mobile ? row.customer.mobile : "-",
                      email: row.customer.email ? row.customer.email : "-",
                      customerGroup: row.type.name,
                      purchaseDate: _MOMENT(row.createdAt).format("DD-MM-YYYY"),
                      expiryDate: _MOMENT(row.validity).format("DD-MM-YYYY"),
                      status: _MOMENT().diff(_MOMENT(row.validity)) > 0 ? "Expired" : "Valid"
                    }).commit();
                    cb();
                  }, function (err, result) {
                    workbook.xlsx.writeBuffer().then(function (data) {
                      var returnObj = {buffer: data};
                      if (q.teamName) {
                        returnObj.teamName = q.teamName;
                      }
                      socket.emit("sales:subscription:report:success", returnObj);
                    });
                  });
                });
              });
          });
      });
  });

  function addTimes(startTime, endTime) {
    var times = [0, 0, 0]
    var max = times.length

    var a = (startTime || '').split(':')
    var b = (endTime || '').split(':')

    // normalize time values
    for (var i = 0; i < max; i++) {
      a[i] = isNaN(parseInt(a[i])) ? 0 : parseInt(a[i])
      b[i] = isNaN(parseInt(b[i])) ? 0 : parseInt(b[i])
    }

    // store time values
    for (var i = 0; i < max; i++) {
      times[i] = a[i] + b[i]
    }

    var hours = times[0]
    var minutes = times[1]


    if (minutes >= 60) {
      var h = (minutes / 60) << 0
      hours += h
      minutes -= 60 * h
    }

    return ('0' + hours).slice(-2) + ':' + ('0' + minutes).slice(-2)
  }
};