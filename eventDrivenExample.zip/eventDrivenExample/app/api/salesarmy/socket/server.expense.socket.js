'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  FileUploader = require("../../app/api/shared/file.uploader"),
  Expenses = require('../api/models/server.expenses.model');

module.exports.listen = function (io, socket) {

  socket.on("sales:expense:get", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 0 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {dateOfExpense: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true
              };
              var qf = {store: store._id, isDeleted: false, employee: data.filters.employee || response.user._id};
              if (data.expenseId) {
                qf._id = data.expenseId;
                options.populate = [{
                  path: "attachments",
                  model: "PrivateFile",
                  select: '_id metadata fileId url store'
                }];
              }
              if (data.filters && data.filters.searchText && data.filters.searchText.length > 0) {
                qf['$or'] = [];
                qf['$or'].push({'company': {'$regex': data.filters.searchText, '$options': 'i'}});
                qf['$or'].push({'category': {'$regex': data.filters.searchText, '$options': 'i'}});
              }
              if (data.filters && data.filters.start && data.filters.end) {
                qf["createdAt"] = {
                  $gte: new Date(_MOMENT(data.filters.start).startOf('day')),
                  $lte: new Date(_MOMENT(data.filters.end).endOf('day'))
                };
              }
              Expenses.paginate(qf, options).then(function (documents) {
                Helper.sendSocketResponse(socket, scb, documents, {event: "sales:expense:get:success"});
              });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:expense:get:error"});
            }
          });
      });
  });

  socket.on("sales:expense:add", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.expense) {
              FileUploader.uploadMultipleFile(data.expense.attachments, store, false)
                .then(d => {
                  data.expense.attachments = d.idList;
                  if (data.expense._id) {
                    Expenses.findOneAndUpdate({
                      _id: data.expense._id,
                      store: store._id,
                      isDeleted: false
                    }, data.expense, {new: true})
                      .then(exp => {
                        Helper.sendSocketResponse(socket, scb, exp, {event: "sales:expense:add:success"});
                      }).catch(err => {
                      _logger.error(err);
                      Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:expense:add:error"});
                    });
                  } else {
                    data.expense.store = store._id;
                    data.expense.employee = response.user._id;
                    Expenses.create(data.expense)
                      .then(exp => {
                        Helper.sendSocketResponse(socket, scb, exp, {event: "sales:expense:add:success"});
                      }).catch(err => {
                      _logger.error(err);
                      Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:expense:add:error"});
                    });
                  }
                });
            }
          });
      });
  });

  socket.on("sales:expense:delete", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Expenses.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isDeleted: true}, {new: true})
                .then(exp => {
                  Helper.sendSocketResponse(socket, scb, exp, {event: "sales:expense:delete:success"});
                });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:expense:delete:error"});
            }
          });
      });
  });

  socket.on("sales:expense:approve", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Expenses.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isApproved: data.isApproved, comment: data.comment}, {new: true})
                .then(exp => {
                  Helper.sendSocketResponse(socket, scb, exp, {event: "sales:expense:approve:success"});
                });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:expense:approve:error"});
            }
          });
      });
  });

  socket.on("employee:expense:availability", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        var query = {
          employee: data.employee || response.user._id,
          createdAt: {
            $gte: _MOMENT(data.start).startOf("day").toISOString(),
            $lte: _MOMENT(data.end).endOf("day").toISOString()
          },
          isDeleted: false
        };
        Expenses.paginate(query, {
          lean: true,
          limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
          select: 'createdAt _id'
        }).then(function (res) {
          if (res.docs && res.docs.length > 0) {
            var returnObj = _.uniq(_.map(res.docs, function (d) {
              return _MOMENT(d.createdAt).format("DD/MM/YYYY");
            }));
            Helper.sendSocketResponse(socket, scb, returnObj, {event: "employee:expense:availability:success"});
          } else {
            Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:expense:availability:error"});
          }
        }).catch(function (err) {
          _logger.error(err);
          Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:expense:availability:error"});
        });
      });
  });
};