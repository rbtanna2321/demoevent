'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  Orders = require('../../app/api/models/server.order.model'),
  Package = require('../../app/api/models/server.store.package.model'),
  Address = require('../../app/api/models/server.address.model'),
  Store = require('../../app/api/models/server.store.model'),
  async = require('async'),
  BankDetail = require('../../app/api/models/server.bank.detail.model');

module.exports.listen = function (io, socket) {

  socket.on("manage:transaction:update", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (Helper.checkAddonBoolean(store, "MANAGE_TRANSACTIONS")) {
              if (data._id) {
                Orders.findOneAndUpdate({
                  _id: data._id
                }, {$set: {payoutStatus: data.status}}, {new: true})
                  .then(exp => {
                    socket.emit("manage:transaction:update:success", exp);
                  });
              } else {
                socket.emit("manage:transaction:update:error", {message: "Something went wrong. Please try again later."});
              }
            }
          });
      });
  });

  socket.on("manage:transaction:details", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        if (data._id) {
          BankDetail.findOne({store: data._id, isDeleted: false})
            .then(bank => {
              socket.emit("manage:transaction:details:success", bank);
            })
        } else {
          socket.emit("manage:transaction:details:error", {message: "Something went wrong. Please try again later."});
        }
      });
  });

  socket.on("sales:store:update", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (Helper.checkAddonBoolean(store, "MANAGE_STORES")) {
              var addressId = null;
              var addressTask = function (cb) {
                var addressObject = {
                  address1: data.address.address1,
                  address2: data.address.address2,
                  zip: data.address.zip,
                  country: data.address.country,
                  state: data.address.state,
                  city: data.address.city,
                };
                if (data.address._id) {
                  Address.findOneAndUpdate({_id: data.address._id, isDeleted: false}, addressObject)
                    .then(r => {
                      addressId = r._id;
                      cb(null, r);
                    })
                } else {
                  Address.create(addressObject)
                    .then(r => {
                      addressId = r._id;
                      cb(null, r);
                    })
                }
              };
              var packageTask = function (cb) {
                if (data.package._id) {
                  Package.findOneAndUpdate({_id: data.package._id, isDeleted: false}, {
                    $set: {
                      modules: data.package.modules,
                      addOns: data.package.addOns,
                      expiresAt: data.package.expiresAt
                    }
                  })
                    .then(r => {
                      cb(null, r);
                    })
                } else {
                  cb(null);
                }
              };
              async.parallel([addressTask, packageTask], function (err, result) {
                var updateObject = {
                  name: data.name,
                  domain: data.domain,
                  subdomain: data.subdomain,
                  hostname: data.hostname && _.isArray(data.hostname) ? data.hostname : (data.hostname.indexOf(",") ? data.hostname.split(",") : [data.hostname]),
                  mobileAppId: data.mobileAppId,
                  address: addressId,
                  settings: data.settings
                };
                Store.findOneAndUpdate({_id: data._id}, {$set: updateObject}, {new: true})
                  .then(store => {
                    Helper.clearFromRedisPromised(store);
                    socket.emit("sales:store:update:success", {});
                  });
              });
            }
          });
      });
  });
};