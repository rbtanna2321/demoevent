'use strict';
var DISTRIBUTOR = require("../socket/shared/server.socket.events").DISTRIBUTOR,
  Helper = require("../../app/api/shared/server.helper.js"),
  Employee = require('../api/models/server.distributor.model'),
  Controller = require('../api/controllers/server.distributor.controller'),
  DISTRIBUTOR_KEYS = require('../api/shared/server.filter.keys').feed;

module.exports.listen = function (io, socket) {

  socket.on(DISTRIBUTOR.ADD.EVENT, function (data, scb) {
    Helper.checkEmployeeAccess(socket, data.auth, DISTRIBUTOR_KEYS.add)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            var req = {
              body: data.distributor,
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : DISTRIBUTOR_KEYS.view.guest.keys
            };
            data.filters = data.filters || {};
            data.distributor.store = store._id;
            store.domain = store.domain ? store.domain : store.subdomain;
            Controller.add(req)
              .then(distributor => {
                Helper.sendSocketResponse(socket, scb, distributor, {event: DISTRIBUTOR.ADD.SUCCESS});
              })
              .catch(error => {
                if (error) {
                  _logger.error(error);
                  Helper.sendSocketErrorResponse(socket, scb, "Error occurred while adding distributor", {event: DISTRIBUTOR.ADD.ERROR});
                }
              });
          });
      });
  });

  socket.on(DISTRIBUTOR.GET_ALL.EVENT, function (data, scb) {
    Helper.checkEmployeeAccess(socket, data.auth, DISTRIBUTOR_KEYS.view)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.filters = data.filters || {};
            data.filters.store = store._id;
            var req = {
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : DISTRIBUTOR_KEYS.view.guest.keys
            };
            Controller.getAll(req)
              .then(function (body) {
                Helper.sendSocketResponse(socket, scb, body, {event: DISTRIBUTOR.GET_ALL.SUCCESS});
              })
              .catch(function (error) {
                if (error) {
                  _logger.error(error);
                  Helper.sendSocketErrorResponse(socket, scb, "Error occurred while getting a list of distributors", {event: DISTRIBUTOR.GET_ALL.ERROR});
                }
              })
          });
      });
  });


  socket.on(DISTRIBUTOR.GET_ALL_DISTRIBUTORS.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, DISTRIBUTOR_KEYS.view)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.filters = data.filters || {};
            data.filters.store = store._id;
            var req = {
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : DISTRIBUTOR_KEYS.view.guest.keys
            };
            Controller.getAllDistributors(req)
              .then(function (body) {
                socket.emit(DISTRIBUTOR.GET_ALL_DISTRIBUTORS.SUCCESS, body);
              })
              .catch(function (error) {
                if (error) {
                  _logger.error(error);
                  socket.emit(DISTRIBUTOR.GET_ALL_DISTRIBUTORS.ERROR, "error occurred while getting a list of distributors");
                }
              })
          });
      });
  });
  socket.on(DISTRIBUTOR.GET.EVENT, (data) => {
    Helper.getStore(socket)
      .then(store => {
        var req = {
          body: data,
          // store : store._id,
          query: Helper.createQueryString(socket, data.filters)
        };
        Controller.get(req).then(res => {
          if (res == false) {
            socket.emit(DISTRIBUTOR.GET.ERROR, "Error occurred while getting a Employee with Id: " + data._id);
          } else {
            socket.emit(DISTRIBUTOR.GET.SUCCESS, res);
          }
        }).catch(error => {
          if (error) {
            _logger.error(error);
            socket.emit(DISTRIBUTOR.GET.ERROR, "Error occurred while getting a Employee with Id: " + data._id);
          }
        });
      })
  });

  socket.on(DISTRIBUTOR.UPDATE.EVENT, function (data, scb) {
    Helper.checkEmployeeAccess(socket, data.auth, DISTRIBUTOR_KEYS.update)
      .then(response => {
        var req = {
          body: data.distributor,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : DISTRIBUTOR_KEYS.view.guest.keys
        };
        Controller.update(req)
          .then(distributor => {
            Helper.sendSocketResponse(socket, scb, distributor, {event: DISTRIBUTOR.UPDATE.SUCCESS});
            return false;
          })
          .catch(error => {
            if (error) {
              _logger.error(error);
              Helper.sendSocketErrorResponse(socket, scb, "Error occurred while updating Employee with ID: " + data.distributor._id, {event: DISTRIBUTOR.UPDATE.ERROR});
              socket.emit(DISTRIBUTOR.UPDATE.ERROR, "Error occurred while updating Employee with ID: " + data.distributor._id);
            }
          });
      });
  });

  socket.on(DISTRIBUTOR.DELETE.EVENT, function (data, scb) {
    Helper.checkEmployeeAccess(socket, data.auth, DISTRIBUTOR_KEYS.delete)
      .then(response => {
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : DISTRIBUTOR_KEYS.view.guest.keys
        };
        Controller.delete(req)
          .then(distributor => {
            Helper.sendSocketResponse(socket, scb, distributor, {event: DISTRIBUTOR.DELETE.SUCCESS});
          }).catch(error => {
          if (error) {
            _logger.error(error);
            Helper.sendSocketErrorResponse(socket, scb, "Error occurred while deleting distributor with Id: " + data._id, {event: DISTRIBUTOR.DELETE.ERROR});
          }
        });
      });
  });

  socket.on(DISTRIBUTOR.DELETE.MULTIPLE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, DISTRIBUTOR_KEYS.delete)
      .then(response => {
        Employee.updateAsync({_id: {$in: data.ids}}, {$set: {isDeleted: true}}, {multi: true})
          .then(function () {
            socket.emit(DISTRIBUTOR.DELETE.MULTIPLE.SUCCESS, "Customer Deleted Successfully.");
          })
          .catch(function (error) {
            _logger.error(error);
            socket.emit(DISTRIBUTOR.DELETE.MULTIPLE.ERROR, "Error occurred while deleting customer ");
          });
      });
  });


  socket.on(DISTRIBUTOR.GET_NEAR_BY.EVENT, (data) => {
    var req = {
      body: data,
      query: Helper.createQueryString(socket, data.filters)
    };
    Controller.getNearBy(req).then(res => {
      socket.emit(DISTRIBUTOR.GET_NEAR_BY.SUCCESS, res);
    }).catch(error => {
      if (error) {
        _logger.error(error);
        socket.emit(DISTRIBUTOR.GET_NEAR_BY.ERROR, "Invalid Polygon data. Check if loop is valid or not.");
      }
    });
  });
};