'use strict';
var EMPLOYEE = require("../socket/shared/server.socket.events").EMPLOYEE,
  Helper = require("../../app/api/shared/server.helper.js"),
  async = require("async"),
  mongoose = require("mongoose"),
  Meeting = require('../api/models/server.meeting.model'),
  Employee = require('../api/models/server.employee.model'),
  History = require('../api/models/server.history.model'),
  Orders = require('../api/models/server.bulk.order.model'),
  Controller = require('../api/controllers/server.employee.controller'),
  XlsxStreamReader = require("xlsx-stream-reader"),
  EMPLOYEE_KEYS = require('../api/shared/server.filter.keys').feed,
  Notification = require('../../app/api/shared/server.push.notification.helper'),
  StaffMemberHelper = require('../../app/api/shared/server.staff.member.helper');

module.exports.listen = function (io, socket) {

  socket.on(EMPLOYEE.ADD.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, {}, EMPLOYEE_KEYS.add)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.filters = data.filters || {};
            data.employee.store = store._id;
            store.domain = store.domain ? store.domain : store.subdomain;
            data.employee.store = store._id;
            data.employee.username = data.employee.email;
            if (response.user._id == store.owner._id) {
              data.employee.roles = ["owner"];
            }
            if (data.employee.type) {
              data.employee.roles = data.employee.roles || [];
              switch (data.employee.type) {
                case "sales":
                  data.employee.roles.push("sales");
                  break;
                case "support":
                  data.employee.roles.push("support");
                  break;
                case "service":
                  data.employee.roles.push("service");
                  break;
              }
              delete data.employee.type;
            }
            if (_.isString(data.employee.phone)) data.employee.phone = {number: data.employee.phone};
            var options = {
              limit: 1,
              lean: true,
              select: '-password -salt -createdAt -updatedAt -__v -username -pwdRecoveryId -invitationId -isDeleted -chatAlert -devices -addresses -notificationHistories -promotionalNotifications -roles -store'
            };
            var qf = {store: store._id, isDeleted: false};
            Employee.paginate(qf, options).then(function (documents) {
              if (store.settings.salesarmy.limitations && store.settings.salesarmy.limitations.employee.total > documents.total) {
                StaffMemberHelper.createEmployee(data.employee)
                  .then(function (seller) {
                    socket.emit(EMPLOYEE.ADD.SUCCESS, {});
                  }).catch(err => {
                  socket.emit(EMPLOYEE.ADD.ERROR, {message: "Something went wrong. Please try again."});
                });
              } else {
                socket.emit(EMPLOYEE.ADD.ERROR, {message: "You dont have required number of licenses. Please contact your Salesarmy Account Manager."});
              }
            });
          });
      });
  });

  socket.on(EMPLOYEE.GET_ALL.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, EMPLOYEE_KEYS.view)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.filters = data.filters || {};
            data.filters.store = store._id;
            var req = {
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : EMPLOYEE_KEYS.view.guest.keys
            };
            Controller.getAll(req)
              .then(function (body) {
                socket.emit(EMPLOYEE.GET_ALL.SUCCESS, body);
              })
              .catch(function (error) {
                if (error) {
                  _logger.error(error);
                  socket.emit(EMPLOYEE.GET_ALL.ERROR, "error occurred while getting a list of employees");
                }
              })
          });
      });
  });

  socket.on(EMPLOYEE.GET.EVENT, (data, scb) => {
    var req = {
      body: data,
      query: Helper.createQueryString(socket, data.filters)
    };
    Controller.get(req).then(res => {
      if (res == false) {
        Helper.sendSocketErrorResponse(socket, scb, {message: "Error occurred. Please try again later."}, {event: EMPLOYEE.GET.ERROR});
      } else {
        Helper.sendSocketResponse(socket, scb, res, {event: EMPLOYEE.GET.SUCCESS});
      }
    }).catch(error => {
      if (error) {
        _logger.error(error);
        Helper.sendSocketErrorResponse(socket, scb, {message: "Error occurred. Please try again later."}, {event: EMPLOYEE.GET.ERROR});
      }
    });
  });

  socket.on(EMPLOYEE.UPDATE.EVENT, function (data, scb) {
    Helper.checkEmployeeAccess(socket, data.auth, EMPLOYEE_KEYS.update)
      .then(response => {
        if (_.isString(data.employee.phone)) data.employee.phone = {number: data.employee.phone};
        var req = {
          body: data.employee,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : EMPLOYEE_KEYS.view.guest.keys
        };
        Controller.update(req)
          .then(employee => {
            if (employee && employee.changedIMEI) {
              if (!_.isUndefined(io.sockets.adapter.rooms[employee._id + ":service"]) || (io.sockets.adapter.rooms[employee._id + ":service"] && io.sockets.adapter.rooms[employee._id + ":service"].length === 1)) {
                io.sockets.in(employee._id + ":service").emit("location:updates:start", {type: "logout"});
              } else if (_.isUndefined(io.sockets.adapter.rooms[employee._id + ":location"]) || (io.sockets.adapter.rooms[employee._id + ":location"] && io.sockets.adapter.rooms[employee._id + ":location"].length === 0)) {
                Notification.send({
                  notification: {
                    to: employee._id + "",
                    type: "logout"
                  }
                });
              }
            }
            Helper.sendSocketResponse(socket, scb, employee, {event: EMPLOYEE.UPDATE.SUCCESS});
            return false;
          })
          .catch(error => {
            if (error) {
              _logger.error(error);
              Helper.sendSocketErrorResponse(socket, scb, "Error occurred while updating Employee with ID: " + data.employee._id, {event: EMPLOYEE.UPDATE.ERROR});
            }
          });
      });
  });

  socket.on(EMPLOYEE.DELETE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, EMPLOYEE_KEYS.delete)
      .then(response => {
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : EMPLOYEE_KEYS.view.guest.keys
        };
        Controller.delete(req)
          .then(employee => {
            if (employee) {
              if (employee && employee.changedIMEI) {
                if (!_.isUndefined(io.sockets.adapter.rooms[employee._id + ":service"]) || (io.sockets.adapter.rooms[employee._id + ":service"] && io.sockets.adapter.rooms[employee._id + ":service"].length === 1)) {
                  io.sockets.in(employee._id + ":service").emit("location:updates:start", {type: "logout"});
                } else if (_.isUndefined(io.sockets.adapter.rooms[employee._id + ":location"]) || (io.sockets.adapter.rooms[employee._id + ":location"] && io.sockets.adapter.rooms[employee._id + ":location"].length === 0)) {
                  Notification.send({
                    notification: {
                      to: employee._id + "",
                      type: "logout"
                    }
                  });
                }
              }
            }
            socket.emit(EMPLOYEE.DELETE.SUCCESS, employee);
          }).catch(error => {
          if (error) {
            _logger.error(error);
            socket.emit(EMPLOYEE.DELETE.ERROR, "Error occurred while deleting employee with Id: " + data._id);
          }
        });
      });
  });

  socket.on(EMPLOYEE.DELETE.MULTIPLE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, EMPLOYEE_KEYS.delete)
      .then(response => {
        Employee.updateAsync({_id: {$in: data.ids}}, {$set: {isDeleted: true}}, {multi: true})
          .then(function () {
            socket.emit(EMPLOYEE.DELETE.MULTIPLE.SUCCESS, "Customer Deleted Successfully.");
          })
          .catch(function (error) {
            _logger.error(error);
            socket.emit(EMPLOYEE.DELETE.MULTIPLE.ERROR, "Error occurred while deleting customer ");
          });
      });
  });

  socket.on("employee:stats", function (data) {
    var tasks = [];
    var returnObj = {
      numberOfMeetingThisMonth: 0,
      numberOfMeetingLastMonth: 0,
      momMeetinggrowth: 0,
      momKmsgrowth: 0,
      distanceTravelledThisMonth: 0,
      distanceTravelledLastMonth: 0,
      momEarningsgrowth: 0,
      earningThisMonth: 0,
      earningLastMonth: 0
    };
    var meetingTask = function (cb) {
      var meetingsThisMonth = function (callback) {
        Meeting.countDocuments({
          employee: data.employee,
          time: {$gte: _MOMENT().startOf('month'), $lte: _MOMENT().endOf('month')}
        }).then(data => {
          returnObj.numberOfMeetingThisMonth = data;
          callback(null, data);
        });
      };
      var meetingsLastMonth = function (callback) {
        Meeting.countDocuments({
          employee: data.employee,
          time: {
            $gte: _MOMENT().subtract(1, 'month').startOf('month'),
            $lte: _MOMENT().subtract(1, 'month').endOf('month')
          }
        }).then(data => {
          returnObj.numberOfMeetingLastMonth = data;
          callback(null, data);
        });
      };
      async.parallel([meetingsThisMonth, meetingsLastMonth], function (err, result) {
        returnObj.momMeetinggrowth = Math.abs((returnObj.numberOfMeetingLastMonth - returnObj.numberOfMeetingThisMonth) / returnObj.numberOfMeetingThisMonth * 100);
        if (!isFinite(returnObj.momMeetinggrowth)) {
          returnObj.momMeetinggrowth = 0;
        }
        cb(null, {});
      });
    };
    tasks.push(meetingTask);
    var kmstravelledTask = function (cb) {
      var kmsTravelledThisMonth = function (callback) {
        History.aggregate([
          {
            $match: {
              month: parseInt(_MOMENT().format("M")),
              year: parseInt(_MOMENT().format("YYYY")),
              employee: mongoose.Types.ObjectId(data.employee)
            }
          }, {
            $group: {
              _id: {
                month: {$month: "$createdAt"},
              }, distanceTravelled: {$sum: "$distanceTravelled"}
            }
          }])
          .then(re => {
            if (re && re.length > 0) {
              returnObj.distanceTravelledThisMonth = re[0].distanceTravelled
            }
            callback(null, re);
          });
      };
      var kmsTravelledLastMonth = function (callback) {
        History.aggregate([
          {
            $match: {
              month: parseInt(_MOMENT().subtract(1, 'month').format("M")),
              year: parseInt(_MOMENT().format("YYYY")),
              employee: mongoose.Types.ObjectId(data.employee)
            }
          }, {
            $group: {
              _id: {
                month: {$month: "$createdAt"},
              }, distanceTravelled: {$sum: "$distanceTravelled"}
            }
          }])
          .then(re => {
            if (re && re.length > 0) {
              returnObj.distanceTravelledLastMonth = re[0].distanceTravelled
            }
            callback(null, re);
          });
      };
      async.parallel([kmsTravelledThisMonth, kmsTravelledLastMonth], function (err, result) {
        returnObj.momKmsgrowth = Math.abs((returnObj.distanceTravelledLastMonth - returnObj.distanceTravelledThisMonth) / returnObj.distanceTravelledThisMonth * 100);
        if (!isFinite(returnObj.momKmsgrowth)) {
          returnObj.momKmsgrowth = 0;
        }
        cb(null, {});
      });
    };
    tasks.push(kmstravelledTask);
    var earningsTask = function (cb) {
      var EarningsThisMonth = function (callback) {
        Orders.aggregate([
          {
            $match: {
              createdAt: {
                $gte: new Date(_MOMENT().startOf('month').format()),
                $lte: new Date(_MOMENT().endOf('month').format())
              },
              isDeleted: false,
              employee: mongoose.Types.ObjectId(data.employee)
            }
          }, {
            $group: {
              _id: {
                month: {$month: "$createdAt"},
              }, total: {$sum: "$total"}
            }
          }])
          .then(re => {
            if (re && re.length > 0) {
              returnObj.earningThisMonth = re[0].total
            }
            callback(null, re);
          });
      };
      var EarningsLastMonth = function (callback) {
        Orders.aggregate([
          {
            $match: {
              createdAt: {
                $gte: new Date(_MOMENT().subtract(1, 'month').startOf('month').format()),
                $lte: new Date(_MOMENT().subtract(1, 'month').endOf('month').format())
              },
              isDeleted: false,
              employee: mongoose.Types.ObjectId(data.employee)
            }
          }, {
            $group: {
              _id: {
                month: {$month: "$createdAt"},
              }, total: {$sum: "$total"}
            }
          }])
          .then(re => {
            if (re && re.length > 0) {
              returnObj.earningLastMonth = re[0].total
            }
            callback(null, re);
          });
      };
      async.parallel([EarningsThisMonth, EarningsLastMonth], function (err, result) {
        returnObj.momEarningsgrowth = Math.abs((returnObj.earningLastMonth - returnObj.earningThisMonth) / returnObj.earningThisMonth * 100);
        if (!isFinite(returnObj.momEarningsgrowth)) {
          returnObj.momEarningsgrowth = 0;
        }
        cb(null, {});
      });
    };
    tasks.push(earningsTask);
    async.parallel(tasks, function (err, result) {
      socket.emit("employee:stats:success", returnObj);
    })
  });
  var stream = require('stream');
  socket.on("sales:employee:import", function (data, scb) {
    Helper.checkEmployeeAccess(socket, data.auth, EMPLOYEE_KEYS.delete)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data && data.buffer && data.buffer.length > 0 && data.metadata && data.metadata.size && ((data.metadata.size / 1024) / 1024) < _CONFIG.MEDIA.MAX_LIMIT) {
              var bufferStream = new stream.PassThrough();
              data.buffer = Buffer.from(data.buffer, 'base64');
              bufferStream.end(data.buffer);
              var workBookReader = new XlsxStreamReader();
              workBookReader.on('error', function (error) {
                socket.emit("sales:employee:import:error", {});
              });
              workBookReader.on('worksheet', function (workSheetReader) {
                if (workSheetReader.id > 1) {
                  workSheetReader.skip();
                  return;
                }
                var rows = [];
                var sampleObject = {};
                workSheetReader.on('row', function (row) {
                  if (row.attributes.r == 1) {
                    row.values.forEach(function (rowVal, colNum) {
                      sampleObject[colNum] = {column: rowVal, value: null};
                    });
                  } else {
                    var r = new Employee();
                    row.values.forEach(function (rowVal, colNum) {
                      r = r || new Employee();
                      switch (sampleObject[colNum].column.toLowerCase()) {
                        case "firstname" :
                          r.firstName = rowVal;
                          break;
                        case "lastname":
                          r.lastName = rowVal;
                          break;
                        case "email":
                          r.email = rowVal;
                          break;
                        case "mobile":
                          r.phone = r.phone || {};
                          r.phone.number = rowVal;
                          break;
                        case "password":
                          r.setPassword(rowVal);
                          break;
                        case "gender":
                          r.gender = rowVal;
                          break;
                        case "deviceid":
                          r.imei = rowVal;
                          break;
                        case "role":
                          r.roles = _.union(["sales", "hr", "support", "service"].indexOf(rowVal) > -1 ? [rowVal] : ["sales"], ['employee']);
                          break;
                      }
                      r.store = store._id;
                    });
                    if (r.phone && r.phone.number && r.phone.number.length > 0) {
                      rows.push(r);
                    }
                  }
                });
                workSheetReader.on('end', function () {
                  console.log("r", rows);
                  var employeesToCreate = [];
                  async.each(rows, function (r, cb) {
                    Employee.findOne({
                      email: r.email,
                      'phone.number': r.phone.number,
                      isDeleted: false,
                      store: store._id
                    }).then(pr => {
                        if (!_.isNull(pr) && pr.email && pr.email.length > 0 && pr.phone && pr.phone.number && pr.phone.number.length > 0) {
                          pr.firstName = r.firstName;
                          pr.lastName = r.lastName;
                          pr.email = r.email;
                          pr.phone = r.phone || {};
                          pr.phone.number = r.phone.number;
                          pr.password = r.password;
                          pr.salt = r.salt;
                          pr.gender = r.gender;
                          pr.imei = r.imei;
                          pr.roles = r.roles;
                          pr.save();
                        } else {
                          if (r.email && r.email.length > 0 && r.phone && r.phone.number && r.phone.number.length > 0) {
                            employeesToCreate.push(r);
                          }
                        }
                        cb();
                      });
                  }, function (err, result) {
                    if (employeesToCreate.length > 0) {
                      var options = {
                        limit: 0,
                        lean: true,
                        select: '-password -salt -createdAt -updatedAt -__v -username -pwdRecoveryId -invitationId -isDeleted -chatAlert -devices -addresses -notificationHistories -promotionalNotifications -roles -store'
                      };
                      var qf = {store: store._id, isDeleted: false};
                      Employee.paginate(qf, options).then(function (documents) {
                        if (store.settings.salesarmy.limitations && store.settings.salesarmy.limitations.employee.total > (documents.total + employeesToCreate.length)) {
                          Employee.create(employeesToCreate).then(s => {
                            socket.emit("sales:employee:import:success", {});
                          })
                        } else {
                          socket.emit("sales:employee:import:error", {message: "You dont have required number of licenses. Please contact your Salesarmy Account Manager."});
                        }

                      });
                    }
                    else {
                      socket.emit("sales:employee:import:success", {});
                    }
                  });
                });
                workSheetReader.process();
              });
              bufferStream.pipe(workBookReader);
            } else {
              socket.emit("sales:employee:import:error", {});
            }
          });
      });
  });

  socket.on(EMPLOYEE.GET_ALL_FOR_TEAM.EVENT, function (data) {
    Helper.getStore(socket)
      .then(store => {
        data.filters = data.filters || {};
        data.filters.store = store._id;
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters)
        };
        Controller.getAllForTeam(req)
          .then(function (body) {
            socket.emit(EMPLOYEE.GET_ALL_FOR_TEAM.SUCCESS, body);
          })
          .catch(function (error) {
            if (error) {
              _logger.error(error);
              socket.emit(EMPLOYEE.GET_ALL_FOR_TEAM.ERROR, "Error occurred while getting employee");
            }
          })
      });
  });

  socket.on(EMPLOYEE.GET_OTHER_DETAILS.EVENT, (data, scb) => {
    var req = {
      body: data,
      query: Helper.createQueryString(socket, data.filters)
    };
    Controller.getOtherDetails(req).then(res => {
      if (res == false) {
        Helper.sendSocketErrorResponse(socket, scb, "Error occurred while getting a Employee with Id: " + data._id, {event: EMPLOYEE.GET_OTHER_DETAILS.ERROR});
      } else {
        Helper.sendSocketResponse(socket, scb, res, {event: EMPLOYEE.GET_OTHER_DETAILS.SUCCESS});
      }
    }).catch(error => {
      if (error) {
        _logger.error(error);
        Helper.sendSocketErrorResponse(socket, scb, "Error occurred while getting a Employee with Id: " + data._id, {event: EMPLOYEE.GET_OTHER_DETAILS.ERROR})
      }
    });
  });

  socket.on(EMPLOYEE.GET_LIVE_LOCATION.EVENT, (data) => {
    var req = {
      body: data,
      query: Helper.createQueryString(socket, data.filters)
    };
    Controller.getLiveLocation(req).then(res => {
      if (res == false) {
        socket.emit(EMPLOYEE.GET_LIVE_LOCATION.ERROR, "Error occurred while getting a Employee with Id: " + data);
      } else {
        socket.emit(EMPLOYEE.GET_LIVE_LOCATION.SUCCESS, res);
      }
    }).catch(error => {
      if (error) {
        _logger.error(error);
        socket.emit(EMPLOYEE.GET_LIVE_LOCATION.ERROR, "Error occurred while getting a Employee with Id: " + data._id);
      }
    });
  });
};