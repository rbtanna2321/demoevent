var Employee = require('../../api/models/server.employee.model');
var Passcode = require('../../../app/api/models/server.passcode.model');
var Coupon = require('../../api/models/promotion/server.coupon.model');
var PointWallet = require('../../api/models/promotion/server.point.wallet.model');
var PointWalletTransaction = require('../../api/models/promotion/server.point.wallet.transaction.model');
var Referrals = require('../../api/models/server.referrals.model');
var Designation = require('../../api/models/promotion/server.promoter.designation.model');
var request = require("request-promise");

module.exports = {
  getEmployeeByReferrerCode: function (code, passcode, store) {
    return new Promise((resolve, reject) => {
      Employee.findOne({'phone.number': code, store: store._id}).then(emp => {
        if (emp) {
          Passcode.findOne({'value': emp.mlm.referralCode, code: passcode})
            .then(s => {
              if (s) {
                resolve(emp);
                s.remove();
              } else reject({message: "Customer not found. Please verify the security code."});
            })
        } else reject({message: "Referrer not found. Please verify the referral code."});
      });
    });
  },

  activateNextCoupon: function (employee, store, activatedBy, remittance) {
    return new Promise((resolve, reject) => {
      Employee.findOneAndUpdate({'_id': employee._id, store: store._id}, {
        $inc: {'mlm.currentCoupon': 1},
        $set: {'mlm.isActiveEmployee': true}
      }).then(emp => {
        var q = {
          employee: employee._id,
          previousCouponNumber: emp.mlm.currentCoupon,
          couponNumber: emp.mlm.currentCoupon + 1,
          store: store._id,
          autoActivation: true
        };
        if (activatedBy) {
          q.vendor = activatedBy;
          q.autoActivation = false;
        }
        module.exports.sendSMS(store, employee.phone.number, 'activation', {couponNumber: q.couponNumber});
        Coupon.createAsync(q)
          .then(function (coupon) {
            module.exports.goNLevelsAndAddAmount(employee, 1, coupon.couponNumber, remittance, store, function (completed) {

            }, true, coupon);
            resolve(coupon);
            if (activatedBy) {
              Employee.findOneAndUpdate({_id: activatedBy, isDeleted: false}, {$inc: {'mlm.credit': -1}})
                .then(e => {
                  return true;
                }).catch(err => {
                _logger.error(err);
              })
            }
            return true;
          }).catch(function (error) {
          reject({message: "Something went wrong while coupon activation. Please try again later."});
        });
      });
    });
  },

  updateEmployeeWallet: function (emp, type, store, couponNumber, amountToAdd, couponActivated) {
    PointWallet.findOneAndUpdate({
      employee: emp._id,
      typeOfWallet: type,
      isDeleted: false,
      store: store._id,
      couponNumber: couponNumber
    }, {typeOfWallet: type}, {upsert: true, new: true})
      .then(pw => {
        if (pw) {
          var amountToAddInValue = amountToAdd;
          var currentValue = pw.value;
          var amountToAddInHidden = 0;
          if (emp.mlm.designation.limit < (amountToAddInValue + currentValue)) {
            amountToAddInHidden = amountToAddInValue - (emp.mlm.designation.limit - currentValue);
            amountToAddInValue = amountToAddInValue - amountToAddInHidden;
          }
          PointWalletTransaction.create({
            purchaser: couponActivated.employee,
            typeOfWallet: type,
            amount: amountToAddInValue,
            hiddenAmount: amountToAddInHidden,
            receiver: emp._id,
            coupon: couponActivated._id
          }).then(r => {
            return true;
          }).catch(err => {
            console.log(err);
          });
          PointWallet.findOneAndUpdate({_id: pw._id}, {
            $inc: {
              hidden: amountToAddInHidden,
              pending: amountToAddInValue
            }
          }).then(r => {
            return true;
          }).catch(err => {
            console.log(err);
          });
        }
        return true;
      }).catch(err => {
      _logger.error({message: "Something went wrong while retrieving wallet. Please try again later."})
    });
  },

  addCashback: function (referral, store) {
    Referrals.findOneAndUpdate({
      _id: referral._id,
      isDeleted: false,
      store: store._id
    }, {$inc: {score: store.settings.mlm.cashbackToEmployeeOnActivation}})
      .then(r => {
        return true;
      }).catch(err => {
      console.log(err);
    });
  },

  checkAndUpdateDesignation: function (referrer, store, remittance, couponNumber) {
    return new Promise((resolve, reject) => {
      Designation.findOne({
        store: store._id,
        minimumReference: {$lte: referrer.mlm.activatedSlots},
        maximumReference: {$gte: referrer.mlm.activatedSlots},
        isDeleted: false
      }).then(designation => {
        var setter = {$inc: {'mlm.activatedSlots': 1}};
        if ((couponNumber == 1 || referrer.mlm.designation.limit == 0) && _MOMENT().diff(_MOMENT(referrer.createdAt), 'day') <= (store.settings.mlm.rewardLimitDays || 30)) {
          setter.$inc['mlm.activatedFirstSlots'] = 1;
          setter['$set'] = {'mlm.designation': {name: designation.designation, limit: designation.rewardLimit}};
        }
        Employee.findOneAndUpdate({
          _id: referrer._id,
          isDeleted: false,
          store: store._id
        }, setter, {new: true})
          .then(r => {
            resolve();
            if (r.mlm.activatedSlots % 12 == 0) {
              module.exports.activateNextCoupon(r, store, null, remittance)
                .then(s => {
                  return true;
                });
            }
            return true;
          });
      });
    });
  },

  goNLevelsAndAddAmount: function (origin, currentLevel, couponNumber, remittance, store, cb, addCashbackToEmployee, couponActivated) {
    var level = remittance.levels[_.findIndex(remittance.levels, function (e) {
      return e.level == currentLevel;
    })];
    var options = {
      page: 1,
      limit: parseInt(1),
      populate: [{path: "parent", model: "Sales-Employee", select: "_id firstName mlm"}]
    };
    var qf = {employee: origin._id, store: store._id, isDeleted: false};
    Referrals.paginate(qf, options)
      .then(referral => {
        if (referral && referral.docs.length > 0) {
          var parent = referral.docs[0].parent;
          if (addCashbackToEmployee) {
            addCashbackToEmployee = false;
            module.exports.addCashback(referral.docs[0], store);
            module.exports.checkAndUpdateDesignation(parent, store, remittance, couponNumber).then(r => {
              if (((remittance.activeStatusRequired && parent.mlm.isActiveEmployee) || remittance.activeStatusRequired == false) && parent.mlm.currentCoupon >= couponNumber) {
                module.exports.updateEmployeeWallet(parent, level.typeOfRemittance, store, couponNumber, level.amount, couponActivated);
                currentLevel++;
              } else {
                module.exports.goNLevelsAndAddAmount(parent, currentLevel, couponNumber, remittance, store, cb, addCashbackToEmployee, couponActivated);
                return true;
              }
              if (currentLevel > remittance.remittanceToNumberOfPeople) {
                cb();
              } else {
                module.exports.goNLevelsAndAddAmount(parent, currentLevel, couponNumber, remittance, store, cb, addCashbackToEmployee, couponActivated);
              }
              return true;
            }).catch(err => {
              console.log(err);
            });
          } else if (((remittance.activeStatusRequired && parent.mlm.isActiveEmployee) || remittance.activeStatusRequired == false) && parent.mlm.currentCoupon >= couponNumber) {
            module.exports.updateEmployeeWallet(parent, level.typeOfRemittance, store, couponNumber, level.amount, couponActivated);
            currentLevel++;
            if (currentLevel > remittance.remittanceToNumberOfPeople) {
              cb();
            } else {
              module.exports.goNLevelsAndAddAmount(parent, currentLevel, couponNumber, remittance, store, cb, addCashbackToEmployee, couponActivated);
              return true;
            }
          } else {
            module.exports.goNLevelsAndAddAmount(parent, currentLevel, couponNumber, remittance, store, cb, addCashbackToEmployee, couponActivated);
          }
        } else {
          cb();
        }
        return true;
      }).catch(err => {
      console.log(err);
    });
  },

  sendSMS: function (store, number, messageType, opts) {
    var authenticationDetails = store.promotions.sms.smsId;
    if (authenticationDetails) {
      authenticationDetails = _.isString(authenticationDetails) ? JSON.parse(authenticationDetails) : authenticationDetails;
      var text = authenticationDetails[messageType];
      if (opts) {
        if (opts.couponNumber) text = text.replace(/{{COUPON_NUMBER}}/g, opts.couponNumber);
        if (opts.amount) text = text.replace(/{{AMOUNT}}/g, opts.amount);
        if (opts.password) text = text.replace(/{{PASSWORD}}/g, opts.password);
        if (opts.password) text = text.replace(/{{MOBILE}}/g, number);
      }
      var options = {
        method: 'GET',
        url: _CONFIG.SMS.SECONDARY.SEND_URL,
        qs: {
          Userid: authenticationDetails.Userid,
          UserPassword: authenticationDetails.UserPassword,
          PhoneNumber: number,
          Text: text,
          GSM: authenticationDetails.GSM
        },
        json: true
      };
      console.log(options);
      if (process.env.NODE_ENV === 'production') {
        request(options)
          .then(function (body) {
            _logger.info('Sms api response ' + body);
          })
          .catch(function (err) {
            _logger.error(err);
          })
      } else {
        _logger.info(options.qs.Text);
      }
    }
  }
};