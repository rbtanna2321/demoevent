'use strict';
var Helper = require("../../../app/api/shared/server.helper.js");
var Designation = require("../../api/models/promotion/server.promoter.designation.model");

module.exports.listen = function (io, socket) {

  socket.on("promoter:designation:add", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.designation.store = store._id;
            Designation.createAsync(data.designation)
              .then(function (designation) {
                socket.emit("promoter:designation:add:success", designation);
              }).catch(function (error) {
              _logger.error(error);
            });
          })
      });
  });

  socket.on("promoter:designation:update", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            var id = data.designation._id;
            if (data.designation._id) {
              delete data.designation._id;
            }
            var query = {$set: data.designation};
            Designation.findOneAndUpdate({_id: id, store: store._id}, query, {new: true})
              .then(function (data) {
                socket.emit("promoter:designation:update:success", data);
              }).catch(function (err) {
              _logger.error(err);
              socket.emit("promoter:designation:update:error", {message: "Something went wrong. Please try again."});
            });
          });
      });
  });

  socket.on("promoter:designation:delete", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            var id = data._id;
            Designation.findOneAndUpdate({_id: id, store: store._id}, {isDeleted: true}, {new: true})
              .then(function (data) {
                socket.emit("promoter:designation:delete:success", data);
              }).catch(function (err) {
              _logger.error(err);
              socket.emit("promoter:designation:delete:error", {message: "Something went wrong. Please try again."});
            });
          })
      });
  });
};