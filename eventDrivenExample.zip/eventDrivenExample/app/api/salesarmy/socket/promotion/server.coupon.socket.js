'use strict';
var Helper = require("../../../app/api/shared/server.helper.js");
var Coupon = require("../../api/models/promotion/server.coupon.model");
var Employee = require("../../api/models/server.employee.model");
var Remittance = require("../../api/models/server.remittance.model");
var PromotionHelper = require("./server.promotion.helper");
var async = require("async");

module.exports.listen = function (io, socket) {

  socket.on("promoter:coupon:activate", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            console.log(data);
            data.coupon.store = store._id;
            checkForCouponCredit(response.user._id)
              .then(r => {
                PromotionHelper.getEmployeeByReferrerCode(data.coupon.buyer, data.coupon.code, store)
                  .then(emp => {
                    var query = {store: store._id, isDeleted: false};
                    Remittance.find(query)
                      .then(remittances => {
                        console.log("remittance length : ", remittances.length);
                        async.each(remittances, function (remittance, cb) {
                          PromotionHelper.activateNextCoupon(emp, store, response.user._id, remittance)
                            .then(c => {
                              console.log("completed");
                              cb();
                            });
                        }, function (err, result) {
                          socket.emit("promoter:coupon:activate:success", {});
                        });
                      });
                  }).catch(err => {
                  socket.emit("promoter:coupon:activate:error", err);
                })
              }).catch(err => {
              socket.emit("promoter:coupon:activate:error", err);
            });
          });
      });
  });

  function checkForCouponCredit(empId) {
    return new Promise((resolve, reject) => {
      Employee.findOne({_id: empId, isDeleted: false})
        .then(vendor => {
          if (vendor && vendor.mlm.credit > 0) {
            resolve();
          } else {
            reject({message: "You do not have enough credit to activate coupon."});
          }
        })
    });
  }

  socket.on("sales:get:location:by:pincode", function (data) {
    Helper.getCityStateFromZip(data.pincode)
      .then(pin => {
        socket.emit("sales:get:location:by:pincode:success", pin)
      }).catch(err => {
      socket.emit("sales:get:location:by:pincode:error", err)
    });
  });

};