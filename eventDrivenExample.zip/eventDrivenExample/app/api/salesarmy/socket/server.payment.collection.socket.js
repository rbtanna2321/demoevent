'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  FileUploader = require("../../app/api/shared/file.uploader"),
  PaymentCollection = require('../api/models/server.payment.collection.model'),
  PaymentLink = require('../../app/api/models/server.paymentlinks.model');

module.exports.listen = function (io, socket) {

  socket.on("sales:payment:collection:get", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 0 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {createdAt: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true
              };
              var qf = {store: store._id, isDeleted: false};
              if (data.paymentCollectionId) {
                qf._id = data.paymentCollectionId;
                options.populate = [{
                  path: "attachments",
                  model: "PrivateFile",
                  select: '_id metadata fileId url store'
                }];
              }
              if (data.filters && data.filters.start && data.filters.end) {
                qf["createdAt"] = {
                  $gte: new Date(_MOMENT(data.filters.start).startOf('day')),
                  $lte: new Date(_MOMENT(data.filters.end).endOf('day'))
                };
              }
              if (data.filters && data.filters.employee) qf.employee = data.filters.employee;
              if (data.filters.searchText && data.filters.searchText.length > 0) {
                qf['$or'] = [];
                qf['$or'].push({'company': {'$regex': data.filters.searchText, '$options': 'i'}});
                qf['$or'].push({'category': {'$regex': data.filters.searchText, '$options': 'i'}});
              }
              PaymentCollection.paginate(qf, options).then(function (documents) {
                Helper.sendSocketResponse(socket, scb, documents, {event: "sales:payment:collection:get:success"});
              });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:payment:collection:get:error"});
            }
          });
      });
  });

  socket.on("sales:payment:collection:add", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.paymentCollection) {
              FileUploader.uploadMultipleFile(data.paymentCollection.attachments, store, false)
                .then(d => {
                  data.paymentCollection.attachments = d.idList;
                  if (data.paymentCollection._id) {
                    PaymentCollection.findOneAndUpdate({
                      _id: data.paymentCollection._id,
                      store: store._id,
                      isDeleted: false
                    }, data.paymentCollection, {new: true})
                      .then(exp => {
                        Helper.sendSocketResponse(socket, scb, exp, {event: "sales:payment:collection:add:success"});
                      });
                  } else {
                    data.paymentCollection.store = store._id;
                    data.paymentCollection.employee = response.user._id;
                    PaymentCollection.create(data.paymentCollection)
                      .then(exp => {
                        Helper.sendSocketResponse(socket, scb, exp, {event: "sales:payment:collection:add:success"});
                      }).catch(err => {
                      _logger.error(err);
                      Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:payment:collection:add:error"});
                    });
                  }
                });
            }
          });
      });
  });

  socket.on("sales:payment:links:add", function (data , scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.paymentLink) {
                  if (data.paymentLink._id) {
                    PaymentLink.findOneAndUpdate({
                      _id: data.paymentLink._id,
                      store: store._id,
                      isDeleted: false
                    }, data.paymentLink, {new: true})
                      .then(exp => {
                        Helper.sendSocketResponse(socket, scb, exp, {event: "sales:payment:links:add:success"});
                      });
                  } else {
                    data.paymentLink.store = store._id;
                    data.paymentLink.employee = response.user._id;
                    PaymentLink.create(data.paymentLink)
                      .then(exp => {
                        Helper.sendSocketResponse(socket, scb, exp, {event: "sales:payment:links:add:success"});
                      }).catch(err => {
                      _logger.error(err);
                      Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:payment:links:add:error"});
                    });
                  }
            }
          });
      });
  });

  socket.on("sales:payment:collection:delete", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              PaymentCollection.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isDeleted: true}, {new: true})
                .then(exp => {
                  Helper.sendSocketResponse(socket, scb, exp, {event: "sales:payment:collection:delete:success"});
                });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:payment:collection:delete:error"});
            }
          });
      });
  });

  socket.on("employee:payment:collection:availability", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        var query = {
          employee: data.employee || response.user._id,
          createdAt: {
            $gte: _MOMENT(data.start).startOf("day").toISOString(),
            $lte: _MOMENT(data.end).endOf("day").toISOString()
          },
          isDeleted: false
        };
        PaymentCollection.paginate(query, {
          lean: true,
          limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
          select: 'createdAt _id'
        }).then(function (res) {
          if (res.docs && res.docs.length > 0) {
            var returnObj = _.uniq(_.map(res.docs, function (d) {
              return _MOMENT(d.createdAt).format("DD/MM/YYYY");
            }));
            Helper.sendSocketResponse(socket, scb, returnObj, {event: "employee:payment:collection:availability:success"});
          } else {
            Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:payment:collection:availability:error"});
          }
        }).catch(function (err) {
          _logger.error(err);
          Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:payment:collection:availability:error"});
        });
      });
  });
};