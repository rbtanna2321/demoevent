'use strict';
var EMPLOYEE = require("../socket/shared/server.socket.events").EMPLOYEE,
  Helper = require("../../app/api/shared/server.helper.js"),
  Employee = require('../api/models/server.employee.model'),
  Controller = require('../api/controllers/server.employee.controller'),
  PasscodeController = require('../../app/api/controllers/server.passcode.controller'),
  EMPLOYEE_KEYS = require('../api/shared/server.filter.keys').feed,
  Notification = require('../../app/api/shared/server.push.notification.helper');

module.exports.listen = function (io, socket) {

  socket.on(EMPLOYEE.AUTHENTICATE.EVENT, function (data) {
    Helper.getStore(socket)
      .then(function (store) {
        var stayLoggedIn = data.stayLoggedIn ? data.stayLoggedIn : data.credentials && data.credentials.stayLoggedIn ? data.credentials.stayLoggedIn : false;
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters),
          tokenExpiry: stayLoggedIn
        };
        req.query.store = store._id;
        req.query.storeObj = store;
        req.query.deviceId = socket.isWebSocket ? false : socket.deviceId;
        Controller.authenticate(req)
          .then(function (res) {
            if (res.status === true) {
              socket.emit(EMPLOYEE.AUTHENTICATE.ERROR, res);
            } else {
              if (res.status === 401) {
                socket.emit(EMPLOYEE.AUTHENTICATE.ERROR, res);
              } else {
                var expiry = parseInt((+new Date) / 1000) + 86400;
                if (stayLoggedIn) expiry = parseInt((+new Date) / 1000) + 157680000;
                socket.handshake.session.cookie.expires = expiry;
                Helper.setEmployeeAccessToken(socket, res.user, res.token, "Sales-Employee", stayLoggedIn);
                delete res.token;
                if (stayLoggedIn) res.expiry = 1825;
                socket.emit(EMPLOYEE.AUTHENTICATE.SUCCESS, res);
              }
            }
          })
          .catch(function (error) {
            if (error) {
              socket.emit(EMPLOYEE.AUTHENTICATE.ERROR, error);
            }
          })
      });
  });

  socket.on("employee:store:find", function (data) {
    var deviceId = socket.isWebSocket ? false : socket.deviceId;
    var options = {
      limit: 1,
      select: '-password -salt -createdAt -updatedAt -__v -username -pwdRecoveryId -invitationId -isDeleted -chatAlert -devices -addresses -notificationHistories -promotionalNotifications -roles',
      populate: {
        path: 'store',
        select: 'mobileAppId'
      }
    };
    var qf = {
      imei: deviceId,
      isDeleted: false
    };
    Employee.paginate(qf, options)
      .then(function (res) {
        if (res.docs.length == 0) {
          socket.emit("employee:store:find:error", {
            status: 401,
            message: 'Authentication failed, Please contact System Administrator and provide them the IMEI mentioned below.'
          });
        } else {
          if (res.docs[0].store) socket.emit("employee:store:find:success", {
            status: 200,
            app: res.docs[0].store.mobileAppId
          });
          else socket.emit("employee:store:find:error", {
            status: 401,
            message: 'Authentication failed, Please contact System Administrator and provide them the IMEI mentioned below.'
          });
        }
      }).catch(function (error) {
      if (error) {
        socket.emit("employee:store:find:error", {
          status: 401,
          message: 'Authentication failed, Please contact System Administrator and provide them the IMEI mentioned below.'
        });
      }
    });
  });

  socket.on("employee:authenticate:app", function (data, scb) {
    var stayLoggedIn = true;
    var req = {
      query: Helper.createQueryString(socket, data.filters),
      tokenExpiry: stayLoggedIn
    };
    req.query.deviceId = socket.isWebSocket ? false : socket.deviceId;
    req.query.device = socket.device ? socket.device : false;
    Controller.authenticateApp(req)
      .then(function (response) {
        var res = response.result;
        var store = response.store;
        if (res.status === true) {
          Helper.sendSocketErrorResponse(socket, scb, res, {
            event: "employee:authenticate:app:error",
            forceCallback: true
          });
        } else {
          if (res.status === 401) {
            Helper.sendSocketErrorResponse(socket, scb, res, {
              event: "employee:authenticate:app:error",
              forceCallback: true
            });
          } else {
            var expiry = parseInt((+new Date) / 1000) + 86400;
            if (stayLoggedIn) expiry = parseInt((+new Date) / 1000) + 157680000;
            socket.handshake.session.cookie.expires = expiry;
            Helper.setEmployeeAccessToken(socket, res.user, res.token, "Sales-Employee", stayLoggedIn);
            delete res.token;
            if (stayLoggedIn) res.expiry = 1825;
            if (Helper.checkAddonBoolean(store, "SALES_NOTIFICATION")) {
              Notification.sendToManagersAndLeader(res.user._id, "text", {
                title: "Activity Alert",
                subtitle: `${res.user.firstName} ${res.user.lastName} has logged in on ${res.user.gender ? (res.user.gender == "male" ? "his" : "her") : "their"} device.`
              });
            }
            Helper.sendSocketResponse(socket, scb, res, {
              event: "employee:authenticate:app:success",
              forceCallback: true
            })
          }
        }
      })
      .catch(function (error) {
        if (error) {
          console.log(error);
          Helper.sendSocketErrorResponse(socket, scb, error, {
            event: "employee:authenticate:app:error",
            forceCallback: true
          });
        }
      });
  });

  socket.on(EMPLOYEE.VERIFY.EVENT, function (data) {
    Helper.getStore(socket)
      .then(store => {
        data.mobile = data.value;
        data.remoteIp = socket.remoteIp;
        data.remoteCountry = socket.remoteCountry;
        var stayLoggedIn = data.stayLoggedIn ? data.stayLoggedIn : data.credentials && data.credentials.stayLoggedIn ? data.credentials.stayLoggedIn : false;
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters),
          tokenExpiry: stayLoggedIn
        };
        req.query.store = store._id;
        req.query.storeObj = store;
        PasscodeController.verifyPasscode(req)
          .then(function (response) {
            var isValidCode = false;
            if (response.valid === false) {
              isValidCode = false;
              socket.emit(EMPLOYEE.VERIFY.ERROR, {message: "Invalid Verification Code. Please try again."});
            }
            if (response.valid === true) {
              isValidCode = true;
              req.query.deviceId = socket.isWebSocket ? false : socket.deviceId;
              Controller.authenticate(req)
                .then(function (res) {
                  res.isValidCode = isValidCode;
                  if (res.status === true) {
                    socket.emit(EMPLOYEE.VERIFY.ERROR, {message: "Invalid Verification Code. Please try again."});
                  } else {
                    if (res.status === 401) {
                      socket.emit(EMPLOYEE.VERIFY.ERROR, {message: "Invalid Verification Code. Please try again."});
                    } else {
                      var expiry = parseInt((+new Date) / 1000) + 86400;
                      if (stayLoggedIn) expiry = parseInt((+new Date) / 1000) + 157680000;
                      socket.handshake.session.cookie.expires = expiry;
                      Helper.setEmployeeAccessToken(socket, res.user, res.token, "Sales-Employee", stayLoggedIn);
                      delete res.token;
                      if (stayLoggedIn) res.expiry = 1825;
                      socket.emit(EMPLOYEE.VERIFY.SUCCESS, res);
                    }
                  }
                })
                .catch(function (error) {
                  if (error) {
                    socket.emit(EMPLOYEE.VERIFY.ERROR, {message: "Invalid Verification Code. Please try again."});
                  }
                })
            }
          })
          .catch(function (error) {
            if (error) {
              _logger.error(error);
              socket.emit(EMPLOYEE.VERIFY.ERROR, {message: "Invalid Verification Code. Please try again."});
            }
          })
      });

  });

  socket.on("employee:login:by:cookie", function (data, scb) {
    _RedisSession.get("sess:" + data).then(function (obj) {
      if (obj) {
        var session = JSON.parse(obj);
        var expiry = parseInt((+new Date) / 1000) + 86400;
        socket.handshake.session.cookie.expires = expiry;
        Helper.setEmployeeAccessToken(socket, session.employee.user, session.employee.token, "Sales-Employee", false);
        scb();
      }
    });
  });

  socket.on("employee:login:code", function (data) {
    data.sessID = socket.handshake.sessionID;
    io.sockets.emit("employee:login:by:" + data.code, data);
  });

  socket.on("employee:logout", function (data, scb) {
    socket.handshake.session.regenerate(function (r) {
      scb({});
    });
  });

  socket.on("sales:employee:logout", function (data, scb) {
    Helper.checkEmployeeAccess(socket, {}, EMPLOYEE_KEYS.add)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (Helper.checkAddonBoolean(store, "SALES_NOTIFICATION")) {
              Notification.sendToManagersAndLeader(response.user._id, "text", {
                title: "Activity Alert",
                subtitle: `${response.user.firstName} ${response.user.lastName} has logged out on ${response.user.gender ? (response.user.gender == "male" ? "his" : "her") : "their"} device.`
              });
            }
            scb();
          });
      });
  });

  socket.on(EMPLOYEE.CHECK_AVAILABILITY.EVENT, function (data) {
    Helper.getStore(socket)
      .then(function (store) {
        var req = {
          body: {value: data.value, field: data.field, store: store._id},
          query: Helper.createQueryString(socket, data.filters)
        };
        Controller.checkAvailability(req)
          .then(function (body) {
            if (body.available === true) {
              socket.emit(EMPLOYEE.CHECK_AVAILABILITY.SUCCESS, body);
            } else {
              socket.emit(EMPLOYEE.CHECK_AVAILABILITY.SUCCESS, body);
            }
          })
          .catch(function (error) {
            if (error) {
              _logger.error(error);
              socket.emit(EMPLOYEE.CHECK_AVAILABILITY.ERROR, "Error occurred while checking availability of employee.");
            }
          })
      });
  });

};