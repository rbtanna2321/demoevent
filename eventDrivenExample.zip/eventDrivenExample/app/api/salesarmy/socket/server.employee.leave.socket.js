'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  Employee = require('../api/models/server.employee.model'),
  EmployeeLeave = require('../api/models/server.employee.leave.model'),
  EMPLOYEE_KEYS = require('../api/shared/server.filter.keys').feed;

module.exports.listen = function (io, socket) {

  socket.on("sales:leave:get", function (data, scb) {
    Helper.checkEmployeeAccess(socket, {}, EMPLOYEE_KEYS.add)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 1 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {createdAt: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true
              };
              var qf = {store: store._id, isDeleted: false, employee: data.filters.employee || response.user._id};
              EmployeeLeave.paginate(qf, options).then(function (documents) {
                Helper.sendSocketResponse(socket, scb, documents, {event: "sales:leave:get:success"});
              });
            }
          });
      });
  });

  socket.on("sales:leave:add", function (data, scb) {
    Helper.checkEmployeeAccess(socket, {}, EMPLOYEE_KEYS.add)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.leave.store = store._id;
            data.leave.employee = data.leave.employee || response.user._id;
            EmployeeLeave.create(data.leave).then(leaveEntry => {
              Helper.sendSocketResponse(socket, scb, leaveEntry, {event: "sales:leave:add:success"});
            });
          });
      });
  });

  socket.on("sales:leave:approve", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, EMPLOYEE_KEYS.add)
      .then(response => {
        EmployeeLeave.findOneAndUpdate({_id: data._id}, {
          $set: {
            isApproved: true,
            approvalDate: _MOMENT(),
            approvedBy: data.approvedBy,
            remarks: data.remarks
          }
        }).then(leaveEntry => {
          Employee.findOne({_id: leaveEntry.employee}).then(emp => {
            emp.hr.leaves = _.map(emp.hr.leaves, function (leave) {
              if (leave.typeOfLeave == leaveEntry.typeOfLeave) {
                var days = _MOMENT(leaveEntry.dateTo).diff(leaveEntry.dateFrom, 'days');
                leave.available = leave.available - (days + 1);
              }
              return leave;
            });
            emp.save();
          }).catch(e => {
            console.log(e);
          });
          socket.emit("sales:leave:approve:success", leaveEntry);
        });
      });
  });

  socket.on("sales:leave:disapprove", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, EMPLOYEE_KEYS.add)
      .then(response => {
        EmployeeLeave.findOneAndUpdate({_id: data._id}, {
          $set: {
            isApproved: false,
            approvalDate: _MOMENT(),
            approvedBy: data.approvedBy,
            remarks: data.remarks
          }
        }).then(leaveEntry => {
          socket.emit("sales:leave:disapprove:success", leaveEntry);
        });
      });
  });

  socket.on("sales:leave:cancel", function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, EMPLOYEE_KEYS.add)
      .then(response => {
        EmployeeLeave.findOneAndUpdate({_id: data._id}, {
          $set: {
            isApproved: false,
            approvalDate: _MOMENT(),
            approvedBy: data.approvedBy,
            remarks: data.remarks
          }
        }).then(leaveEntry => {
          Employee.findOne({_id: leaveEntry.employee}).then(emp => {
            emp.hr.leaves = _.map(emp.hr.leaves, function (leave) {
              if (leave.typeOfLeave === leaveEntry.typeOfLeave) {
                var days = _MOMENT(leaveEntry.dateTo).startOf('day').diff(_MOMENT(leaveEntry.dateFrom).startOf('day'), 'days');
                leave.available = leave.available + (days + 1);
              }
              return leave;
            });
            emp.save();
          }).catch(e => {
            console.log(e);
          });
          socket.emit("sales:leave:cancel:success", leaveEntry);
        });
      });
  });

};