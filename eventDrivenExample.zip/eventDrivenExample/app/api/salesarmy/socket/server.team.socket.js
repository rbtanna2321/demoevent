'use strict';
var TEAM = require("../socket/shared/server.socket.events").TEAM,
  Helper = require("../../app/api/shared/server.helper.js"),
  Controller = require('../api/controllers/server.team.controller'),
  Notification = require('../../app/api/shared/server.push.notification.helper'),
  TeamRelation = require('../api/models/server.team.relation.model'),
  TEAM_KEYS = require('../api/shared/server.filter.keys').feed;

module.exports.listen = function (io, socket) {

  socket.on(TEAM.ADD.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, TEAM_KEYS.add)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.team.store = store._id;
            var req = {
              body: data.team,
              query: Helper.createQueryString(socket, data.filters),
            };
            Controller.add(req)
              .then(team => {
                socket.emit(TEAM.ADD.SUCCESS, team);
              })
              .catch(error => {
                if (error) {
                  _logger.error(error);
                  socket.emit(TEAM.ADD.ERROR, "Error occurred while adding team");
                }
              });
          });
      });
  });

  socket.on(TEAM.GET_ALL.EVENT, function (data) {
    Helper.getStore(socket)
      .then(store => {
        data.filters = data.filters || {};
        data.filters.store = store._id;
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters)
        };
        Controller.getAll(req)
          .then(function (data) {
            socket.emit(TEAM.GET_ALL.SUCCESS, data);
          })
          .catch(function (error) {
            _logger.error(error);
            socket.emit(TEAM.GET_ALL.ERROR, "Error occurred while getting list of teams.");
          });
      });
  });

  socket.on(TEAM.GET.EVENT, (data) => {
    var req = {
      body: data,
      query: Helper.createQueryString(socket, data.filters)
    };
    Controller.get(req).then(team => {
      socket.emit(TEAM.GET.SUCCESS, team);
    }).catch(error => {
      if (error) {
        _logger.error(error);
        socket.emit(TEAM.GET.ERROR, "Error occurred while getting a team with Id: " + data._id);
      }
    });
  });

  socket.on(TEAM.UPDATE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, TEAM_KEYS.update)
      .then(response => {
        var req = {
          body: data.team,
          query: Helper.createQueryString(socket, data.filters),
        };
        Controller.update(req)
          .then(product => {
            socket.emit(TEAM.UPDATE.SUCCESS, product);
          })
          .catch(error => {
            if (error) {
              _logger.error(error);
              socket.emit(TEAM.UPDATE.ERROR, "Error occurred while updating team with ID: " + data.team._id);
            }
          });
      })
  });

  socket.on(TEAM.DELETE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, TEAM_KEYS.delete)
      .then(response => {
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : TEAM_KEYS.view.guest.keys
        };
        Controller.delete(req)
          .then(team => {
            socket.emit(TEAM.DELETE.SUCCESS, team);
          }).catch(error => {
          if (error) {
            _logger.error(error);
            socket.emit(TEAM.DELETE.ERROR, "Error occurred while deleting team with Id: " + data._id);
          }
        });
      });
  });

  socket.on(TEAM.GET.BY_LEADER.EVENT, (data, scb) => {
    var req = {
      body: data,
      query: Helper.createQueryString(socket, data.filters)
    };
    if(req.body.leader && req.body.leader.length > 0 && req.body.teamId && req.body.teamId.length > 0) {
      Controller.getTeamByLeader(req).then(team => {
        Helper.sendSocketResponse(socket, scb, team, {event: TEAM.GET.BY_LEADER.SUCCESS})
      }).catch(error => {
        if (error) {
          _logger.error(error);
          Helper.sendSocketErrorResponse(socket, scb, {message: "Error occurred while getting a team by leader"}, {event: TEAM.GET.BY_LEADER.ERROR})
        }
      });
    } else {
      Helper.sendSocketErrorResponse(socket, scb, {message: "Error occurred while getting a team by leader"}, {event: TEAM.GET.BY_LEADER.ERROR})
    }
  });

  socket.on(TEAM.GET.BY_LOGGED_IN_USER.EVENT, (data, scb) => {
    if (data && data._id && data._id.length > 0) {
      var req = {
        body: data,
        query: Helper.createQueryString(socket, data.filters)
      };
      Controller.getTeamByLoggedInUser(req).then(team => {
        Helper.sendSocketResponse(socket, scb, team, {event: TEAM.GET.BY_LOGGED_IN_USER.SUCCESS})
      }).catch(error => {
        if (error) {
          _logger.error(error);
          Helper.sendSocketErrorResponse(socket, scb, {message: "Error occurred while getting a team by user: " + data._id}, {event: TEAM.GET.BY_LOGGED_IN_USER.ERROR});
        }
      });
    } else {
      Helper.sendSocketErrorResponse(socket, scb, {message: "Error occurred while getting a team by user: " + data._id}, {event: TEAM.GET.BY_LOGGED_IN_USER.ERROR});
    }
  });

  socket.on(TEAM.GET_ALL_TEAM_ONLY.EVENT, function (data) {
    Helper.getStore(socket)
      .then(store => {
        data.filters = data.filters || {};
        data.filters.store = store._id;
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters)
        };
        Controller.getAllTeamOnly(req)
          .then(function (body) {
            socket.emit(TEAM.GET_ALL_TEAM_ONLY.SUCCESS, body);
          })
          .catch(function (error) {
            if (error) {
              _logger.error(error);
              socket.emit(TEAM.GET_ALL_TEAM_ONLY.ERROR, "Error occurred while getting employee");
            }
          })
      });
  });

  socket.on("sales:team:relation:add", function (data) {
    Helper.getStore(socket)
      .then(store => {
        TeamRelation.find({employee: data.employee, store: store._id, team: data.team, isDeleted: false})
          .then(rel => {
            if (rel && rel.length == 0) {
              data.store = store._id;
              TeamRelation.create(data)
                .then(relation => {
                  if (data.employee) {
                    var options = {
                      limit: 1,
                      select: {'team': 1, 'isLeader': 1, 'isManager': 1},
                      lean: true,
                      populate: {
                        path: 'team',
                        select: 'name _id isDeleted'
                      }
                    };
                    TeamRelation.paginate({_id: relation._id, isDeleted: false}, options)
                      .then(function (teams) {
                        if (teams.docs && teams.docs.length > 0) {
                          var team = teams.docs[0];
                          if (!_.isUndefined(io.sockets.adapter.rooms[data.employee + ":service"]) || (io.sockets.adapter.rooms[data.employee + ":service"] && io.sockets.adapter.rooms[data.employee + ":service"].length === 1)) {
                            io.sockets.in(data.employee + ":service").emit("location:updates:start", {
                              type: "team:reload",
                              team: team, action: "relation:add"
                            });
                          } else if (_.isUndefined(io.sockets.adapter.rooms[data.employee + ":location"]) || (io.sockets.adapter.rooms[data.employee + ":location"] && io.sockets.adapter.rooms[data.employee + ":location"].length === 0)) {
                            Notification.send({
                              notification: {
                                to: data.employee + "",
                                team: team,
                                action: "relation:add",
                                type: "team:reload"
                              }
                            });
                          }
                        }
                      });
                  }
                  socket.emit("sales:team:relation:add:success", relation);
                }).catch(err => {
                socket.emit("sales:team:relation:add:error", {message: "Something went wrong! Please try again."});
              })
            } else {
              socket.emit("sales:team:relation:add:error", {message: "Employee is a member of this team already."});
            }
          }).catch(err => {
          socket.emit("sales:team:relation:add:error", {message: "Something went wrong! Please try again."});
        });
      });
  });

  socket.on("sales:team:relation:update", function (data) {
    Helper.getStore(socket)
      .then(store => {
        TeamRelation.findOne({_id: data._id, store: store._id, isDeleted: false})
          .then(rel => {
            if (!_.isNull(rel)) {
              var valueChanged = false;
              if (rel.isManager != data.isManager) {
                valueChanged = true;
              }
              if (rel.isLeader != data.isLeader) {
                valueChanged = true;
              }
              rel.isManager = data.isManager;
              rel.isLeader = data.isLeader;
              rel.save()
                .then(relation => {
                  if (rel.employee && rel.employee._id && valueChanged) {
                    var team = {
                      _id: relation._id,
                      isManager: relation.isManager,
                      isLeader: relation.isManager,
                      team: {
                        _id: relation.team._id,
                        name: relation.team.name,
                        isDeleted: relation.team.isDeleted
                      }
                    };
                    if (!_.isUndefined(io.sockets.adapter.rooms[rel.employee._id + ":service"]) || (io.sockets.adapter.rooms[rel.employee._id + ":service"] && io.sockets.adapter.rooms[rel.employee._id + ":service"].length === 1)) {
                      io.sockets.in(rel.employee._id + ":service").emit("location:updates:start", {
                        type: "team:reload",
                        team: team, action: "relation:update"
                      });
                    } else if (_.isUndefined(io.sockets.adapter.rooms[rel.employee._id + ":location"]) || (io.sockets.adapter.rooms[rel.employee._id + ":location"] && io.sockets.adapter.rooms[rel.employee._id + ":location"].length === 0)) {
                      Notification.send({
                        notification: {
                          to: rel.employee._id + "",
                          team: team,
                          action: "relation:update",
                          type: "team:reload"
                        }
                      });
                    }
                  }
                  socket.emit("sales:team:relation:update:success", relation);
                }).catch(err => {
                socket.emit("sales:team:relation:update:error", {message: "Something went wrong! Please try again."});
              })
            } else {
              socket.emit("sales:team:relation:update:error", {message: "Employee is not a member of this team."});
            }
          }).catch(err => {
          socket.emit("sales:team:relation:update:error", {message: "Something went wrong! Please try again."});
        });
      });
  });

  socket.on("sales:team:relation:delete", function (data) {
    Helper.getStore(socket)
      .then(store => {
        TeamRelation.findOneAndUpdate({_id: data._id, store: store._id, isDeleted: false}, {$set: {isDeleted: true}})
          .then(relation => {
            if (relation.employee && relation.employee._id) {
              if (!_.isUndefined(io.sockets.adapter.rooms[relation.employee._id + ":service"]) || (io.sockets.adapter.rooms[relation.employee._id + ":service"] && io.sockets.adapter.rooms[relation.employee._id + ":service"].length === 1)) {
                io.sockets.in(relation.employee._id + ":service").emit("location:updates:start", {
                  type: "team:reload",
                  team: relation.team._id,
                  action: "relation:delete"
                });
              } else if (_.isUndefined(io.sockets.adapter.rooms[relation.employee._id + ":location"]) || (io.sockets.adapter.rooms[relation.employee._id + ":location"] && io.sockets.adapter.rooms[relation.employee._id + ":location"].length === 0)) {
                Notification.send({
                  notification: {
                    to: relation.employee._id + "",
                    team: relation.team._id,
                    action: "relation:delete",
                    type: "team:reload"
                  }
                });
              }
            }
            socket.emit("sales:team:relation:delete:success", {});
          }).catch(err => {
          socket.emit("sales:team:relation:delete:error", {message: "Something went wrong! Please try again."});
        })
      })
  });

};