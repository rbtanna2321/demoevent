'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  Ingredient = require('../api/models/server.ingredients.model');

module.exports.listen = function (io, socket) {

  socket.on("sales:ingredient:get", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 0 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {createdAt: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true
              };
              var qf = {store: store._id, isDeleted: false};
              if (data.ingredientId) {
                qf._id = data.ingredientId;
              }
              if (data.filters.searchText && data.filters.searchText.length > 0) {
                qf['$or'] = [];
                qf['$or'].push({'name': {'$regex': data.filters.searchText, '$options': 'i'}});
              }
              Ingredient.paginate(qf, options).then(function (documents) {
                Helper.sendSocketResponse(socket, scb, documents, {event: "sales:ingredient:get:success"});
              });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:ingredient:get:error"});
            }
          });
      });
  });

  socket.on("sales:ingredient:add", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            console.log(data.ingredient);
            if (data.ingredient) {
              if (data.ingredient._id) {
                Ingredient.findOneAndUpdate({
                  _id: data.ingredient._id,
                  store: store._id,
                  isDeleted: false
                }, data.ingredient, {new: true})
                  .then(exp => {
                    Helper.sendSocketResponse(socket, scb, exp, {event: "sales:ingredient:add:success"});
                  });
              } else {
                data.ingredient.store = store._id;
                data.ingredient.employee = response.user._id;
                Ingredient.create(data.ingredient)
                  .then(exp => {
                    Helper.sendSocketResponse(socket, scb, exp, {event: "sales:ingredient:add:success"});
                  }).catch(err => {
                  _logger.error(err);
                  Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:ingredient:add:error"});
                });
              }
            }
          });
      });
  });

  socket.on("sales:ingredient:delete", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Ingredient.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isDeleted: true}, {new: true})
                .then(exp => {
                  Helper.sendSocketResponse(socket, scb, exp, {event: "sales:ingredient:delete:success"});
                });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:ingredient:delete:error"});
            }
          });
      });
  });
};