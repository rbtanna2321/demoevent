'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  Service = require('../api/models/server.services.model');

module.exports.listen = function (io, socket) {

  socket.on("sales:service:get", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 0 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {createdAt: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true
              };
              var qf = {store: store._id, isDeleted: false};
              if (data.serviceId) {
                qf._id = data.serviceId;
              }
              if (data.filters.searchText && data.filters.searchText.length > 0) {
                qf['$or'] = [];
                qf['$or'].push({'name': {'$regex': data.filters.searchText, '$options': 'i'}});
              }
              Service.paginate(qf, options).then(function (documents) {
                socket.emit("sales:service:get:success", documents);
              });
            } else {
              socket.emit("sales:service:get:error", {message: "Something went wrong. Please try again later."});
            }
          });
      });
  });

  socket.on("sales:service:add", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.service) {
              if (data.service._id) {
                Service.findOneAndUpdate({
                  _id: data.service._id,
                  store: store._id,
                  isDeleted: false
                }, data.service, {new: true})
                  .then(exp => {
                    socket.emit("sales:service:add:success", exp);
                  }).catch(err => {
                  socket.emit("sales:service:add:error", {message: "Something went wrong. Please try again later."});
                });
              } else {
                data.service.store = store._id;
                data.service.employee = response.user._id;
                Service.create(data.service)
                  .then(exp => {
                    socket.emit("sales:service:add:success", exp);
                  }).catch(err => {
                  socket.emit("sales:service:add:error", {message: "Something went wrong. Please try again later."});
                });
              }
            } else {
              socket.emit("sales:service:add:error", {message: "Something went wrong. Please try again later."});
            }
          });
      });
  });

  socket.on("sales:service:delete", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Service.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isDeleted: true}, {new: true})
                .then(exp => {
                  socket.emit("sales:service:delete:success", exp);
                });
            } else {
              socket.emit("sales:service:delete:error", {message: "Something went wrong. Please try again later."});
            }
          });
      });
  });
};