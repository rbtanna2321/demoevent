'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  FileUploader = require("../../app/api/shared/file.uploader"),
  Application = require('../api/models/server.application.model'),
  request = require("request"),
  cheerio = require("cheerio"),
  async = require("async"),
  s = require("underscore.string"),
  fileType = require("file-type"),
  ApplicationUsage = require('../api/models/server.application.usage.model');

module.exports.listen = function (io, socket) {


  function getUsageDetails(response, store, date) {
    return new Promise((resolve, reject) => {
      var start = _MOMENT().startOf("day").toISOString();
      var end = _MOMENT().toISOString();
      if (date) {
        start = _MOMENT(date, "DD/MM/YYYY").startOf("day").toISOString();
        end = _MOMENT(date, "DD/MM/YYYY").endOf('day').toISOString();
      }
      ApplicationUsage.paginate({
        employee: response.user._id,
        isDeleted: false,
        store: store._id,
        createdAt: {
          $gte: start,
          $lte: end
        }
      }, {
        lean: true,
        select: {applications: 1},
        populate: [{path: "applications.application", model: "Sales-Application", "select": {packageId: 1}}]
      }).then(usageDetails => {
        if (usageDetails.docs && usageDetails.docs.length > 0) {
          resolve(usageDetails.docs[0]);
        } else {
          ApplicationUsage.create({store: store._id, employee: response.user._id})
            .then(usageDetails => {
              resolve(usageDetails);
            });
        }
      });
    });
  };


  function getApplicationId(packageId, otherApplications, applicationsFromRequest) {
    return new Promise((resolve, reject) => {
      var index = _.findIndex(otherApplications, function (r) {
        return r.application.packageId + "" == packageId;
      });
      if (index > -1) {
        resolve(otherApplications[index].application._id)
      } else {
        Application.paginate({
          isDeleted: false,
          packageId: packageId
        }, {
          lean: true,
          select: {_id: 1}
        }).then(application => {
          if (application.docs && application.docs.length > 0) {
            resolve(application.docs[0]._id);
          } else {
            request('https://play.google.com/store/apps/details?id=' + packageId, function (error, response, html) {
              if (!error && response.statusCode == 200) {
                var $ = cheerio.load(html);
                var obj = {
                  packageId: packageId,
                  image: $('[itemtype="https://schema.org/SoftwareApplication"] [itemprop="image"]').attr("content"),
                  genre: $('[itemtype="https://schema.org/SoftwareApplication"] [itemprop="applicationCategory"]').attr("content"),
                  url: $('[itemtype="https://schema.org/SoftwareApplication"] [itemprop="url"]').attr("content"),
                  name: $('[itemtype="https://schema.org/SoftwareApplication"] [itemprop="name"]').attr("content")
                };
                if (obj.image && obj.image.length > 0) {
                  var options = {
                    uri: obj.image,
                    encoding: null
                  };
                  request(options, function (error, response, body) {
                    if (error || response.statusCode !== 200) {
                      console.log("failed to get image");
                      console.log(error);
                    } else {
                      FileUploader.uploadToSpace({
                        store: "assets",
                        buffer: body,
                        metadata: {
                          name: s.slugify(obj.name) + "." + fileType(body).ext,
                          type: fileType(body).mime,
                          size: ""
                        }
                      }, false)
                        .then(file => {
                          if (file) {
                            obj.image = file._id;
                            Application.create(obj)
                              .then(r => {
                                resolve(r._id);
                              });
                          }
                        });
                    }
                  });
                } else {
                  Application.create(obj)
                    .then(r => {
                      resolve(r._id);
                    });
                }
              } else {
                var obj = {
                  packageId: packageId,
                  genre: "Unknown",
                  name: "Not available on Play Store"
                };
                var index = _.findIndex(applicationsFromRequest, function (r) {
                  return r.packageId == packageId;
                });
                if (index > -1) {
                  obj.name = applicationsFromRequest[index].name || "Not available on Play Store";
                }
                Application.create(obj)
                  .then(r => {
                    resolve(r._id);
                  });
              }
            });
          }
        });
      }
    });
  };


  socket.on("sales:usage:update", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            async.each(data.applications, function (usageData, callback) {
              getUsageDetails(response, store, usageData.date)
                .then(usageDetails => {
                  var packageIds = _.pluck(usageData.usage, 'packageId');
                  var packageIdsInUsage = _.map(usageDetails.applications, function (app) {
                    return app.application.packageId;
                  });
                  var packagesRequired = _.union(packageIds, packageIdsInUsage);
                  async.each(packagesRequired, function (item, cb) {
                    getApplicationId(item, usageDetails.applications, usageData.usage)
                      .then(applicationId => {
                        var index = _.findIndex(usageDetails.applications, function (app) {
                          return app.application._id + "" == applicationId + "";
                        });
                        if (index > -1) {
                          var indexInNewData = _.findIndex(usageData.usage, function (r) {
                            return r.packageId == item;
                          });
                          if (indexInNewData > -1) {
                            usageDetails.applications[index].time = usageData.usage[indexInNewData].time;
                          }
                          cb();
                        } else {
                          var indexInNewData = _.findIndex(usageData.usage, function (r) {
                            return r.packageId == item;
                          });
                          if (indexInNewData > -1) {
                            usageDetails.applications.push({
                              application: applicationId,
                              time: usageData.usage[indexInNewData].time
                            });
                          }
                          cb();
                        }
                      });
                  }, function (err, result) {
                    ApplicationUsage.findOneAndUpdate({_id: usageDetails._id}, {$set: {applications: usageDetails.applications}}, {new: true})
                      .then(r => {
                        callback()
                      });
                  });
                });
            }, function (err, result) {
              Helper.sendSocketResponse(socket, scb, {}, {event: "sales:usage:update:success"});
            });
          })
      });
  });


  socket.on("sales:application:usage:get", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            ApplicationUsage.paginate({
              employee: data.employee,
              isDeleted: false,
              store: store._id,
              createdAt: {
                $gte: _MOMENT().startOf("day").toISOString(),
                $lte: _MOMENT().toISOString()
              }
            }, {
              lean: true,
              select: {applications: 1},
              populate: [{
                path: "applications.application",
                model: "Sales-Application",
                "select": {name: 1, genre: 1, url: 1, image: 1, packageId: 1},
                populate: [{
                  path: "image",
                  model: "PrivateFile",
                  select: 'url'
                }]
              }]
            }).then(usageDetails => {
              Helper.sendSocketResponse(socket, scb, usageDetails.docs.length > 0 ? usageDetails.docs[0] : {applications: []}, {event: "sales:application:usage:get:success"});
            });
          });
      });
  });

  socket.on("sales:usage:application:add", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        if (data.application) {
          if (data.application._id) {
            Application.findOneAndUpdate({
              _id: data.application._id,
              isDeleted: false
            }, data.application, {new: true})
              .then(exp => {
                socket.emit("sales:usage:application:add:success", exp);
              });
          } else {
            Application.create(data.application)
              .then(exp => {
                socket.emit("sales:usage:application:add:success", exp);
              }).catch(err => {
              socket.emit("sales:usage:application:add:error", {message: "Something went wrong. Please try again later."});
            });
          }
        }
      });
  });

  socket.on("sales:usage:application:delete", function (data) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        if (data._id) {
          Application.findOneAndUpdate({
            _id: data._id,
            isDeleted: false
          }, {isDeleted: true}, {new: true})
            .then(exp => {
              socket.emit("sales:usage:application:delete:success", exp);
            });
        } else {
          socket.emit("sales:usage:application:delete:error", {message: "Something went wrong. Please try again later."});
        }
      });
  });
}
;