'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  FileUploader = require("../../app/api/shared/file.uploader"),
  Visitor = require('../api/models/server.visitor.model');

module.exports.listen = function (io, socket) {

  socket.on("sales:visitor:get", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 0 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {createdAt: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true,
                populate: [{path: "file", model: "PrivateFile", select: '_id metadata fileId url store'}]
              };
              var qf = {store: store._id, isDeleted: false};
              if (data.visitorId) {
                qf._id = data.visitorId;
              }
              if(data.filters && data.filters.employee) qf.employee = data.filters.employee;
              if (data.filters.searchText && data.filters.searchText.length > 0) {
                qf['$or'] = [];
                qf['$or'].push({'name': {'$regex': data.filters.searchText, '$options': 'i'}});
                qf['$or'].push({'mobile': {'$regex': data.filters.searchText, '$options': 'i'}});
                qf['$or'].push({'information.vehicleNumber': {'$regex': data.filters.searchText, '$options': 'i'}});
                qf['$or'].push({'information.unitNumber': {'$regex': data.filters.searchText, '$options': 'i'}});
              }
              if (data.filters && data.filters.start && data.filters.end) {
                qf["createdAt"] = {
                  $gte: new Date(_MOMENT(data.filters.start).startOf('day')),
                  $lte: new Date(_MOMENT(data.filters.end).endOf('day'))
                };
              }
              Visitor.paginate(qf, options).then(function (documents) {
                Helper.sendSocketResponse(socket, scb, documents, {event: "sales:visitor:get:success"});
              });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:visitor:get:error"});
            }
          });
      });
  });

  socket.on("sales:visitor:add", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.visitor) {
              FileUploader.uploadMultipleFile([data.visitor.file], store, false)
                .then(d => {
                  data.visitor.file = d.idList && d.idList.length > 0 ? d.idList[0] : undefined;
                  if (data.visitor._id) {
                    Visitor.findOneAndUpdate({
                      _id: data.visitor._id,
                      store: store._id,
                      isDeleted: false
                    }, data.visitor, {new: true})
                      .then(exp => {
                        Helper.sendSocketResponse(socket, scb, exp, {event: "sales:visitor:add:success"});
                      });
                  } else {
                    data.visitor.employee = response.user._id;
                    data.visitor.store = store._id;
                    Visitor.create(data.visitor)
                      .then(exp => {
                        Helper.sendSocketResponse(socket, scb, exp, {event: "sales:visitor:add:success"});
                      }).catch(err => {
                      _logger.error(err);
                      Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:visitor:add:error"});
                    });
                  }
                });
            }
          });
      });
  });

  socket.on("sales:visitor:out", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Visitor.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {$set: {out: data.out}}, {new: true})
                .then(exp => {
                  Helper.sendSocketResponse(socket, scb, exp, {event: "sales:visitor:out:success"});
                });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:visitor:out:error"});
            }
          });
      });
  });

  socket.on("employee:visitor:availability", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        var query = {
          employee: data.employee || response.user._id,
          createdAt: {
            $gte: _MOMENT(data.start).startOf("day").toISOString(),
            $lte: _MOMENT(data.end).endOf("day").toISOString()
          },
          isDeleted: false
        };
        Visitor.paginate(query, {
          lean: true,
          limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
          select: 'createdAt _id'
        }).then(function (res) {
          if (res.docs && res.docs.length > 0) {
            var returnObj = _.uniq(_.map(res.docs, function (d) {
              return _MOMENT(d.createdAt).format("DD/MM/YYYY");
            }));
            Helper.sendSocketResponse(socket, scb, returnObj, {event: "employee:visitor:availability:success"});
          } else {
            Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:visitor:availability:error"});
          }
        }).catch(function (err) {
          _logger.error(err);
          Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:visitor:availability:error"});
        });
      });
  });
};