var TeamRelation = require('../api/models/server.team.relation.model'),
  Helper = require('../../app/api/shared/server.helper'),
  Chat = require('../api/models/server.chat.model'),
  ChatMessage = require('../api/models/server.chat.message.model');

var ChatHelper = {
  joinTeamRooms: function (socket, userId, store) {
    var options = {
      page: 1,
      limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
      lean: true,
      select: 'team'
    };
    var qf = {store: store._id, employee: userId, isDeleted: false};
    TeamRelation.paginate(qf, options)
      .then(teamRelations => {
        _.map(teamRelations.docs, function (ob) {
          socket.join(ob.team + ":chat");
        });
      });
  },
  getTeamRooms: function (userId, store) {
    return new Promise((resolve, reject) => {
      var options = {
        page: 1,
        limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
        lean: true,
        select: 'team',
        populate: {
          path: 'team',
          select: '_id name about'
        }
      };
      var qf = {store: store._id, employee: userId, isDeleted: false};
      TeamRelation.paginate(qf, options)
        .then(teamRelations => {
          resolve(teamRelations);
        });
    });
  }
};

module.exports.listen = function (io, socket) {

  socket.on("location:config", function (data, scb) {
    Helper.getStore(socket)
      .then(store => {
        if (data && data._id) {
          socket.join(data._id + ":service");
          socket.join("employee:" + data._id);
          socket.join(data._id + ":chat");
          socket.join("call:" + data._id);
          socket.join("chat:" + store._id + ":" + data._id);
          ChatHelper.joinTeamRooms(socket, data._id, store)
        }
        Helper.sendSocketResponse(socket, scb, store.settings.salesarmy.location, {event: "location:config:success"});
      });
  });

  socket.on("sales:team:members:getAll", (data, scb) => {
    Helper.getStore(socket)
      .then(function (store) {
        if (typeof store !== 'undefined' && store._id) {
          var page = _.isUndefined(data.filters.page) ? 1 : data.filters.page;
          var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
          var sort = {createdAt: "desc"};
          if (!_.isUndefined(data.filters.limit)) {
            if (parseInt(data.filters.limit) === -1) {
              limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
            } else {
              if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                limit = data.filters.limit;
              } else {
                limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              }
            }
          }
          var options = {
            page: parseInt(page),
            limit: parseInt(limit),
            sort: sort,
            lean: true,
            populate: [{
              path: "employee",
              model: "Sales-Employee",
              select: "_id firstName lastName email phone profileColor"
            }],
            select: 'employee'
          };
          var qf = {store: store._id, isDeleted: false, team: data.teams};
          TeamRelation.paginate(qf, options).then(function (documents) {
            Helper.sendSocketResponse(socket, scb, documents, {
              event: "sales:team:members:getAll:success",
              forceCallback: true
            });
          });
        }
      });
  });

  socket.on("sales:connect:chat", data => {
    Helper.getStore(socket)
      .then(store => {
        if (data && data._id) {
          socket.join(data._id + ":service");
          socket.join("employee:" + data._id);
          socket.join(data._id + ":chat");
          socket.join("call:" + data._id);
          socket.join("chat:" + store._id + ":" + data._id);
          ChatHelper.joinTeamRooms(socket, data._id, store)
        }
        socket.emit("sales:connect:chat:success", {});
      });
  });

  socket.on("sales:chat:getAll", (data, scb) => {
    Helper.checkEmployeeAccess(socket, {})
      .then(seller => {
        Helper.getStore(socket)
          .then(store => {
            ChatHelper.getTeamRooms(seller.user._id, store)
              .then(relations => {
                Helper.sendSocketResponse(socket, scb, relations, {event: "sales:chat:getAll:success"});
              })
          });
      });
  });

  socket.on("sales:chat:get", (data, scb) => {
    Helper.checkEmployeeAccess(socket, {})
      .then(seller => {
        Helper.getStore(socket)
          .then(store => {
            var q = {
              isDeleted: false,
              store: store._id
            };
            if (data.team) q.team = data.team;
            else q.members = data.members;
            Chat.findOne(q)
              .then(chat => {
                if (chat) {
                  if (data.message) {
                    ChatMessage.create({
                      chatId: chat._id,
                      message: data.message,
                      store: store._id,
                      sender: seller.user._id
                    }).then(message => {
                      if (chat.team) {
                        message.team = chat.team;
                        io.sockets.in(chat.team._id + ":chat").emit('new-message', message);
                      } else {
                        _.map(chat.members, function (member) {
                          io.sockets.in(member + ":chat").emit('new-direct-message', message);
                        })
                      }
                    });
                  }
                  Helper.sendSocketResponse(socket, scb, chat, {event: "sales:chat:get:success"});
                } else {
                  var ob = {
                    store: store._id
                  };
                  if (data.team) {
                    ob.team = data.team
                  } else ob.members = data.members;
                  Chat.create(ob)
                    .then(chat => {
                      if (data.message) {
                        ChatMessage.create({
                          chatId: chat._id,
                          message: data.message,
                          store: store._id,
                          sender: seller.user._id
                        }).then(message => {
                          if (chat.team) {
                            if (message.toObject) message = message.toObject();
                            message.sentBy = chat.team.name;
                            io.sockets.in(chat.team._id + ":chat").emit('new-team-message', message);
                          } else {
                            _.map(chat.members, function (member) {
                              if (seller.user._id != member) io.sockets.in(member + ":chat").emit('new-direct-message', message);
                            })
                          }
                        });
                      }
                      Helper.sendSocketResponse(socket, scb, chat, {event: "sales:chat:get:success"});
                    })
                }
              })
          })
      }).catch(err => {
      Helper.sendSocketErrorResponse(socket, scb, "Something went wrong. Please try again later.", {event: "sales:chat:get:error"});
    });
  });

  socket.on("sales:message:get", (data, scb) => {
    Helper.checkEmployeeAccess(socket, {})
      .then(seller => {
        Helper.getStore(socket)
          .then(store => {
            Chat.findOne({_id: data.chatId, store: store._id})
              .then(chat => {
                if (!_.isNull(chat)) {
                  data.filters = data.filters || {};
                  var page = _.isUndefined(data.filters.page) ? 1 : data.filters.page;
                  var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  if (!_.isUndefined(data.filters.limit)) {
                    if (parseInt(data.filters.limit) === -1) {
                      limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                    } else {
                      if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                        limit = data.filters.limit;
                      } else {
                        limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                      }
                    }
                  }
                  var options = {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    sort: '-createdAt',
                    lean: true,
                    populate: {path: "sender", model: "Sales-Employee", select: "_id firstName lastName"},
                    select: {message: 1, sender: 1, _id: 1, createdAt: 1}
                  };
                  var qf = {
                    chatId: chat._id,
                    store: store._id
                  };
                  ChatMessage.paginate(qf, options).then(function (result) {
                    if (result) {
                      Helper.sendSocketResponse(socket, scb, result, {
                        event: "sales:message:get:success",
                        forceCallback: true
                      });
                    } else {
                      Helper.sendSocketErrorResponse(socket, scb, {
                        err: true,
                        message: "No Data found."
                      }, {event: "sales:message:get:error", forceCallback: true});
                    }
                  }).catch(function (err) {
                    Helper.sendSocketErrorResponse(socket, scb, {
                      err: true,
                      message: "No Data found."
                    }, {event: "sales:message:get:error", forceCallback: true});
                  });
                } else {
                  Helper.sendSocketErrorResponse(socket, scb, {
                    err: true,
                    message: "No Data found."
                  }, {event: "sales:message:get:error", forceCallback: true});
                }
              });
          });
      }).catch(err => {
      Helper.sendSocketErrorResponse(socket, scb, "Something went wrong. Please try again later.", {
        event: "sales:message:get:error",
        forceCallback: true
      });
    });
  });

  socket.on("sales:message:add", (data, scb) => {
    Helper.checkEmployeeAccess(socket, {})
      .then(seller => {
        Helper.getStore(socket)
          .then(store => {
            Chat.findOne({_id: data.chatId, store: store._id})
              .then(chat => {
                if (chat.toObject) chat = chat.toObject();
                ChatMessage.create({
                  chatId: data.chatId,
                  message: data.message,
                  store: store._id,
                  sender: seller.user._id
                }).then(message => {
                  if (chat.team) {
                    if (message.toObject) message = message.toObject();
                    message.sentBy = chat.team.name;
                    ChatMessage.populate(message, [{
                      path: 'sender',
                      model: 'Sales-Employee',
                      select: {
                        _id: 1,
                        firstName: 1,
                        lastName: 1
                      }
                    }]).then(message => {
                      io.sockets.in(chat.team._id + ":chat").emit('new-team-message', message);
                    });
                  } else {
                    ChatMessage.populate(message, [{
                      path: 'sender',
                      model: 'Sales-Employee',
                      select: {
                        _id: 1,
                        firstName: 1,
                        lastName: 1
                      }
                    }]).then(message => {
                      if (message.toObject) message = message.toObject();
                      var membersSent = [];
                      _.map(chat.members, function (member) {
                        if (membersSent.indexOf(member.toString()) == -1) io.sockets.in(member + ":chat").emit('new-direct-message', message);
                        membersSent.push(member.toString());
                      });
                    });
                  }
                  Helper.sendSocketResponse(socket, scb, message, {event: "sales:message:add:success"});
                });
              });
          });
      }).catch(err => {
      Helper.sendSocketErrorResponse(socket, scb, "Something went wrong. Please try again later.", {event: "sales:message:add:error"});
    });
  });

};