'use strict';
var Helper = require("../../app/api/shared/server.helper.js"),
  Places = require('../api/models/server.geofence.model');

module.exports.listen = function (io, socket) {

  socket.on("sales:place:get", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (typeof store !== 'undefined' && store._id) {
              var page = _.isUndefined(data.filters.page) ? 0 : data.filters.page;
              var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
              var sort = {createdAt: "desc"};
              if (!_.isUndefined(data.filters.limit)) {
                if (parseInt(data.filters.limit) === -1) {
                  limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
                } else {
                  if (parseInt(data.filters.limit) !== -1 && data.filters.limit !== undefined) {
                    limit = data.filters.limit;
                  } else {
                    limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
                  }
                }
              }
              var options = {
                page: parseInt(page),
                limit: parseInt(limit),
                sort: sort,
                lean: true,
                populate: [{path: "file", model: "PrivateFile", select: '_id metadata fileId url store'}]
              };
              var qf = {store: store._id, isDeleted: false};
              if (data.placeId) {
                qf._id = data.placeId;
              }
              qf.employee = data.filters.employee;
              if (data.filters.searchText && data.filters.searchText.length > 0) {
                qf['$or'] = [];
                qf['$or'].push({'name': {'$regex': data.filters.searchText, '$options': 'i'}});
                qf['$or'].push({'mobile': {'$regex': data.filters.searchText, '$options': 'i'}});
                qf['$or'].push({'information.vehicleNumber': {'$regex': data.filters.searchText, '$options': 'i'}});
                qf['$or'].push({'information.unitNumber': {'$regex': data.filters.searchText, '$options': 'i'}});
              }
              Places.paginate(qf, options).then(function (documents) {
                Helper.sendSocketResponse(socket, scb, documents, {event: "sales:place:get:success"});
              });
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:place:get:error"});
            }
          });
      });
  });

  socket.on("sales:place:add", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data.place) {
              if (data.place._id) {
                Places.findOneAndUpdate({
                  _id: data.place._id,
                  store: store._id,
                  isDeleted: false
                }, {
                  $set: {
                    name: data.place.name,
                    radius: data.place.radius,
                    'location.coordinates': data.place.location.coordinates
                  }
                }, {new: true})
                  .then(exp => {
                    Helper.sendSocketResponse(socket, scb, exp, {event: "sales:place:add:success"});
                  });
              } else {
                data.place.store = store._id;
                Places.create(data.place)
                  .then(exp => {
                    Helper.sendSocketResponse(socket, scb, exp, {event: "sales:place:add:success"});
                  }).catch(err => {
                  _logger.error(err);
                  Helper.sendSocketErrorResponse(socket, scb, {message: "Something went wrong. Please try again later."}, {event: "sales:place:add:error"});
                });
              }

            }
          });
      });
  });
  socket.on("sales:place:delete", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            if (data._id) {
              Places.findOneAndUpdate({
                _id: data._id,
                store: store._id,
                isDeleted: false
              }, {isDeleted: true}, {new: true})
                .then(exp => {
                  Helper.sendSocketResponse(socket, scb, exp, {event: "sales:place:delete:success"});
                })
            } else {
              Helper.sendSocketErrorResponse(socket, scb, {
                message: "Something went wrong. Please try again later.",
                event: "sales:place:delete:error"
              })
            }
          })
      })

  })
};