'use strict';
var MEETING = require("../socket/shared/server.socket.events").MEETING,
  Helper = require("../../app/api/shared/server.helper.js"),
  Controller = require('../api/controllers/server.meeting.controller'),
  Calendar = require('../api/models/server.calendar.model'),
  ST = require('stjs'),
  CAR_KEYS = require('../api/shared/server.filter.keys').feed;


module.exports.listen = function (io, socket) {

  socket.on("calendar:delete", function (data, scb) {
    Calendar.findOneAndUpdate({_id: data._id}, {$set: {isDeleted: true}}, {new: true})
      .then(event => {
        Helper.sendSocketResponse(socket, scb, {}, {event: "calendar:delete:success"});
      })
  });
  socket.on("calendar:update", function (data, scb) {
    Helper.getStore(socket)
      .then(store => {
        var query = {store: store._id, isDeleted: false};
        var template = {
          title: "{{title}}",
          start: "{{start}}",
          end: "{{end}}",
          employee: "{{other.employee ? other.employee : null}}",
          address: "{{other.address || null}}",
          companyName: "{{other.companyName || null}}",
          contactPerson: "{{other.contactPerson || null}}",
          location: "{{other.location || null}}",
          status: "{{other.status || null}}",
          color: "{{other.color || null}}",
          remarks: "{{other.remarks || null}}",
          _id: "{{other._id || null}}"
        };
        var updateObj = ST.select(data)
          .transformWith(template)
          .root();
        if (updateObj._id && !_.isNull(updateObj._id)) {
          query._id = updateObj._id;
          delete updateObj._id;
          Calendar.findOneAndUpdate(query, updateObj, {new: true})
            .then(event => {
              Helper.sendSocketResponse(socket, scb, {_id: query._id}, {event: "calendar:update:success"});
            })
        } else {
          updateObj = _.extend(updateObj, query);
          delete updateObj._id;
          Calendar.create(updateObj)
            .then(event => {
              Helper.sendSocketResponse(socket, scb, {_id: event._id}, {event: "calendar:update:success"});
            })
        }
      });
  });


  socket.on("calendar:get", function (data, scb) {
    Helper.getStore(socket)
      .then(store => {
        var query = {
          start: {$gte: new Date(_MOMENT(data.start).startOf('day'))},
          end: {$lte: new Date(_MOMENT(data.end).endOf('day'))},
          store: store._id,
          isDeleted: false
        };
        if (data.employee) query.employee = data.employee;
        Calendar.find(query).sort({start: "asc"})
          .then(events => {
            var data = {
              items: events
            };
            var template = {
              "{{#each items}}": {
                title: "{{title}}",
                class: "{{color}}",
                start: "{{start}}",
                end: "{{end}}",
                other: {
                  address: "{{address}}",
                  employee: "{{employee}}",
                  _id: "{{_id}}",
                  companyName: "{{companyName}}",
                  contactPerson: "{{contactPerson}}",
                  location: "{{location}}",
                  color: "{{color}}",
                  status: "{{status}}",
                  remarks: "{{remarks}}"
                }
              }
            };
            Helper.sendSocketResponse(socket, scb, ST.select(data)
              .transformWith(template)
              .root(), {event: "calendar:get:success"});
          })
      });
  });

  socket.on(MEETING.ADD.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, CAR_KEYS.add)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.meeting.store = store._id;
            var req = {
              body: data.meeting,
              query: Helper.createQueryString(socket, data.filters),
            };
            Controller.add(req)
              .then(meeting => {
                socket.emit(MEETING.ADD.SUCCESS, meeting);
              })
              .catch(error => {
                if (error) {
                  _logger.error(error);
                  socket.emit(MEETING.ADD.ERROR, "Error occurred while adding meeting");
                }
              });
          });
      });
  });

  socket.on(MEETING.GET_ALL.EVENT, function (data) {
    Helper.getStore(socket)
      .then(store => {
        data.filters = data.filters || {};
        data.filters.store = store._id;
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters)
        };
        Controller.getAll(req)
          .then(function (data) {
            socket.emit(MEETING.GET_ALL.SUCCESS, data);
          })
          .catch(function (error) {
            _logger.error(error);
            socket.emit(MEETING.GET_ALL.ERROR, "Error occurred while getting list of poss.");
          });
      });
  });

  socket.on(MEETING.GET.EVENT, (data) => {
    var req = {
      body: data,
      query: Helper.createQueryString(socket, data.filters)
    };
    Controller.get(req).then(meeting => {
      socket.emit(MEETING.GET.SUCCESS, meeting);
    }).catch(error => {
      if (error) {
        _logger.error(error);
        socket.emit(MEETING.GET.ERROR, "Error occurred while getting a meeting with Id: " + data._id);
      }
    });
  });

  socket.on(MEETING.GET.BY_EMPLOYEE.EVENT, (data) => {
    var req = {
      body: data,
      query: Helper.createQueryString(socket, data.filters)
    };
    Controller.getMeetingsForEmployee(req)
      .then(meeting => {
        socket.emit(MEETING.GET.BY_EMPLOYEE.SUCCESS, meeting);
      }).catch(error => {
      if (error) {
        _logger.error(error);
        socket.emit(MEETING.GET.BY_EMPLOYEE.ERROR, "Error occurred while getting a meeting with Id: " + data._id);
      }
    });
  });

  socket.on(MEETING.UPDATE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, CAR_KEYS.update)
      .then(response => {
        var req = {
          body: data.meeting,
          query: Helper.createQueryString(socket, data.filters),
        };
        Controller.update(req)
          .then(product => {
            socket.emit(MEETING.UPDATE.SUCCESS, product);
          })
          .catch(error => {
            if (error) {
              _logger.error(error);
              socket.emit(MEETING.UPDATE.ERROR, "Error occurred while updating meeting with ID: " + data.meeting._id);
            }
          });
      })
  });

  socket.on(MEETING.DELETE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, CAR_KEYS.delete)
      .then(response => {
        var req = {
          body: data,
        };
        Controller.delete(req)
          .then(product => {
            socket.emit(MEETING.DELETE.SUCCESS, product);
          })
          .catch(error => {
            if (error) {
              _logger.error(error);
              socket.emit(MEETING.DELETE.ERROR, "Error occurred while deleting meeting with Id: " + data._id);
            }
          });
      });
  });


  socket.on(MEETING.GET.BY_COUNT.EVENT, (data) => {
    Helper.checkEmployeeAccess(socket, {})
      .then(response => {
        var req = {
          body: data,
          employeeId: response.user._id,
          query: Helper.createQueryString(socket, data.filters)
        };
        Controller.getCountsOfMeetings(req).then(response => {
          socket.emit(MEETING.GET.BY_COUNT.SUCCESS, response);
        }).catch(error => {
          if (error) {
            _logger.error(error);
            socket.emit(MEETING.GET.BY_COUNT.ERROR, "Error occurred while getting a meeting with Id: ");
          }
        });
      });
  });

  socket.on("employee:calendar:availability", function (data, scb) {
    Helper.getAccessTokenPromised(socket, data.auth)
      .then(response => {
        var query = {
          employee: data.employee,
          start: {$gte: new Date(_MOMENT(data.start).startOf('day'))},
          end: {$lte: new Date(_MOMENT(data.end).endOf('day'))},
          isDeleted: false
        };
        Calendar.paginate(query, {
          lean: true,
          limit: _CONFIG.MONGODB.MAX_DOCUMENTS,
          select: 'start _id'
        }).then(function (res) {
          if (res.docs && res.docs.length > 0) {
            var returnObj = _.uniq(_.map(res.docs, function (d) {
              return _MOMENT(d.start).format("DD/MM/YYYY");
            }));
            Helper.sendSocketResponse(socket, scb, returnObj, {event: "employee:calendar:availability:success"});
          } else {
            Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:calendar:availability:error"});
          }
        }).catch(function (err) {
          _logger.error(err);
          Helper.sendSocketErrorResponse(socket, scb, {message: "No Data found."}, {event: "employee:calendar:availability:error"});
        });
      });
  });

};