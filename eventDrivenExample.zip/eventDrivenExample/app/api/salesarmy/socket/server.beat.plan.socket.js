'use strict';
var request = require("request-promise"),
  BEAT_PLAN = require("../socket/shared/server.socket.events").BEAT_PLAN,
  Helper = require("../../app/api/shared/server.helper.js"),
  async = require("async"),
  BeatPlan = require('../api/models/server.beatplan.model'),
  Controller = require('../api/controllers/server.beat.plan.controller'),
  BEAT_PLAN_KEYS = require('../api/shared/server.filter.keys').feed;
module.exports.listen = function (io, socket) {

  socket.on(BEAT_PLAN.ADD.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, BEAT_PLAN_KEYS.add)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            var req = {
              body: data.beatPlan,
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : BEAT_PLAN_KEYS.view.guest.keys
            };
            data.filters = data.filters || {};
            data.beatPlan.store = store._id;
            store.domain = store.domain ? store.domain : store.subdomain;
            Controller.add(req)
              .then(beatPlan => {
                socket.emit(BEAT_PLAN.ADD.SUCCESS, beatPlan);
              })
              .catch(error => {
                if (error) {
                  _logger.error(error);
                  socket.emit(BEAT_PLAN.ADD.ERROR, "Error occurred while adding beatPlan");
                }
              });
          });
      });
  });

  socket.on(BEAT_PLAN.GET_ALL.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, BEAT_PLAN_KEYS.view)
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            data.filters = data.filters || {};
            data.filters.store = store._id;
            var req = {
              query: Helper.createQueryString(socket, data.filters),
              filterKeys: response && response.filterKeys ? response.filterKeys : BEAT_PLAN_KEYS.view.guest.keys
            };
            Controller.getAll(req)
              .then(function (body) {
                socket.emit(BEAT_PLAN.GET_ALL.SUCCESS, body);
              })
              .catch(function (error) {
                if (error) {
                  _logger.error(error);
                  socket.emit(BEAT_PLAN.GET_ALL.ERROR, "error occurred while getting a list of beatPlans");
                }
              })
          });
      });
  });

  socket.on(BEAT_PLAN.GET.EVENT, (data) => {
    Helper.getStore(socket)
      .then(store => {
        var req = {
          body: data,
          // store : store._id,
          query: Helper.createQueryString(socket, data.filters)
        };
        Controller.get(req).then(res => {
          if (res == false) {
            socket.emit(BEAT_PLAN.GET.ERROR, "Error occurred while getting a BeatPlan with Id: " + data._id);
          } else {
            socket.emit(BEAT_PLAN.GET.SUCCESS, res);
          }
        }).catch(error => {
          if (error) {
            _logger.error(error);
            socket.emit(BEAT_PLAN.GET.ERROR, "Error occurred while getting a BeatPlan with Id: " + data._id);
          }
        });
      })
  });

  socket.on(BEAT_PLAN.UPDATE.EVENT, function (data, scb) {
    Helper.checkEmployeeAccess(socket, data.auth, BEAT_PLAN_KEYS.update)
      .then(response => {
        var req = {
          body: data.beatPlan,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : BEAT_PLAN_KEYS.view.guest.keys
        };
        Controller.update(req)
          .then(beatPlan => {
            Helper.sendSocketResponse(socket, scb, beatPlan, {event: BEAT_PLAN.UPDATE.SUCCESS});
            return false;
          })
          .catch(error => {
            if (error) {
              _logger.error(error);
              Helper.sendSocketErrorResponse(socket, scb, "Error occurred while updating BeatPlan with ID: " + data.beatPlan._id, {event: BEAT_PLAN.UPDATE.ERROR});
            }
          });
      });
  });

  socket.on(BEAT_PLAN.DELETE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, BEAT_PLAN_KEYS.delete)
      .then(response => {
        var req = {
          body: data,
          query: Helper.createQueryString(socket, data.filters),
          filterKeys: response && response.filterKeys ? response.filterKeys : BEAT_PLAN_KEYS.view.guest.keys
        };
        Controller.delete(req)
          .then(beatPlan => {
            socket.emit(BEAT_PLAN.DELETE.SUCCESS, beatPlan);
          }).catch(error => {
          if (error) {
            _logger.error(error);
            socket.emit(BEAT_PLAN.DELETE.ERROR, "Error occurred while deleting beatPlan with Id: " + data._id);
          }
        });
      });
  });

  socket.on(BEAT_PLAN.DELETE.MULTIPLE.EVENT, function (data) {
    Helper.checkEmployeeAccess(socket, data.auth, BEAT_PLAN_KEYS.delete)
      .then(response => {
        BeatPlan.updateAsync({_id: {$in: data.ids}}, {$set: {isDeleted: true}}, {multi: true})
          .then(function () {
            socket.emit(BEAT_PLAN.DELETE.MULTIPLE.SUCCESS, "Customer Deleted Successfully.");
          })
          .catch(function (error) {
            _logger.error(error);
            socket.emit(BEAT_PLAN.DELETE.MULTIPLE.ERROR, "Error occurred while deleting customer ");
          });
      });
  });


  socket.on(BEAT_PLAN.GET_BY_EMP.EVENT, (data, scb) => {
    Helper.checkEmployeeAccess(socket, {})
      .then(response => {
        Helper.getStore(socket)
          .then(store => {
            var req = {
              body: data,
              employeeId: response.user._id,
              store: store._id,
              query: Helper.createQueryString(socket, data.filters)
            };
            Controller.getByEmpId(req).then(res => {
              Helper.sendSocketResponse(socket, scb, res, {event: BEAT_PLAN.GET_BY_EMP.SUCCESS});
            }).catch(error => {
              if (error) {
                _logger.error(error);
                Helper.sendSocketErrorResponse(socket, scb, "Error occurred while getting a BeatPlan with Id: " + data._id, {event: BEAT_PLAN.GET_BY_EMP.ERROR});
              }
            });
          });
      });
  });
};