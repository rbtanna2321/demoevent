module.exports = {
  "ACTIVITY_LOG": {
    "ADD": {
      "EVENT": "activityLog:add",
      "SUCCESS": "activityLog:add:success",
      "ERROR": "activityLog:add:error"
    },
    "UPDATE": {
      "EVENT": "activityLog:update",
      "SUCCESS": "activityLog:update:success",
      "ERROR": "activityLog:update:error"
    },
    "DELETE": {
      "EVENT": "activityLog:delete",
      "SUCCESS": "activityLog:delete:success",
      "ERROR": "activityLog:delete:error"
    },
    "GET_ALL": {
      "EVENT": "activityLog:getAll",
      "SUCCESS": "activityLog:getAll:success",
      "ERROR": "activityLog:getAll:error"
    },
    "GET": {
      "EVENT": "activityLog:get",
      "SUCCESS": "activityLog:get:success",
      "ERROR": "activityLog:get:error"
    }
  },
  "ADDRESS": {
    "ADD": {
      "EVENT": "address:add",
      "SUCCESS": "address:add:success",
      "ERROR": "address:add:error"
    },
    "UPDATE": {
      "EVENT": "address:update",
      "SUCCESS": "address:update:success",
      "ERROR": "address:update:error"
    },
    "DELETE": {
      "EVENT": "address:delete",
      "SUCCESS": "address:delete:success",
      "ERROR": "address:delete:error"
    },
    "GET_ALL": {
      "EVENT": "address:getAll",
      "SUCCESS": "address:getAll:success",
      "ERROR": "address:getAll:error"
    },
    "GET": {
      "EVENT": "address:get",
      "SUCCESS": "address:get:success",
      "ERROR": "address:get:error"
    }
  },
  "BLOG": {
    "ADD": {
      "EVENT": "blog:add",
      "SUCCESS": "blog:add:success",
      "ERROR": "blog:add:error"
    },
    "UPDATE": {
      "EVENT": "blog:update",
      "SUCCESS": "blog:update:success",
      "ERROR": "blog:update:error"
    },
    "DELETE": {
      "EVENT": "blog:delete",
      "SUCCESS": "blog:delete:success",
      "ERROR": "blog:delete:error"
    },
    "GET_ALL": {
      "EVENT": "blog:getAll",
      "SUCCESS": "blog:getAll:success",
      "ERROR": "blog:getAll:error"
    },
    "GET_ALL_ISFEATURED": {
      "EVENT": "blog:getAllbyIsFeatured",
      "SUCCESS": "blog:getAllbyIsFeatured:success",
      "ERROR": "blog:getAllbyIsFeatured:error"
    },
    "GET": {
      "EVENT": "blog:get",
      "SUCCESS": "blog:get:success",
      "ERROR": "blog:get:error"
    },
    "BY_SLUG": {
      "EVENT": "blog:get:by-slug",
      "SUCCESS": "blog:get:by-slug:success",
      "ERROR": "blog:get:by-slug:error"
    }
  },
  "ANALYTICS": {
    "PRODUCTS": {
      "MOST_VIEWED": {
        "EVENT": "analytics:most:viewed:products",
        "SUCCESS": "analytics:most:viewed:products:success",
        "ERROR": "analytics:most:viewed:products:error"
      }
    },
    "STATISTICS": {
      "LAST_WEEK": {
        "EVENT": "statistics:last:week",
        "SUCCESS": "statistics:last:week:success",
        "ERROR": "statistics:last:week:error"
      },
      "EVENT": "analytics:statistics",
      "SUCCESS": "analytics:statistics:success",
      "ERROR": "analytics:statistics:error"
    },
    "PAGE_COUNT": {
      "EVENT": "page:count",
      "SUCCESS": "page:count:success",
      "ERROR": "page:count:error"
    },
    "TOP_RECORDS": {
      "EVENT": "analytics:top:records",
      "SUCCESS": "analytics:top:records:success",
      "ERROR": "analytics:top:records:error"
    },
    "GET_ALL": {
      "EVENT": "page:count:getAll",
      "SUCCESS": "page:count:getAll:success",
      "ERROR": "page:count:getAll:error"
    }
  },
  "BANK_DETAIL": {
    "ADD": {
      "EVENT": "bankDetail:add",
      "SUCCESS": "bankDetail:add:success",
      "ERROR": "bankDetail:add:error"
    },
    "UPDATE": {
      "EVENT": "bankDetail:update",
      "SUCCESS": "bankDetail:update:success",
      "ERROR": "bankDetail:update:error"
    },
    "DELETE": {
      "EVENT": "bankDetail:delete",
      "SUCCESS": "bankDetail:delete:success",
      "ERROR": "bankDetail:delete:error"
    },
    "GET_ALL": {
      "EVENT": "bankDetail:getAll",
      "SUCCESS": "bankDetail:getAll:success",
      "ERROR": "bankDetail:getAll:error"
    },
    "GET": {
      "BY_HOSTNAME": {
        "EVENT": "bankDetailByHostName:get",
        "SUCCESS": "bankDetailByHostName:get:success",
        "ERROR": "bankDetailByHostName:get:error"
      },
      "EVENT": "bankDetail:get",
      "SUCCESS": "bankDetail:get:success",
      "ERROR": "bankDetail:get:error"
    }
  },
  "CATEGORY": {
    "ADD": {
      "EVENT": "category:add",
      "SUCCESS": "category:add:success",
      "ERROR": "category:add:error"
    },
    "UPDATE": {
      "EVENT": "category:update",
      "SUCCESS": "category:update:success",
      "ERROR": "category:update:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "category:delete:multiple",
        "SUCCESS": "category:delete:multiple:success",
        "ERROR": "category:delete:multiple:error"
      },
      "EVENT": "category:delete",
      "SUCCESS": "category:delete:success",
      "ERROR": "category:delete:error"
    },
    "GET_ALL": {
      "EVENT": "category:getAll",
      "SUCCESS": "category:getAll:success",
      "ERROR": "category:getAll:error"
    },
    "GET": {
      "EVENT": "category:get",
      "SUCCESS": "category:get:success",
      "ERROR": "category:get:error"
    },
    "STORE": {
      "GET_ALL": {
        "EVENT": "category:store:getAll",
        "SUCCESS": "category:store:getAll:success",
        "ERROR": "category:store:getAll:success"
      }
    },
    "SUB_CATEGORY": {
      "ADD": {
        "EVENT": "category:subcategory:add",
        "SUCCESS": "category:subcategory:add:success",
        "ERROR": "category:subcategory:add:error"
      },
      "DELETE": {
        "EVENT": "category:subcategory:delete",
        "SUCCESS": "category:subcategory:delete:success",
        "ERROR": "category:subcategory:delete:error"
      },
      "GET_ALL": {
        "EVENT": "category:subcategory:getAll",
        "SUCCESS": "category:subcategory:getAll:success",
        "ERROR": "category:subcategory:getAll:error"
      }
    },
    "BY_CATEGORYID": {
      "EVENT": "category:get:by:categoryId",
      "SUCCESS": "category:get:by:categoryId:success",
      "ERROR": "category:get:by:categoryId:error"
    },
    "BY_CATEGORY_FIELD": {
      "EVENT": "category:find:by:field",
      "SUCCESS": "category:find:by:field:success",
      "ERROR": "category:find:by:field:error"
    },
    "SEARCH": {
      "BY_ID": {
        "EVENT": "search:category:by:id",
        "SUCCESS": "search:category:by:id:success",
        "ERROR": "search:category:by:id:error"
      },
      "EVENT": "search:categories",
      "SUCCESS": "search:categories:success",
      "ERROR": "search:categories:error"
    }
  },
  "CHAT": {
    "ADD": {
      "EVENT": "chat:add",
      "SUCCESS": "chat:add:success",
      "ERROR": "chat:add:error"
    },
    "UPDATE": {
      "EVENT": "chat:update",
      "SUCCESS": "chat:update:success",
      "ERROR": "chat:update:error"
    },
    "DELETE": {
      "EVENT": "chat:delete",
      "SUCCESS": "chat:delete:success",
      "ERROR": "chat:delete:error"
    },
    "GET_ALL": {
      "EVENT": "chat:getAll",
      "SUCCESS": "chat:getAll:success",
      "ERROR": "chat:getAll:error"
    },
    "GET": {
      "EVENT": "chat:get",
      "SUCCESS": "chat:get:success",
      "ERROR": "chat:get:error"
    },
    "BY_USER": {
      "EVENT": "chat:byUser",
      "SUCCESS": "chat:byUser:success",
      "ERROR": "chat:byUser:error"
    },
    "NOTIFICATION": {
      "SEND": "chat:notification:send",
      "RECEIVE": "chat:notification:receive"
    },
    "CHAT_LEFT": {
      "LEFT": "chat:left"
    },
    "CHAT_TYPING": {
      "TYPING": "chat:typing",
      "TYPING_ON": "chat:typing:on"
    },
    "UNREAD_MESSAGE": {
      "UPDATE": {
        "EVENT": "chat:unreadMessages:update",
        "SUCCESS": "chat:unreadMessages:update:success",
        "ERROR": "chat:unreadMessages:update:error"
      },
      "GET": {
        "EVENT": "chat:unreadMessages:get",
        "SUCCESS": "chat:unreadMessages:get:success",
        "ERROR": "chat:unreadMessages:get:error"
      }
    },
    "CUSTOMER": {
      "EVENT": "chat:customer",
      "SUCCESS": "chat:customer:success",
      "ERROR": "chat:customer:error"
    },
    "GET_SELLERS": {
      "EVENT": "chat:get-sellers",
      "SUCCESS": "chat:get-sellers:success",
      "ERROR": "chat:get-sellers:error"
    }
  },
  "CHECKOUT": {
    "ADD": {
      "EVENT": "checkout:add",
      "SUCCESS": "checkout:add:success",
      "ERROR": "checkout:add:error"
    },
    "UPDATE": {
      "EVENT": "checkout:update",
      "SUCCESS": "checkout:update:success",
      "ERROR": "checkout:update:error"
    },
    "DELETE": {
      "EVENT": "checkout:delete",
      "SUCCESS": "checkout:delete:success",
      "ERROR": "checkout:delete:error"
    },
    "GET_ALL": {
      "EVENT": "checkout:getAll",
      "SUCCESS": "checkout:getAll:success",
      "ERROR": "checkout:getAll:error"
    },
    "GET": {
      "EVENT": "checkout:get",
      "SUCCESS": "checkout:get:success",
      "ERROR": "checkout:get:error"
    }
  },
  "COLLECTION": {
    "ADD": {
      "EVENT": "collection:add",
      "SUCCESS": "collection:add:success",
      "ERROR": "collection:add:error"
    },
    "UPDATE": {
      "EVENT": "collection:update",
      "SUCCESS": "collection:update:success",
      "ERROR": "collection:update:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "collection:delete:multiple",
        "SUCCESS": "collection:delete:multiple:success",
        "ERROR": "collection:delete:multiple:error"
      },
      "EVENT": "collection:delete",
      "SUCCESS": "collection:delete:success",
      "ERROR": "collection:delete:error"
    },
    "GET_ALL": {
      "EVENT": "collection:getAll",
      "SUCCESS": "collection:getAll:success",
      "ERROR": "collection:getAll:error",
      "SOLR": {
        "EVENT": "solr:collection:getAll",
        "SUCCESS": "solr:collection:getAll:success",
        "ERROR": "solr:collection:getAll:error"
      }
    },
    "GET": {
      "BY_COLLECTION_ID": {
        "EVENT": "collection:get:by:collectionId",
        "SUCCESS": "collection:get:by:collectionId:success",
        "ERROR": "collection:get:by:collectionId:error"
      },
      "BY_COLLECTION_PRODUCT": {
        "EVENT": "collection:get:by:product",
        "SUCCESS": "collection:get:by:product:success",
        "ERROR": "collection:get:by:product:error"
      },
      "EVENT": "collection:get",
      "SUCCESS": "collection:get:success",
      "ERROR": "collection:get:error"
    },
    "SEARCH": {
      "EVENT": "search:collections",
      "SUCCESS": "search:collections:success",
      "ERROR": "search:collections:error"
    },
    "SOLR": {
      "GET": {
        "EVENT": "solr:collection:get",
        "SUCCESS": "solr:collection:get:success",
        "ERROR": "solr:collection:get:error"
      }
    }
  },
  "COMPONENT": {
    "ADD": {
      "EVENT": "component:add",
      "SUCCESS": "component:add:success",
      "ERROR": "component:add:error"
    },
    "UPDATE": {
      "EVENT": "component:update",
      "SUCCESS": "component:update:success",
      "ERROR": "component:update:error"
    },
    "DELETE": {
      "EVENT": "component:delete",
      "SUCCESS": "component:delete:success",
      "ERROR": "component:delete:error"
    },
    "GET_ALL": {
      "EVENT": "component:getAll",
      "SUCCESS": "component:getAll:success",
      "ERROR": "component:getAll:error"
    },
    "GET": {
      "EVENT": "component:get",
      "SUCCESS": "component:get:success",
      "ERROR": "component:get:error"
    }
  },
  "CUSTOMER_GROUP": {
    "ADD": {
      "EVENT": "customerGroup:add",
      "SUCCESS": "customerGroup:add:success",
      "ERROR": "customerGroup:add:error"
    },
    "UPDATE": {
      "EVENT": "customerGroup:update",
      "SUCCESS": "customerGroup:update:success",
      "ERROR": "customerGroup:update:error"
    },
    "DELETE": {
      "EVENT": "customerGroup:delete",
      "SUCCESS": "customerGroup:delete:success",
      "ERROR": "customerGroup:delete:error"
    },
    "GET_ALL": {
      "EVENT": "customerGroup:getAll",
      "SUCCESS": "customerGroup:getAll:success",
      "ERROR": "customerGroup:getAll:error"
    },
    "GET": {
      "EVENT": "customerGroup:get",
      "SUCCESS": "customerGroup:get:success",
      "ERROR": "customerGroup:get:error"
    },
    "APPLY_DISCOUNT": {
      "EVENT": "apply:groupDiscount",
      "SUCCESS": "apply:groupDiscount:success",
      "ERROR": "apply:groupDiscount:error"
    },
    "REMOVE_DISCOUNT": {
      "EVENT": "remove:groupDiscount",
      "SUCCESS": "remove:groupDiscount:success",
      "ERROR": "remove:groupDiscount:error"
    }
  },
  "CUSTOMER_SEARCH": {
    "ADD": {
      "EVENT": "customerSearch:add",
      "SUCCESS": "customerSearch:add:success",
      "ERROR": "customerSearch:add:error"
    },
    "UPDATE": {
      "EVENT": "customerSearch:update",
      "SUCCESS": "customerSearch:update:success",
      "ERROR": "customerSearch:update:error"
    },
    "DELETE": {
      "EVENT": "customerSearch:delete",
      "SUCCESS": "customerSearch:delete:success",
      "ERROR": "customerSearch:delete:error"
    },
    "GET_ALL": {
      "EVENT": "customerSearch:getAll",
      "SUCCESS": "customerSearch:getAll:success",
      "ERROR": "customerSearch:getAll:error"
    },
    "GET": {
      "EVENT": "customerSearch:get",
      "SUCCESS": "customerSearch:get:success",
      "ERROR": "customerSearch:get:error"
    }
  },
  "CUSTOMER": {
    "AUTHENTICATE": {
      "EVENT": "customer:authenticate",
      "SUCCESS": "customer:authenticate:success",
      "ERROR": "customer:authenticate:error"
    },
    "VERIFY": {
      "EVENT": "customer:login:verify",
      "SUCCESS": "customer:login:verify:success",
      "ERROR": "customer:login:verify:error"
    },
    "REG": {
      "EVENT": "customer:login:register",
      "SUCCESS": "customer:login:register:success",
      "ERROR": "customer:login:register:error"
    },
    "VALIDATE": {
      "EVENT": "customer:validate",
      "SUCCESS": "customer:validate:success",
      "ERROR": "customer:validate:error"
    },
    "CHECK_AVAILABILITY": {
      "EVENT": "customer:check-availability",
      "SUCCESS": "customer:check-availability:success",
      "ERROR": "customer:check-availability:error"
    },
    "PASSWORD_RECOVERY": {
      "EVENT": "customer:pwdRecovery",
      "SUCCESS": "customer:pwdRecovery:success",
      "ERROR": "customer:pwdRecovery:error"
    },
    "CHANGE_PWD": {
      "EVENT": "customer:changePwd",
      "SUCCESS": "customer:changePwd:success",
      "ERROR": "customer:changePwd:error"
    },
    "CHANGE_PASSWORD": {
      "EVENT": "customer:changePassword",
      "SUCCESS": "customer:changePassword:success",
      "ERROR": "customer:changePassword:error"
    },
    "ADD_PASSWORD": {
      "EVENT": "customer:addPwd",
      "SUCCESS": "customer:addPwd:success",
      "ERROR": "customer:addPwd:error"
    },
    "REGISTER": {
      "EVENT": "customer:register",
      "SUCCESS": "customer:register:success",
      "ERROR": "customer:register:error"
    },
    "ADD": {
      "EVENT": "customer:add",
      "SUCCESS": "customer:add:success",
      "ERROR": "customer:add:error"
    },
    "INVITE": {
      "EVENT": "customer:invite",
      "SUCCESS": "customer:invite:success",
      "ERROR": "customer:invite:error"
    },
    "UPDATE": {
      "EVENT": "customer:update",
      "SUCCESS": "customer:update:success",
      "ERROR": "customer:update:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "customer:delete:multiple",
        "SUCCESS": "customer:delete:multiple:success",
        "ERROR": "customer:delete:multiple:error"
      },
      "EVENT": "customer:delete",
      "SUCCESS": "customer:delete:success",
      "ERROR": "customer:delete:error"
    },
    "GET_ALL": {
      "SOLR": {
        "EVENT": "solr:customer:getAll",
        "SUCCESS": "solr:customer:getAll:success",
        "ERROR": "solr:customer:getAll:error"
      },
      "SOLR_GET": {
        "EVENT": "getAll:customer",
        "SUCCESS": "getAll:customer:success",
        "ERROR": "getAll:customer:error"
      },
      "EVENT": "customer:getAll",
      "SUCCESS": "customer:getAll:success",
      "ERROR": "customer:getAll:error"
    },
    "GET": {
      "EVENT": "customer:get",
      "SUCCESS": "customer:get:success",
      "ERROR": "customer:get:error",
      "BY_INVITATIONID": {
        "EVENT": "customer:get:byInvitationId",
        "SUCCESS": "customer:get:byInvitationId:success",
        "ERROR": "customer:get:byInvitationId:error"
      }
    },
    "ORDER": {
      "EVENT": "customer:order:get",
      "SUCCESS": "customer:order:success:get",
      "ERROR": "customer:order:error:get"
    },
    "DEVICE": {
      "ADD": {
        "EVENT": "customer:device:add",
        "SUCCESS": "customer:device:add:success",
        "ERROR": "customer:device:add:error"
      },
      "GET_ALL": {
        "EVENT": "customer:device:getAll",
        "SUCCESS": "customer:device:getAll:success",
        "ERROR": "customer:device:getAll:error"
      },
      "DELETE": {
        "EVENT": "customer:device:delete:getAll",
        "SUCCESS": "customer:device:delete:success",
        "ERROR": "customer:device:delete:error"
      }
    },
    "ADDRESS": {
      "GET_ALL": {
        "EVENT": "customer:address:getAll",
        "SUCCESS": "customer:address:getAll:success",
        "ERROR": "customer:address:getAll:error"
      }
    },
    "LOGOUT": {
      "EVENT": "customer:logout",
      "SUCCESS": "customer:logout:success",
      "ERROR": "customer:logout:error"
    },
    "PROFILE": {
      "EVENT": "customer:get-profile",
      "SUCCESS": "customer:get-profile:success",
      "ERROR": "customer:get-profile:error"
    }
  },
  "DEVICE": {
    "ADD": {
      "EVENT": "device:add",
      "SUCCESS": "device:add:success",
      "ERROR": "device:add:error"
    },
    "UPDATE": {
      "EVENT": "device:update",
      "SUCCESS": "device:update:success",
      "ERROR": "device:update:error"
    },
    "DELETE": {
      "EVENT": "device:delete",
      "SUCCESS": "device:delete:success",
      "ERROR": "device:delete:error"
    },
    "GET_ALL": {
      "EVENT": "device:getAll",
      "SUCCESS": "device:getAll:success",
      "ERROR": "device:getAll:error"
    },
    "GET": {
      "EVENT": "device:get",
      "SUCCESS": "device:get:success",
      "ERROR": "device:get:error"
    }
  },
  "DISCOUNT": {
    "ADD": {
      "EVENT": "discount:add",
      "SUCCESS": "discount:add:success",
      "ERROR": "discount:add:error"
    },
    "UPDATE": {
      "EVENT": "discount:update",
      "SUCCESS": "discount:update:success",
      "ERROR": "discount:update:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "discount:delete:multiple",
        "SUCCESS": "discount:delete:multiple:success",
        "ERROR": "discount:delete:multiple:error"
      },
      "BY_CART": {
        "EVENT": "discount:remove:byCartId",
        "SUCCESS": "discount:remove:byCartId:success",
        "ERROR": "discount:remove:byCartId:error"
      },
      "EVENT": "discount:delete",
      "SUCCESS": "discount:delete:success",
      "ERROR": "discount:delete:error"
    },
    "GET_ALL": {
      "SOLR": {
        "EVENT": "solr:discount:getAll",
        "SUCCESS": "solr:discount:getAll:success",
        "ERROR": "solr:discount:getAll:error"
      },
      "EVENT": "discount:getAll",
      "SUCCESS": "discount:getAll:success",
      "ERROR": "discount:getAll:error"
    },
    "GET": {
      "BY_CODE": {
        "EVENT": "discount:byCode",
        "SUCCESS": "discount:byCode:success",
        "ERROR": "discount:byCode:error"
      },
      "BY_PRODUCT": {
        "EVENT": "get:offers:by:product",
        "SUCCESS": "get:offers:by:product:success",
        "ERROR": "get:offers:by:product:error"
      },
      "BY_CUSTOMER": {
        "EVENT": "get:offers:by:customer",
        "SUCCESS": "get:offers:by:customer:success",
        "ERROR": "get:offers:by:customer:error"
      },
      "EVENT": "discount:get",
      "SUCCESS": "discount:get:success",
      "ERROR": "discount:get:error"
    },
    "CHECK_AVAILABILITY": {
      "EVENT": "discount:check-availability",
      "SUCCESS": "discount:check-availability:success",
      "ERROR": "discount:check-availability:error"
    }
  },
  "ENUM": {
    "NOTIFICATION": {
      "EVENT": "enum:notification",
      "SUCCESS": "enum:notification:success",
      "ERROR": "enum:notification:error"
    },
    "PRODUCT_OPTION": {
      "EVENT": "enum:productOption",
      "SUCCESS": "enum:productOption:success",
      "ERROR": "enum:productOption:error"
    },
    "ADDRESS": {
      "EVENT": "enum:address",
      "SUCCESS": "enum:address:success",
      "ERROR": "enum:address:error"
    },
    "PHONE": {
      "EVENT": "enum:phone",
      "SUCCESS": "enum:phone:success",
      "ERROR": "enum:phone:error"
    },
    "DISCOUNT": {
      "EVENT": "enum:discount",
      "SUCCESS": "enum:discount:success",
      "ERROR": "enum:discount:error"
    },
    "PAYMENT_DETAIL": {
      "EVENT": "enum:paymentDetail",
      "SUCCESS": "enum:paymentDetail:success",
      "ERROR": "enum:paymentDetail:error"
    },
    "ORDER": {
      "EVENT": "enum:order",
      "SUCCESS": "enum:order:success",
      "ERROR": "enum:order:error"
    },
    "RATING": {
      "EVENT": "enum:rating",
      "SUCCESS": "enum:rating:success",
      "ERROR": "enum:rating:error"
    },
    "REFUND": {
      "EVENT": "enum:refund",
      "SUCCESS": "enum:refund:success",
      "ERROR": "enum:refund:error"
    },
    "SELLER": {
      "EVENT": "enum:seller",
      "SUCCESS": "enum:seller:success",
      "ERROR": "enum:seller:error"
    },
    "SHIPMENT": {
      "EVENT": "enum:shipment",
      "SUCCESS": "enum:shipment:success",
      "ERROR": "enum:shipment:error"
    },
    "SHOPPING_CART": {
      "EVENT": "enum:shoppingCart",
      "SUCCESS": "enum:shoppingCart:success",
      "ERROR": "enum:shoppingCart:error"
    },
    "TRANSACTION": {
      "EVENT": "enum:transaction",
      "SUCCESS": "enum:transaction:success",
      "ERROR": "enum:transaction:error"
    },
    "THEME": {
      "EVENT": "enum:theme",
      "SUCCESS": "enum:theme:success",
      "ERROR": "enum:theme:error"
    },
    "JOBS": {
      "EVENT": "enum:jobs",
      "SUCCESS": "enum:jobs:success",
      "ERROR": "enum:jobs:error"
    },
    "COUPONS": {
      "EVENT": "enum:coupons",
      "SUCCESS": "enum:coupons:success",
      "ERROR": "enum:coupons:error"
    },
    "SMS": {
      "EVENT": "enum:sms",
      "SUCCESS": "enum:sms:success",
      "ERROR": "enum:sms:error"
    }
  },
  "ERROR": {
    "ADD": {
      "EVENT": "error:add",
      "SUCCESS": "error:add:success",
      "ERROR": "error:add:error"
    },
    "UPDATE": {
      "EVENT": "error:update",
      "SUCCESS": "error:update:success",
      "ERROR": "error:update:error"
    },
    "DELETE": {
      "EVENT": "error:delete",
      "SUCCESS": "error:delete:success",
      "ERROR": "error:delete:error"
    },
    "GET_ALL": {
      "EVENT": "error:getAll",
      "SUCCESS": "error:getAll:success",
      "ERROR": "error:getAll:error"
    },
    "GET": {
      "EVENT": "error:get",
      "SUCCESS": "error:get:success",
      "ERROR": "error:get:error"
    }
  },
  "FAQ": {
    "ADD": {
      "EVENT": "faq:add",
      "SUCCESS": "faq:add:success",
      "ERROR": "faq:add:error"
    },
    "UPDATE": {
      "EVENT": "faq:update",
      "SUCCESS": "faq:update:success",
      "ERROR": "faq:update:error"
    },
    "DELETE": {
      "EVENT": "faq:delete",
      "SUCCESS": "faq:delete:success",
      "ERROR": "faq:delete:error"
    },
    "GET_ALL": {
      "EVENT": "faq:getAll",
      "SUCCESS": "faq:getAll:success",
      "ERROR": "faq:getAll:error"
    },
    "GET": {
      "EVENT": "faq:get",
      "SUCCESS": "faq:get:success",
      "ERROR": "faq:get:error"
    }
  },
  "FILE": {
    "ADD": {
      "EVENT": "file:add",
      "SUCCESS": "file:add:success",
      "ERROR": "file:add:error"
    },
    "UPDATE": {
      "EVENT": "file:update",
      "SUCCESS": "file:update:success",
      "ERROR": "file:update:error"
    },
    "DELETE": {
      "EVENT": "file:delete",
      "SUCCESS": "file:delete:success",
      "ERROR": "file:delete:error"
    },
    "PHOTOGRAPHER": {
      "EVENT": "photographer:store:file",
      "SUCCESS": "photographer:store:file:success",
      "ERROR": "photographer:store:file:error"
    },
    "GET_ALL": {
      "SOLR": {
        "EVENT": "solr:file:getAll",
        "SUCCESS": "solr:file:getAll:success",
        "ERROR": "solr:file:getAll:error"
      },
      "EVENT": "file:getAll",
      "SUCCESS": "file:getAll:success",
      "ERROR": "file:getAll:error"
    },
    "GET": {
      "EVENT": "file:get",
      "SUCCESS": "file:get:success",
      "ERROR": "file:get:error"
    },
    "PEXELS": {
      "POPULAR": {
        "EVENT": "file:pexels",
        "SUCCESS": "file:pexels:success",
        "ERROR": "file:pexels:error"
      },
      "SEARCH": {
        "EVENT": "file:pexels:search",
        "SUCCESS": "file:pexels:search:success",
        "ERROR": "file:pexels:search:error"
      },
      "IMPORT": {
        "EVENT": "file:pexels:import",
        "SUCCESS": "file:pexels:import:success",
        "ERROR": "file:pexels:import:error"
      }
    }
  },
  "GIFT_CARD": {
    "ADD": {
      "EVENT": "giftCard:add",
      "SUCCESS": "giftCard:add:success",
      "ERROR": "giftCard:add:error"
    },
    "UPDATE": {
      "EVENT": "giftCard:update",
      "SUCCESS": "giftCard:update:success",
      "ERROR": "giftCard:update:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "giftCard:delete:multiple",
        "SUCCESS": "giftCard:delete:multiple:success",
        "ERROR": "giftCard:delete:multiple:error"
      },
      "EVENT": "giftCard:delete",
      "SUCCESS": "giftCard:delete:success",
      "ERROR": "giftCard:delete:error"
    },
    "GET_ALL": {
      "SOLR": {
        "EVENT": "solr:giftCard:getAll",
        "SUCCESS": "solr:giftCard:getAll:success",
        "ERROR": "solr:giftCard:getAll:error"
      },
      "EVENT": "giftCard:getAll",
      "SUCCESS": "giftCard:getAll:success",
      "ERROR": "giftCard:getAll:error"
    },
    "GET": {
      "BY_CARD_NUMBER": {
        "EVENT": "giftCard:byCardNumber",
        "SUCCESS": "giftCard:byCardNumber:success",
        "ERROR": "giftCard:byCardNumber:error"
      },
      "EVENT": "giftCard:get",
      "SUCCESS": "giftCard:get:success",
      "ERROR": "giftCard:get:error"
    },
    "GENERATE": {
      "EVENT": "generate:giftCard",
      "SUCCESS": "generate:giftCard:success"
    },
    "RESEND": {
      "EMAIL": "giftCard:resend:mail",
      "SUCCESS": "giftCard:resend:mail:success",
      "ERROR": "giftCard:resend:mail:error"
    }
  },
  "IMAGE": {
    "ADD": {
      "EVENT": "image:add",
      "SUCCESS": "image:add:success",
      "ERROR": "image:add:error"
    },
    "UPDATE": {
      "EVENT": "image:update",
      "SUCCESS": "image:update:success",
      "ERROR": "image:update:error"
    },
    "DELETE": {
      "EVENT": "image:delete",
      "SUCCESS": "image:delete:success",
      "ERROR": "image:delete:error"
    },
    "GET_ALL": {
      "EVENT": "image:getAll",
      "SUCCESS": "image:getAll:success",
      "ERROR": "image:getAll:error"
    },
    "GET": {
      "EVENT": "image:get",
      "SUCCESS": "image:get:success",
      "ERROR": "image:get:error"
    }
  },
  "IMPORT_EXPORT": {
    "IMPORT": {
      "EVENT": "import:add",
      "SUCCESS": "import:add:success",
      "ERROR": "import:add:error"
    },
    "EXPORT": {
      "EVENT": "export",
      "SUCCESS": "export:success",
      "ERROR": "export:error"
    },
    "INVOICE": {
      "EVENT": "invoice",
      "SUCCESS": "invoice:success",
      "ERROR": "invoice:error"
    },
    "IMPORT_GET_ALL": {
      "EVENT": "import:getAll",
      "SUCCESS": "import:getAll:success",
      "ERROR": "import:getAll:error"
    },
    "DOWNLOAD_SAMPLE": {
      "EVENT": "download-sample",
      "SUCCESS": "download-sample:success",
      "ERROR": "download-sample:error"
    }
  },
  "LIVE_VISITOR": {
    "ADD": {
      "EVENT": "live:visitor:add",
      "SUCCESS": "live:visitor:add:success",
      "ERROR": "live:visitor:add:error"
    },
    "GET": {
      "EVENT": "live:visitor:get",
      "SUCCESS": "live:visitor:success",
      "ERROR": "live:visitor:error"
    }
  },
  "LOGIN_LOG": {
    "ADD": {
      "EVENT": "loginLog:add",
      "SUCCESS": "loginLog:add:success",
      "ERROR": "loginLog:add:error"
    },
    "UPDATE": {
      "EVENT": "loginLog:update",
      "SUCCESS": "loginLog:update:success",
      "ERROR": "loginLog:update:error"
    },
    "DELETE": {
      "EVENT": "loginLog:delete",
      "SUCCESS": "loginLog:delete:success",
      "ERROR": "loginLog:delete:error"
    },
    "GET_ALL": {
      "EVENT": "loginLog:getAll",
      "SUCCESS": "loginLog:getAll:success",
      "ERROR": "loginLog:getAll:error"
    },
    "GET": {
      "EVENT": "loginLog:get",
      "SUCCESS": "loginLog:get:success",
      "ERROR": "loginLog:get:error"
    }
  },
  "LOGISTIC_MASTER": {
    "ADD": {
      "EVENT": "logisticMaster:add",
      "SUCCESS": "logisticMaster:add:success",
      "ERROR": "logisticMaster:add:error"
    },
    "UPDATE": {
      "EVENT": "logisticMaster:update",
      "SUCCESS": "logisticMaster:update:success",
      "ERROR": "logisticMaster:update:error"
    },
    "DELETE": {
      "EVENT": "logisticMaster:delete",
      "SUCCESS": "logisticMaster:delete:success",
      "ERROR": "logisticMaster:delete:error"
    },
    "GET_ALL": {
      "EVENT": "logisticMaster:getAll",
      "SUCCESS": "logisticMaster:getAll:success",
      "ERROR": "logisticMaster:getAll:error"
    },
    "GET": {
      "EVENT": "logisticMaster:get",
      "SUCCESS": "logisticMaster:get:success",
      "ERROR": "logisticMaster:get:error"
    }
  },
  "LOGISTIC": {
    "ADD": {
      "EVENT": "logistic:add",
      "SUCCESS": "logistic:add:success",
      "ERROR": "logistic:add:error"
    },
    "UPDATE": {
      "STATE": {
        "EVENT": "logistic:state:update",
        "SUCCESS": "logistic:state:update:success",
        "ERROR": "logistic:state:update:error"
      },
      "STORE": {
        "EVENT": "store:logistic:update",
        "SUCCESS": "store:logistic:update:success",
        "ERROR": "store:logistic:update:error"
      },
      "EVENT": "logistic:update",
      "SUCCESS": "logistic:update:success",
      "ERROR": "logistic:update:error"
    },
    "DELETE": {
      "EVENT": "logistic:delete",
      "SUCCESS": "logistic:delete:success",
      "ERROR": "logistic:delete:error"
    },
    "GET_ALL": {
      "EVENT": "logistic:getAll",
      "SUCCESS": "logistic:getAll:success",
      "ERROR": "logistic:getAll:error"
    },
    "GET": {
      "EVENT": "logistic:get",
      "SUCCESS": "logistic:get:success",
      "ERROR": "logistic:get:error"
    }
  },
  "MANUFACTURER": {
    "ADD": {
      "EVENT": "manufacturer:add",
      "SUCCESS": "manufacturer:add:success",
      "ERROR": "manufacturer:add:error"
    },
    "UPDATE": {
      "EVENT": "manufacturer:update",
      "SUCCESS": "manufacturer:update:success",
      "ERROR": "manufacturer:update:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "manufacturer:delete:multiple",
        "SUCCESS": "manufacturer:delete:multiple:success",
        "ERROR": "manufacturer:delete:multiple:error"
      },
      "IMAGE": {
        "EVENT": "manufacturer:image:delete",
        "SUCCESS": "manufacturer:image:delete:success",
        "ERROR": "manufacturer:image:delete:error"
      },
      "EVENT": "manufacturer:delete",
      "SUCCESS": "manufacturer:delete:success",
      "ERROR": "manufacturer:delete:error"
    },
    "GET_ALL": {
      "SOLR": {
        "EVENT": "solr:manufacturer:getAll",
        "SUCCESS": "solr:manufacturer:getAll:success",
        "ERROR": "solr:manufacturer:getAll:error"
      },
      "EVENT": "manufacturer:getAll",
      "SUCCESS": "manufacturer:getAll:success",
      "ERROR": "manufacturer:getAll:error"
    },
    "GET": {
      "EVENT": "manufacturer:get",
      "SUCCESS": "manufacturer:get:success",
      "ERROR": "manufacturer:get:error",
      "BY_SLUG": {
        "EVENT": "get:manufacturer:by:slug",
        "SUCCESS": "get:manufacturer:by:slug:success",
        "ERROR": "get:manufacturer:by:slug:error"
      }
    },
    "SEARCH": {
      "BY_ID": {
        "EVENT": "search:manufacturer:by:id",
        "SUCCESS": "search:manufacturer:by:id:success",
        "ERROR": "search:manufacturer:by:id:error"
      }
    }
  },
  "NEWSLETTER_EMAIL": {
    "ADD": {
      "EVENT": "newsLetterEmail:add",
      "SUCCESS": "newsLetterEmail:add:success",
      "ERROR": "newsLetterEmail:add:error"
    },
    "UPDATE": {
      "EVENT": "newsLetterEmail:update",
      "SUCCESS": "newsLetterEmail:update:success",
      "ERROR": "newsLetterEmail:update:error"
    },
    "DELETE": {
      "EVENT": "newsLetterEmail:delete",
      "SUCCESS": "newsLetterEmail:delete:success",
      "ERROR": "newsLetterEmail:delete:error"
    },
    "GET_ALL": {
      "EVENT": "newsLetterEmail:getAll",
      "SUCCESS": "newsLetterEmail:getAll:success",
      "ERROR": "newsLetterEmail:getAll:error"
    },
    "GET": {
      "EVENT": "newsLetterEmail:get",
      "SUCCESS": "newsLetterEmail:get:success",
      "ERROR": "newsLetterEmail:get:error"
    }
  },
  "NEWSLETTER_SUBSCRIPTION": {
    "ADD": {
      "EVENT": "newsLetterSubscription:add",
      "SUCCESS": "newsLetterSubscription:add:success",
      "ERROR": "newsLetterSubscription:add:error"
    },
    "UPDATE": {
      "EVENT": "newsLetterSubscription:update",
      "SUCCESS": "newsLetterSubscription:update:success",
      "ERROR": "newsLetterSubscription:update:error"
    },
    "DELETE": {
      "EVENT": "newsLetterSubscription:delete",
      "SUCCESS": "newsLetterSubscription:delete:success",
      "ERROR": "newsLetterSubscription:delete:error"
    },
    "GET_ALL": {
      "TYPE": {
        "EVENT": "newsLetterSubscriptionType:getAll",
        "SUCCESS": "newsLetterSubscriptionType:getAll:success",
        "ERROR": "newsLetterSubscriptionType:getAll:error"
      },
      "EVENT": "newsLetterSubscription:getAll",
      "SUCCESS": "newsLetterSubscription:getAll:success",
      "ERROR": "newsLetterSubscription:getAll:error"
    },
    "GET": {
      "BY_CUSTOMER": {
        "EVENT": "newsLetterSubscription:by-customer",
        "SUCCESS": "newsLetterSubscription:by-customer:success",
        "ERROR": "newsLetterSubscription:by-customer:error"
      },
      "EVENT": "newsLetterSubscription:get",
      "SUCCESS": "newsLetterSubscription:get:success",
      "ERROR": "newsLetterSubscription:get:error"
    }
  },
  "NOTIFICATION": {
    "ADD": {
      "EVENT": "notification:add",
      "SUCCESS": "notification:add:success",
      "ERROR": "notification:add:error"
    },
    "UPDATE": {
      "EVENT": "notification:update",
      "SUCCESS": "notification:update:success",
      "ERROR": "notification:update:error"
    },
    "DELETE": {
      "EVENT": "notification:delete",
      "SUCCESS": "notification:delete:success",
      "ERROR": "notification:delete:error"
    },
    "GET_ALL": {
      "EVENT": "notification:getAll",
      "SUCCESS": "notification:getAll:success",
      "ERROR": "notification:getAll:error"
    },
    "GET": {
      "EVENT": "notification:get",
      "SUCCESS": "notification:get:success",
      "ERROR": "notification:get:error"
    }
  },
  "ORDER": {
    "ADD": {
      "EVENT": "order:add",
      "SUCCESS": "order:add:success",
      "ERROR": "order:add:error"
    },
    "UPDATE": {
      "EVENT": "order:update",
      "SUCCESS": "order:update:success",
      "ERROR": "order:update:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "order:delete:multiple",
        "SUCCESS": "order:delete:multiple:success",
        "ERROR": "order:delete:multiple:error"
      },
      "EVENT": "order:delete",
      "SUCCESS": "order:delete:success",
      "ERROR": "order:delete:error"
    },
    "GET_BY_ORDER_ID": {
      "EVENT": "order:get:by:orderId",
      "SUCCESS": "order:get:by:orderId:success",
      "ERROR": "order:get:by:orderId:error"
    },
    "GET_ALL": {
      "SOLR": {
        "EVENT": "solr:order:getAll",
        "SUCCESS": "solr:order:getAll:success",
        "ERROR": "solr:order:getAll:error"
      },
      "OSIV": {
        "EVENT": "osiv:order:getAll",
        "SUCCESS": "osiv:order:getAll:success",
        "ERROR": "osiv:order:getAll:error"
      }
    },
    "GET": {
      "BY_CUSTOMER": {
        "EVENT": "order:byCustomer",
        "SUCCESS": "order:byCustomer:success",
        "ERROR": "order:byCustomer:error"
      },
      "EVENT": "order:get",
      "SUCCESS": "order:get:success",
      "ERROR": "order:get:error"
    },
    "PLACE": {
      "EVENT": "order:place",
      "SUCCESS": "order:place:success",
      "ERROR": "order:place:error"
    },
    "CAPTURE": {
      "EVENT": "order:capture",
      "SUCCESS": "order:capture:success",
      "ERROR": "order:capture:error"
    },
    "CANCEL": {
      "EVENT": "order:cancel",
      "SUCCESS": "order:cancel:success",
      "ERROR": "order:cancel:error",
      "REASONS": {
        "EVENT": "order:cancel-reasons",
        "SUCCESS": "order:cancel-reasons:success",
        "ERROR": "order:cancel-reasons:error"
      }
    }
  },
  "PACKAGE": {
    "ADD": {
      "EVENT": "package:add",
      "SUCCESS": "package:add:success",
      "ERROR": "package:add:error"
    },
    "UPDATE": {
      "EVENT": "package:update",
      "SUCCESS": "package:update:success",
      "ERROR": "package:update:error"
    },
    "DELETE": {
      "EVENT": "package:delete",
      "SUCCESS": "package:delete:success",
      "ERROR": "package:delete:error"
    },
    "UPGRADE": {
      "EVENT": "package:upgrade",
      "SUCCESS": "package:upgrade:success",
      "ERROR": "package:upgrade:error"
    },
    "RENEW": {
      "EVENT": "package:renew",
      "SUCCESS": "package:renew:success",
      "ERROR": "package:renew:error"
    },
    "GET_ALL": {
      "ANGULAR_MODULES": {
        "EVENT": "angular-modules:getAll",
        "SUCCESS": "angular-modules:getAll:success",
        "ERROR": "angular-modules:getAll:error"
      },
      "EVENT": "package:getAll",
      "SUCCESS": "package:getAll:success",
      "ERROR": "package:getAll:error"
    },
    "GET": {
      "EVENT": "package:get",
      "SUCCESS": "package:get:success",
      "ERROR": "package:get:error"
    }
  },
  "PASSCODE": {
    "ADD": {
      "EVENT": "passcode:add",
      "SUCCESS": "passcode:add:success",
      "ERROR": "passcode:add:error"
    },
    "UPDATE": {
      "EVENT": "passcode:update",
      "SUCCESS": "passcode:update:success",
      "ERROR": "passcode:update:error"
    },
    "DELETE": {
      "EVENT": "passcode:delete",
      "SUCCESS": "passcode:delete:success",
      "ERROR": "passcode:delete:error"
    },
    "GET_ALL": {
      "EVENT": "passcode:getAll",
      "SUCCESS": "passcode:getAll:success",
      "ERROR": "passcode:getAll:error"
    },
    "GET": {
      "EVENT": "passcode:get",
      "SUCCESS": "passcode:get:success",
      "ERROR": "passcode:get:error"
    },
    "GENERATE": {
      "EVENT": "passcode:generate",
      "SUCCESS": "passcode:generate:success",
      "ERROR": "passcode:generate:error",
      "EMAIL": {
        "EVENT": "passcode:generate:email",
        "SUCCESS": "passcode:generate:email:success",
        "ERROR": "passcode:generate:email:error"
      }
    },
    "VERIFY": {
      "EVENT": "passcode:verify",
      "SUCCESS": "passcode:verify:success",
      "ERROR": "passcode:verify:error"
    }
  },
  "PAYMENT_DETAIL": {
    "ADD": {
      "EVENT": "paymentDetail:add",
      "SUCCESS": "paymentDetail:add:success",
      "ERROR": "paymentDetail:add:error"
    },
    "UPDATE": {
      "EVENT": "paymentDetail:update",
      "SUCCESS": "paymentDetail:update:success",
      "ERROR": "paymentDetail:update:error"
    },
    "DELETE": {
      "EVENT": "paymentDetail:delete",
      "SUCCESS": "paymentDetail:delete:success",
      "ERROR": "paymentDetail:delete:error"
    },
    "GET_ALL": {
      "EVENT": "paymentDetail:getAll",
      "SUCCESS": "paymentDetail:getAll:success",
      "ERROR": "paymentDetail:getAll:error"
    },
    "GET": {
      "EVENT": "paymentDetail:get",
      "SUCCESS": "paymentDetail:get:success",
      "ERROR": "paymentDetail:get:error"
    }
  },
  "PAYMENT_METHOD": {
    "ADD": {
      "EVENT": "paymentMethod:add",
      "SUCCESS": "paymentMethod:add:success",
      "ERROR": "paymentMethod:add:error"
    },
    "UPDATE": {
      "EVENT": "paymentMethod:update",
      "SUCCESS": "paymentMethod:update:success",
      "ERROR": "paymentMethod:update:error"
    },
    "DELETE": {
      "EVENT": "paymentMethod:delete",
      "SUCCESS": "paymentMethod:delete:success",
      "ERROR": "paymentMethod:delete:error"
    },
    "GET_ALL": {
      "EVENT": "paymentMethod:getAll",
      "SUCCESS": "paymentMethod:getAll:success",
      "ERROR": "paymentMethod:getAll:error"
    },
    "GET": {
      "EVENT": "paymentMethod:get",
      "SUCCESS": "paymentMethod:get:success",
      "ERROR": "paymentMethod:get:error"
    }
  },
  "PERMISSION": {
    "ADD": {
      "EVENT": "permission:add",
      "SUCCESS": "permission:add:success",
      "ERROR": "permission:add:error"
    },
    "CONSTANT": {
      "EVENT": "permission:constant",
      "SUCCESS": "permission:constant:success",
      "ERROR": "permission:constant:error"
    },
    "UPDATE": {
      "BY_SELLER": {
        "EVENT": "permission:bySeller:update",
        "SUCCESS": "permission:bySeller:update:success",
        "ERROR": "permission:bySeller:update:error"
      },
      "EVENT": "permission:update",
      "SUCCESS": "permission:update:success",
      "ERROR": "permission:update:error"
    },
    "DELETE": {
      "EVENT": "permission:delete",
      "SUCCESS": "permission:delete:success",
      "ERROR": "permission:delete:error"
    },
    "GET_ALL": {
      "EVENT": "permission:getAll",
      "SUCCESS": "permission:getAll:success",
      "ERROR": "permission:getAll:error"
    },
    "GET": {
      "BY_SELLERID": {
        "EVENT": "permission:get:bySellerId",
        "SUCCESS": "permission:get:bySellerId:success",
        "ERROR": "permission:get:bySellerId:error"
      },
      "BY_SELLER": {
        "EVENT": "permission:get:by:seller",
        "SUCCESS": "permission:get:by:seller:success",
        "ERROR": "permission:get:by:seller:error"
      },
      "BY_STORE": {
        "EVENT": "permission:get:byStore",
        "SUCCESS": "permission:get:byStore:success",
        "ERROR": "permission:get:byStore:error"
      },
      "EVENT": "permission:get",
      "SUCCESS": "permission:get:success",
      "ERROR": "permission:get:error"
    }
  },
  "PHONE": {
    "ADD": {
      "EVENT": "phone:add",
      "SUCCESS": "phone:add:success",
      "ERROR": "phone:add:error"
    },
    "UPDATE": {
      "EVENT": "phone:update",
      "SUCCESS": "phone:update:success",
      "ERROR": "phone:update:error"
    },
    "DELETE": {
      "EVENT": "phone:delete",
      "SUCCESS": "phone:delete:success",
      "ERROR": "phone:delete:error"
    },
    "GET_ALL": {
      "EVENT": "phone:getAll",
      "SUCCESS": "phone:getAll:success",
      "ERROR": "phone:getAll:error"
    },
    "GET": {
      "EVENT": "phone:get",
      "SUCCESS": "phone:get:success",
      "ERROR": "phone:get:error"
    }
  },
  "PRODUCT": {
    "ADD": {
      "EVENT": "product:add",
      "SUCCESS": "product:add:success",
      "ERROR": "product:add:error"
    },
    "UPDATE": {
      "EVENT": "product:update",
      "SUCCESS": "product:update:success",
      "ERROR": "product:update:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "product:delete:multiple",
        "SUCCESS": "product:delete:multiple:success",
        "ERROR": "product:delete:multiple:error"
      },
      "EVENT": "product:delete",
      "SUCCESS": "product:delete:success",
      "ERROR": "product:delete:error"
    },
    "GET_ALL": {
      "SOLR": {
        "BY_ID": {
          "EVENT": "solr:products:by:ids",
          "SUCCESS": "solr:products:by:ids:success",
          "ERROR": "solr:products:by:ids:error"
        },
        "EVENT": "solr:product:getAll",
        "SUCCESS": "solr:product:getAll:success",
        "ERROR": "solr:product:getAll:error"
      },
      "BY_STORE": {
        "EVENT": "getAll:product:byStore",
        "SUCCESS": "getAll:product:byStore:success",
        "ERROR": "getAll:product:byStore:error"
      },
      "EVENT": "product:getAll",
      "SUCCESS": "product:getAll:success",
      "ERROR": "product:getAll:error"
    },
    "GET": {
      "EVENT": "product:get",
      "SUCCESS": "product:get:success",
      "ERROR": "product:get:error"
    },
    "PRODUCT_ID": {
      "EVENT": "product:get:by:productId",
      "SUCCESS": "product:get:by:productId:success",
      "ERROR": "product:get:by:productId:error"
    },
    "UPDATE_STATUS": {
      "EVENT": "product:update-status",
      "SUCCESS": "product:update-status:success",
      "ERROR": "product:update-status:error"
    },
    "SEARCH": {
      "BY_ID": {
        "EVENT": "search:product:by:id",
        "SUCCESS": "search:product:by:id:success",
        "ERROR": "search:product:by:id:error"
      },
      "EVENT": "search:products",
      "SUCCESS": "search:products:success",
      "ERROR": "search:products:error"
    },
    "CLONE": {
      "EVENT": "product:clone",
      "SUCCESS": "product:clone:success",
      "ERROR": "product:clone:error"
    }
  },
  "PRODUCT_TYPE": {
    "ADD": {
      "EVENT": "productType:add",
      "SUCCESS": "productType:add:success",
      "ERROR": "productType:add:error"
    },
    "UPDATE": {
      "EVENT": "productType:update",
      "SUCCESS": "productType:update:success",
      "ERROR": "productType:update:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "productType:delete:multiple",
        "SUCCESS": "productType:delete:multiple:success",
        "ERROR": "productType:delete:multiple:error"
      },
      "EVENT": "productType:delete",
      "SUCCESS": "productType:delete:success",
      "ERROR": "productType:delete:error"
    },
    "GET_ALL": {
      "SOLR": {
        "EVENT": "solr:productType:getAll",
        "SUCCESS": "solr:productType:getAll:success",
        "ERROR": "solr:productType:getAll:error"
      },
      "EVENT": "productType:getAll",
      "SUCCESS": "productType:getAll:success",
      "ERROR": "productType:getAll:error"
    },
    "GET": {
      "EVENT": "productType:get",
      "SUCCESS": "productType:get:success",
      "ERROR": "productType:get:error"
    },
    "SEARCH": {
      "BY_ID": {
        "EVENT": "search:product:type:by:id",
        "SUCCESS": "search:product:type:by:id:success",
        "ERROR": "search:product:type:by:id:error"
      }
    }
  },
  "RATING": {
    "ADD": {
      "EVENT": "rating:add",
      "SUCCESS": "rating:add:success",
      "ERROR": "rating:add:error"
    },
    "UPDATE": {
      "EVENT": "rating:update",
      "SUCCESS": "rating:update:success",
      "ERROR": "rating:update:error"
    },
    "DELETE": {
      "EVENT": "rating:delete",
      "SUCCESS": "rating:delete:success",
      "ERROR": "rating:delete:error"
    },
    "GET_ALL": {
      "SOLR": {
        "EVENT": "solr:rating:getAll",
        "SUCCESS": "solr:rating:getAll:success",
        "ERROR": "solr:rating:getAll:error"
      },
      "PRODUCT_REVIEW": {
        "EVENT": "rating:product:getAll",
        "SUCCESS": "rating:product:getAll:success",
        "ERROR": "rating:product:getAll:error"
      },
      "EVENT": "rating:getAll",
      "SUCCESS": "rating:getAll:success",
      "ERROR": "rating:getAll:error"
    },
    "GET": {
      "BY_CUSTOMER": {
        "EVENT": "rating:get:by:customerId",
        "SUCCESS": "rating:get:by:customerId:success",
        "ERROR": "rating:get:by:customerId:error"
      },
      "BY_PRODUCTID": {
        "EVENT": "rating:get:by:productId",
        "SUCCESS": "rating:get:by:productId:success",
        "ERROR": "rating:get:by:productId:error"
      },
      "EVENT": "rating:get",
      "SUCCESS": "rating:get:success",
      "ERROR": "rating:get:error"
    }
  },
  "REFUND": {
    "ADD": {
      "EVENT": "refund:add",
      "SUCCESS": "refund:add:success",
      "ERROR": "refund:add:error"
    },
    "UPDATE": {
      "EVENT": "refund:update",
      "SUCCESS": "refund:update:success",
      "ERROR": "refund:update:error"
    },
    "DELETE": {
      "EVENT": "refund:delete",
      "SUCCESS": "refund:delete:success",
      "ERROR": "refund:delete:error"
    },
    "GET_ALL": {
      "EVENT": "refund:getAll",
      "SUCCESS": "refund:getAll:success",
      "ERROR": "refund:getAll:error"
    },
    "GET": {
      "EVENT": "refund:get",
      "SUCCESS": "refund:get:success",
      "ERROR": "refund:get:error"
    }
  },
  "REGISTRATION": {
    "ADD": {
      "EVENT": "registration:add",
      "SUCCESS": "registration:add:success",
      "ERROR": "registration:add:error"
    },
    "UPDATE": {
      "EVENT": "registration:update",
      "SUCCESS": "registration:update:success",
      "ERROR": "registration:update:error",
      "RESEND": {
        "EVENT": "registration:resend",
        "SUCCESS": "registration:resend:success",
        "ERROR": "registration:resend:error"
      }
    },
    "DELETE": {
      "EVENT": "registration:delete",
      "SUCCESS": "registration:delete:success",
      "ERROR": "registration:delete:error"
    },
    "GET_ALL": {
      "EVENT": "registration:getAll",
      "SUCCESS": "registration:getAll:success",
      "ERROR": "registration:getAll:error"
    },
    "GET": {
      "EVENT": "registration:get",
      "SUCCESS": "registration:get:success",
      "ERROR": "registration:get:error"
    }
  },
  "SELLER_ACTIVITY_LOG": {
    "ADD": {
      "EVENT": "sellerActivityLog:add",
      "SUCCESS": "sellerActivityLog:add:success",
      "ERROR": "sellerActivityLog:add:error"
    },
    "UPDATE": {
      "EVENT": "sellerActivityLog:update",
      "SUCCESS": "sellerActivityLog:update:success",
      "ERROR": "sellerActivityLog:update:error"
    },
    "DELETE": {
      "EVENT": "sellerActivityLog:delete",
      "SUCCESS": "sellerActivityLog:delete:success",
      "ERROR": "sellerActivityLog:delete:error"
    },
    "GET_ALL": {
      "EVENT": "sellerActivityLog:getAll",
      "SUCCESS": "sellerActivityLog:getAll:success",
      "ERROR": "sellerActivityLog:getAll:error"
    },
    "GET": {
      "EVENT": "sellerActivityLog:get",
      "SUCCESS": "sellerActivityLog:get:success",
      "ERROR": "sellerActivityLog:get:error"
    },
    "COUNT": {
      "EVENT": "sellerActivityLog:get:count",
      "SUCCESS": "sellerActivityLog:get:count:success",
      "ERROR": "sellerActivityLog:get:count:error"
    }
  },
  "SELLER": {
    "ADD": {
      "SELLER_ADDRESS": {
        "EVENT": "seller:address:add",
        "SUCCESS": "seller:address:add:success",
        "ERROR": "seller:address:add:error"
      },
      "EVENT": "seller:add",
      "SUCCESS": "seller:add:success",
      "ERROR": "seller:add:error"
    },
    "UPDATE": {
      "EVENT": "seller:update",
      "SUCCESS": "seller:update:success",
      "ERROR": "seller:update:error"
    },
    "UPDATE_SETTINGS": {
      "EVENT": "seller:update-settings",
      "SUCCESS": "seller:update-settings:success",
      "ERROR": "seller:update-settings:error"
    },
    "DELETE": {
      "SELLER_ADDRESS": {
        "EVENT": "seller:address:delete",
        "SUCCESS": "seller:address:delete:success",
        "ERROR": "seller:address:delete:error"
      },
      "EVENT": "seller:delete",
      "SUCCESS": "seller:delete:success",
      "ERROR": "seller:delete:error"
    },
    "GET_ALL": {
      "SOLR": {
        "EVENT": "solr:seller:getAll",
        "SUCCESS": "solr:seller:getAll:success",
        "ERROR": "solr:seller:getAll:error"
      },
      "SELLER_ADDRESS": {
        "EVENT": "seller:address:getAll",
        "SUCCESS": "seller:address:getAll:success",
        "ERROR": "seller:address:getAll:error"
      },
      "EVENT": "seller:getAll",
      "SUCCESS": "seller:getAll:success",
      "ERROR": "seller:getAll:error"
    },
    "GET": {
      "ROLE": {
        "EVENT": "seller:getRole",
        "SUCCESS": "seller:getRole:success",
        "ERROR": "seller:getRole:error"
      },
      "EVENT": "seller:get",
      "SUCCESS": "seller:get:success",
      "ERROR": "seller:get:error"
    },
    "CHECK_AVAILABILITY": {
      "EVENT": "seller:check-availability",
      "SUCCESS": "seller:check-availability:success",
      "ERROR": "seller:check-availability:error"
    },
    "AUTHENTICATE": {
      "EVENT": "seller:authenticate",
      "SUCCESS": "seller:authenticate:success",
      "ERROR": "seller:authenticate:error"
    },
    "STAFF_AUTHENTICATE": {
      "EVENT": "staff:authenticate",
      "SUCCESS": "staff:authenticate:success",
      "ERROR": "staff:authenticate:error"
    },
    "APP_AUTHENTICATE": {
      "EVENT": "seller:app:authenticate",
      "SUCCESS": "seller:app:authenticate:success",
      "ERROR": "seller:app:authenticate:error"
    },
    "PASSWORD_RECOVERY": {
      "EVENT": "seller:password-recovery",
      "SUCCESS": "seller:password-recovery:success",
      "ERROR": "seller:password-recovery:error"
    },
    "PASSWORD_RECOVERY_PHONE": {
      "EVENT": "seller:password-recovery-phone",
      "SUCCESS": "seller:password-recovery-phone:success",
      "ERROR": "seller:password-recovery-phone:error"
    },
    "UNLOCK": {
      "EVENT": "seller:unlock",
      "SUCCESS": "seller:unlock:success",
      "ERROR": "seller:unlock:error"
    },
    "CHANGE_PASSWORD": {
      "EVENT": "seller:change-password",
      "SUCCESS": "seller:change-password:success",
      "ERROR": "seller:change-password:error"
    },
    "ADD_PASSWORD": {
      "EVENT": "seller:add-password",
      "SUCCESS": "seller:add-password:success",
      "ERROR": "seller:add-password:error"
    },
    "CONNECT": {
      "EVENT": "connectme"
    },
    "LOGOUT": {
      "EVENT": "seller:logout",
      "SUCCESS": "seller:logout:success",
      "ERROR": "seller:logout:error"
    },
    "ONLINE_SET": {
      "EVENT": "seller:online:set"
    },
    "ONLINE_GET": {
      "EVENT": "seller:online:get",
      "SUCCESS": "seller:online:get:success"
    },
    "SEO_PHOTOGRAPHER_MANAGERS": {
      "EVENT": "get:all:seoOrPhotographerManagers",
      "SUCCESS": "get:all:seoOrPhotographerManagers:success",
      "ERROR": "get:all:seoOrPhotographerManagers:error"
    },
    "FIND": {
      "EVENT": "seller:find",
      "SUCCESS": "seller:find:success",
      "ERROR": "seller:find:error"
    }
  },
  "SHIPMENT": {
    "ADD": {
      "EVENT": "shipment:add",
      "SUCCESS": "shipment:add:success",
      "ERROR": "shipment:add:error"
    },
    "UPDATE": {
      "EVENT": "shipment:update",
      "SUCCESS": "shipment:update:success",
      "ERROR": "shipment:update:error"
    },
    "DELETE": {
      "EVENT": "shipment:delete",
      "SUCCESS": "shipment:delete:success",
      "ERROR": "shipment:delete:error"
    },
    "GET_ALL": {
      "SOLR": {
        "EVENT": "solr:shipment:getAll",
        "SUCCESS": "solr:shipment:getAll:success",
        "ERROR": "solr:shipment:getAll:error"
      },
      "EVENT": "shipment:getAll",
      "SUCCESS": "shipment:getAll:success",
      "ERROR": "shipment:getAll:error"
    },
    "GET": {
      "BY_TRACKINGID": {
        "EVENT": "shipment:get-by:tracking-id",
        "SUCCESS": "shipment:get-by:tracking-id:success",
        "ERROR": "shipment:get-by:tracking-id:error"
      },
      "EVENT": "shipment:get",
      "SUCCESS": "shipment:get:success",
      "ERROR": "shipment:get:error"
    }
  },
  "SHOPPING_CART": {
    "ADD": {
      "ITEM": {
        "EVENT": "shoppingCart:add:item",
        "SUCCESS": "shoppingCart:add:item:success",
        "ERROR": "shoppingCart:add:item:error"
      },
      "BUNDLE": {
        "EVENT": "shoppingCart:add:bundle",
        "SUCCESS": "shoppingCart:add:bundle:success",
        "ERROR": "shoppingCart:add:bundle:error"
      },
      "EVENT": "shoppingCart:add",
      "SUCCESS": "shoppingCart:add:success",
      "ERROR": "shoppingCart:add:error"
    },
    "UPDATE": {
      "QUANTITY": {
        "EVENT": "shoppingCart:update:item:quantity",
        "SUCCESS": "shoppingCart:update:item:quantity:success",
        "ERROR": "shoppingCart:update:item:quantity:error"
      },
      "BUNDLE": {
        "EVENT": "shoppingCart:update:bundle:quantity",
        "SUCCESS": "shoppingCart:update:bundle:quantity:success",
        "ERROR": "shoppingCart:update:bundle:quantity:error"
      },
      "BY_ID": {
        "EVENT": "shoppingCart:updateById",
        "SUCCESS": "shoppingCart:updateById:success",
        "ERROR": "shoppingCart:updateById:error"
      },
      "EVENT": "shoppingCart:update",
      "SUCCESS": "shoppingCart:update:success",
      "ERROR": "shoppingCart:update:error"
    },
    "DELETE": {
      "ITEM": {
        "EVENT": "shoppingCart:remove:item",
        "SUCCESS": "shoppingCart:remove:item:success",
        "ERROR": "shoppingCart:remove:item:error"
      },
      "GIFT_CARD": {
        "EVENT": "shoppingCart:remove:giftCard",
        "SUCCESS": "shoppingCart:remove:giftCard:success",
        "ERROR": "shoppingCart:remove:giftCard:error"
      },
      "BUNDLE": {
        "EVENT": "shoppingCart:delete:bundle",
        "SUCCESS": "shoppingCart:delete:bundle:success",
        "ERROR": "shoppingCart:delete:bundle:error"
      },
      "EVENT": "shoppingCart:delete",
      "SUCCESS": "shoppingCart:delete:success",
      "ERROR": "shoppingCart:delete:error"
    },
    "GET_ALL": {
      "EVENT": "shoppingCart:getAll",
      "SUCCESS": "shoppingCart:getAll:success",
      "ERROR": "shoppingCart:getAll:error"
    },
    "GET": {
      "ITEM": {
        "EVENT": "shoppingCart:items",
        "SUCCESS": "shoppingCart:items:success",
        "ERROR": "shoppingCart:items:error"
      },
      "BY_CUSTOMER": {
        "EVENT": "shoppingCart:by:customer",
        "SUCCESS": "shoppingCart:by:customer:success",
        "ERROR": "shoppingCart:by:customer:error"
      },
      "EVENT": "shoppingCart:get",
      "SUCCESS": "shoppingCart:get:success",
      "ERROR": "shoppingCart:get:error"
    }
  },
  "SLIDER": {
    "ADD": {
      "EVENT": "slider:add",
      "SUCCESS": "slider:add:success",
      "ERROR": "slider:add:error"
    },
    "UPDATE": {
      "EVENT": "slider:update",
      "SUCCESS": "slider:update:success",
      "ERROR": "slider:update:error"
    },
    "DELETE": {
      "EVENT": "slider:delete",
      "SUCCESS": "slider:delete:success",
      "ERROR": "slider:delete:error"
    },
    "GET_ALL": {
      "EVENT": "slider:getAll",
      "SUCCESS": "slider:getAll:success",
      "ERROR": "slider:getAll:error"
    },
    "GET": {
      "EVENT": "slider:get",
      "SUCCESS": "slider:get:success",
      "ERROR": "slider:get:error"
    }
  },
  "APP_SLIDER": {
    "ADD": {
      "EVENT": "app:slider:add",
      "SUCCESS": "app:slider:add:success",
      "ERROR": "app:slider:add:error"
    },
    "UPDATE": {
      "EVENT": "app:slider:update",
      "SUCCESS": "app:slider:update:success",
      "ERROR": "app:slider:update:error"
    },
    "DELETE": {
      "EVENT": "app:slider:delete",
      "SUCCESS": "app:slider:delete:success",
      "ERROR": "app:slider:delete:error"
    },
    "GET_ALL": {
      "EVENT": "app:slider:getAll",
      "SUCCESS": "app:slider:getAll:success",
      "ERROR": "app:slider:getAll:error"
    },
    "GET": {
      "EVENT": "app:slider:get",
      "SUCCESS": "app:slider:get:success",
      "ERROR": "app:slider:get:error"
    }
  },
  "SOLR_SEARCH": {
    "SEARCH_BY_FIELD": {
      "EVENT": "search:by-field",
      "SUCCESS": "search:by-field:success",
      "ERROR": "search:by-field:error"
    },
    "ITEMS": {
      "EVENT": "search:items",
      "SUCCESS": "search:items:success",
      "ERROR": "search:items:error"
    },
    "FIND_BY_FIELD": {
      "EVENT": "findBy:field",
      "SUCCESS": "findBy:field:success",
      "ERROR": "findBy:field:error"
    },
    "FILTERS": {
      "EVENT": "search:filters",
      "SUCCESS": "search:filters:success",
      "ERROR": "search:filters:error"
    },
    "BY_FILTER": {
      "EVENT": "search:by:filters",
      "SUCCESS": "search:by:filters:success",
      "ERROR": "search:by:filters:error"
    },
    "GLOBAL": {
      "EVENT": "search:global",
      "SUCCESS": "search:global:success",
      "ERROR": "search:global:error"
    }
  },
  "STORE_SLIDER": {
    "ADD": {
      "EVENT": "store-slider:add",
      "SUCCESS": "store-slider:add:success",
      "ERROR": "store-slider:add:error"
    },
    "UPDATE": {
      "EVENT": "store-slider:update",
      "SUCCESS": "store-slider:update:success",
      "ERROR": "store-slider:update:error"
    },
    "DELETE": {
      "EVENT": "store-slider:delete",
      "SUCCESS": "store-slider:delete:success",
      "ERROR": "store-slider:delete:error"
    },
    "GET_ALL": {
      "EVENT": "store-slider:getAll",
      "SUCCESS": "store-slider:getAll:success",
      "ERROR": "store-slider:getAll:error"
    },
    "GET": {
      "EVENT": "store-slider:get",
      "SUCCESS": "store-slider:get:success",
      "ERROR": "store-slider:get:error"
    }
  },
  "STORE": {
    "ADD": {
      "MEMBER": {
        "EVENT": "store:newMember:add",
        "SUCCESS": "store:newMember:add:success",
        "ERROR": "store:newMember:add:error"
      },
      "EVENT": "store:add",
      "SUCCESS": "store:add:success",
      "ERROR": "store:add:error"
    },
    "UPDATE": {
      "STORE": {
        "EVENT": "update:store",
        "SUCCESS": "update:store:output",
        "ERROR": "update:store:error"
      },
      "THEME": {
        "EVENT": "store:theme",
        "SUCCESS": "store:theme:success",
        "ERROR": "store:theme:error"
      },
      "SPECIFIC_UPDATE": {
        "EVENT": "store:specific-update",
        "SUCCESS": "store:specific-update:success",
        "ERROR": "store:specific-update:error"
      },
      "SMS_ID": {
        "EVENT": "store:sms-update",
        "SUCCESS": "store:sms-update:success",
        "ERROR": "store:sms-update:error"
      },
      "LOGISTIC": {
        "STATE": {
          "EVENT": "store:logistics:state:update",
          "SUCCESS": "store:logistics:state:update:success",
          "ERROR": "store:logistics:state:update:error"
        },
        "EVENT": "store:logistics:update",
        "SUCCESS": "store:logistics:update:success",
        "ERROR": "store:logistics:update:error"
      },
      "COLLECTION_SETTINGS": {
        "EVENT": "store:collection-settings:update",
        "SUCCESS": "store:collection-settings:update:success",
        "ERROR": "store:collection-settings:update:error"
      },
      "EVENT": "store:update",
      "SUCCESS": "store:update:success",
      "ERROR": "store:update:error"
    },
    "DELETE": {
      "MEMBER": {
        "EVENT": "store:member:delete",
        "SUCCESS": "store:member:delete:success",
        "ERROR": "store:member:delete:error"
      },
      "EVENT": "store:delete",
      "SUCCESS": "store:delete:success",
      "ERROR": "store:delete:error"
    },
    "GET_ALL": {
      "SELLER": {
        "EVENT": "store:seller:getAll",
        "SUCCESS": "store:seller:getAll:success",
        "ERROR": "store:seller:getAll:error"
      },
      "EVENT": "store:getAll",
      "SUCCESS": "store:getAll:success",
      "ERROR": "store:getAll:error"
    },
    "GET": {
      "BY_DOMAIN": {
        "EVENT": "store:get:by-domain",
        "SUCCESS": "store:get:by-domain:success",
        "ERROR": "store:get:by-domain:error"
      },
      "PACKAGE": {
        "EVENT": "store:get:package",
        "SUCCESS": "store:get:package:success"
      },
      "MEMBER": {
        "EVENT": "store:member:get",
        "SUCCESS": "store:member:get:success",
        "ERROR": "store:member:get:error"
      },
      "ADMIN_PACKAGE": {
        "EVENT": "store:get:admin:package",
        "SUCCESS": "store:get:admin:package:success"
      },
      "EVENT": "store:get",
      "SUCCESS": "store:get:success",
      "ERROR": "store:get:error"
    },
    "MANAGE": {
      "GET": {
        "EVENT": "store:manage:get",
        "SUCCESS": "store:manage:get:success",
        "ERROR": "store:manage:get:error"
      }
    },
    "CHECK": {
      "EVENT": "store:check:existence",
      "SUCCESS": "store:check:existence:success",
      "ERROR": "store:check:existence:error",
      "DOMAIN": {
        "EVENT": "storeDomain:check-availability",
        "SUCCESS": "storeDomain:check-availability:success",
        "ERROR": "storeDomain:check-availability:error"
      }
    },
    "THEME": {
      "EVENT": "store:base:theme:update",
      "SUCCESS": "store:base:theme:update:success",
      "ERROR": "store:base:theme:update:error"
    },
    "USER": {
      "EVENT": "input:getAll:storeUser",
      "SUCCESS": "input:getAll:storeUser:success",
      "ERROR": "input:getAll:storeUser:error"
    },
    "SEO_MANAGER": {
      "FIND_BY_FIELD": {
        "EVENT": "seo_manager:find:by:field",
        "SUCCESS": "seo_manager:find:by:field:success",
        "ERROR": "seo_manager:find:by:field:error"
      },
      "EVENT": "assigned:unassigned:seo:managers",
      "SUCCESS": "assigned:unassigned:seo:managers:success",
      "ERROR": "assigned:unassigned:seo:managers:error"
    },
    "PHOTOGRAPHER_MANAGER": {
      "FIND_BY_FIELD": {
        "EVENT": "photographer_manager:find:by:field",
        "SUCCESS": "photographer_manager:find:by:field:success",
        "ERROR": "photographer_manager:find:by:field:error"
      },
      "EVENT": "assigned:unassigned:photographers",
      "SUCCESS": "assigned:unassigned:photographers:success",
      "ERROR": "assigned:unassigned:photographers:error"
    },
    "GET_INSTAGRAM": {
      "EVENT": "get:instagram",
      "SUCCESS": "get:instagram:success",
      "ERROR": "get:instagram:error"
    }
  },
  "SUPPORT": {
    "ADD": {
      "MESSAGE": {
        "EVENT": "support:message:add",
        "SUCCESS": "support:message:add:success",
        "ERROR": "support:message:add:error"
      },
      "EVENT": "support:add",
      "SUCCESS": "support:add:success",
      "ERROR": "support:add:error"
    },
    "UPDATE": {
      "EVENT": "support:update",
      "SUCCESS": "support:update:success",
      "ERROR": "support:update:error"
    },
    "DELETE": {
      "MESSAGE": {
        "EVENT": "support:message:delete",
        "SUCCESS": "support:message:delete:success",
        "ERROR": "support:message:delete:error"
      },
      "EVENT": "support:delete",
      "SUCCESS": "support:delete:success",
      "ERROR": "support:delete:error"
    },
    "GET_ALL": {
      "MESSAGE": {
        "EVENT": "support:message:getAll",
        "SUCCESS": "support:message:getAll:success",
        "ERROR": "support:message:getAll:error"
      },
      "EVENT": "support:getAll",
      "SUCCESS": "support:getAll:success",
      "ERROR": "support:getAll:error"
    },
    "GET": {
      "EVENT": "support:get",
      "SUCCESS": "support:get:success",
      "ERROR": "support:get:error"
    },
    "SUB_CATEGORY": {
      "ADD": {
        "EVENT": "support:subcategory:add",
        "SUCCESS": "support:subcategory:add:success",
        "ERROR": "support:subcategory:add:error"
      },
      "DELETE": {
        "EVENT": "support:subcategory:delete",
        "SUCCESS": "support:subcategory:delete:success",
        "ERROR": "support:subcategory:delete:error"
      },
      "GET_ALL": {
        "EVENT": "support:subcategory:getAll",
        "SUCCESS": "support:subcategory:getAll:success",
        "ERROR": "support:subcategory:getAll:error"
      }
    },
    "BY_CATEGORYID": {
      "EVENT": "support:category:getBy:categoryId",
      "SUCCESS": "support:category:getBy:categoryId:success",
      "ERROR": "support:category:getBy:categoryId:error"
    },
    "BY_CATEGORY_FIELD": {
      "EVENT": "support:category:find:by:field",
      "SUCCESS": "support:category:find:by:field:success",
      "ERROR": "support:category:find:by:field:error"
    },
    "SEARCH": {
      "BY_ID": {
        "EVENT": "search:support:category:by:id",
        "SUCCESS": "search:support:category:by:id:success",
        "ERROR": "search:support:category:by:id:error"
      },
      "EVENT": "search:support:categories",
      "SUCCESS": "search:support:categories:success",
      "ERROR": "search:support:categories:error"
    }
  },
  "TESTIMONIAL": {
    "ADD": {
      "EVENT": "testimonial:add",
      "SUCCESS": "testimonial:add:success",
      "ERROR": "testimonial:add:error"
    },
    "UPDATE": {
      "EVENT": "testimonial:update",
      "SUCCESS": "testimonial:update:success",
      "ERROR": "testimonial:update:error"
    },
    "DELETE": {
      "EVENT": "testimonial:delete",
      "SUCCESS": "testimonial:delete:success",
      "ERROR": "testimonial:delete:error"
    },
    "GET_ALL": {
      "EVENT": "testimonial:getAll",
      "SUCCESS": "testimonial:getAll:success",
      "ERROR": "testimonial:getAll:error"
    },
    "GET": {
      "EVENT": "testimonial:get",
      "SUCCESS": "testimonial:get:success",
      "ERROR": "testimonial:get:error"
    }
  },
  "THEME": {
    "ADD": {
      "RESTRICTION": {
        "EVENT": "theme:addThemeRestriction",
        "SUCCESS": "theme:addThemeRestriction:success",
        "ERROR": "theme:addThemeRestriction:error"
      },
      "EVENT": "theme:add",
      "SUCCESS": "theme:add:success",
      "ERROR": "theme:add:error"
    },
    "UPDATE": {
      "EVENT": "theme:update",
      "SUCCESS": "theme:update:success",
      "ERROR": "theme:update:error"
    },
    "DELETE": {
      "EVENT": "theme:delete",
      "SUCCESS": "theme:delete:success",
      "ERROR": "theme:delete:error"
    },
    "GET_ALL": {
      "PURCHASED_THEME": {
        "EVENT": "getAll:purchasedTheme",
        "SUCCESS": "getAll:purchasedTheme:success",
        "ERROR": "getAll:purchasedTheme:error"
      },
      "SOLR": {
        "EVENT": "solr:theme:getAll",
        "SUCCESS": "solr:theme:getAll:success",
        "ERROR": "solr:theme:getAll:error",
        "MANAGE": {
          "EVENT": "solr:manage:theme:getAll",
          "SUCCESS": "solr:manage:theme:getAll:success",
          "ERROR": "solr:manage:theme:getAll:error"
        }
      },
      "EVENT": "theme:getAll",
      "SUCCESS": "theme:getAll:success",
      "ERROR": "theme:getAll:error"
    },
    "GET": {
      "EVENT": "theme:get",
      "SUCCESS": "theme:get:success",
      "ERROR": "theme:get:error"
    },
    "PURCHASE": {
      "EVENT": "theme:purchase",
      "SUCCESS": "theme:purchase:success",
      "ERROR": "theme:purchase:error"
    }
  },
  "TODOLIST": {
    "ADD": {
      "EVENT": "toDoList:add",
      "SUCCESS": "toDoList:add:success",
      "ERROR": "toDoList:add:error"
    },
    "UPDATE": {
      "EVENT": "toDoList:update",
      "SUCCESS": "toDoList:update:success",
      "ERROR": "toDoList:update:error"
    },
    "DELETE": {
      "EVENT": "toDoList:delete",
      "SUCCESS": "toDoList:delete:success",
      "ERROR": "toDoList:delete:error"
    },
    "GET_ALL": {
      "EVENT": "toDoList:getAll",
      "SUCCESS": "toDoList:getAll:success",
      "ERROR": "toDoList:getAll:error"
    },
    "GET": {
      "EVENT": "toDoList:get",
      "SUCCESS": "toDoList:get:success",
      "ERROR": "toDoList:get:error"
    }
  },
  "TODO": {
    "ADD": {
      "EVENT": "todo:add",
      "SUCCESS": "todo:add:success",
      "ERROR": "todo:add:error"
    },
    "UPDATE": {
      "EVENT": "todo:update",
      "SUCCESS": "todo:update:success",
      "ERROR": "todo:update:error"
    },
    "DELETE": {
      "EVENT": "todo:delete",
      "SUCCESS": "todo:delete:success",
      "ERROR": "todo:delete:error"
    },
    "GET_ALL": {
      "EVENT": "todo:getAll",
      "SUCCESS": "todo:getAll:success",
      "ERROR": "todo:getAll:error"
    }
  },
  "TRANSACTION": {
    "ADD": {
      "EVENT": "transaction:add",
      "SUCCESS": "transaction:add:success",
      "ERROR": "transaction:add:error"
    },
    "UPDATE": {
      "EVENT": "transaction:update",
      "SUCCESS": "transaction:update:success",
      "ERROR": "transaction:update:error"
    },
    "DELETE": {
      "EVENT": "transaction:delete",
      "SUCCESS": "transaction:delete:success",
      "ERROR": "transaction:delete:error"
    },
    "GET_ALL": {
      "EVENT": "transaction:getAll",
      "SUCCESS": "transaction:getAll:success",
      "ERROR": "transaction:getAll:error"
    },
    "GET": {
      "EVENT": "transaction:get",
      "SUCCESS": "transaction:get:success",
      "ERROR": "transaction:get:error"
    }
  },
  "UNIT_SYSTEM": {
    "ADD": {
      "EVENT": "unitSystem:add",
      "SUCCESS": "unitSystem:add:success",
      "ERROR": "unitSystem:add:error"
    },
    "UPDATE": {
      "EVENT": "unitSystem:update",
      "SUCCESS": "unitSystem:update:success",
      "ERROR": "unitSystem:update:error"
    },
    "DELETE": {
      "EVENT": "unitSystem:delete",
      "SUCCESS": "unitSystem:delete:success",
      "ERROR": "unitSystem:delete:error"
    },
    "GET_ALL": {
      "EVENT": "unitSystem:getAll",
      "SUCCESS": "unitSystem:getAll:success",
      "ERROR": "unitSystem:getAll:error"
    },
    "GET": {
      "EVENT": "unitSystem:get",
      "SUCCESS": "unitSystem:get:success",
      "ERROR": "unitSystem:get:error"
    }
  },
  "VISITOR": {
    "ADD": {
      "EVENT": "visitor:add",
      "SUCCESS": "visitor:add:success",
      "ERROR": "visitor:add:error"
    },
    "UPDATE": {
      "EVENT": "visitor:update",
      "SUCCESS": "visitor:update:success",
      "ERROR": "visitor:update:error"
    },
    "DELETE": {
      "EVENT": "visitor:delete",
      "SUCCESS": "visitor:delete:success",
      "ERROR": "visitor:delete:error"
    },
    "GET_ALL": {
      "EVENT": "visitor:getAll",
      "SUCCESS": "visitor:getAll:success",
      "ERROR": "visitor:getAll:error"
    },
    "GET": {
      "MONTHLY": {
        "EVENT": "visitor:monthly:get",
        "SUCCESS": "visitor:monthly:get:success",
        "ERROR": "visitor:monthly:get:error"
      },
      "EVENT": "visitor:get",
      "SUCCESS": "visitor:get:success",
      "ERROR": "visitor:get:error"
    }
  },
  "WEB_CONTENT": {
    "ADD": {
      "EVENT": "webContent:add",
      "SUCCESS": "webContent:add:success",
      "ERROR": "webContent:add:error"
    },
    "UPDATE": {
      "EVENT": "webContent:update",
      "SUCCESS": "webContent:update:success",
      "ERROR": "webContent:update:error"
    },
    "DELETE": {
      "EVENT": "webContent:delete",
      "SUCCESS": "webContent:delete:success",
      "ERROR": "webContent:delete:error"
    },
    "GET_BY_STORE": {
      "EVENT": "webContentByStore:get",
      "SUCCESS": "webContentByStore:get:success",
      "ERROR": "webContentByStore:get:error"
    },
    "BANNERS": {
      "EVENT": "banners:get:by:store",
      "SUCCESS": "banners:get:by:store:success",
      "ERROR": "banners:get:by:store:error"
    },
    "GET_ALL": {
      "TYPE": {
        "EVENT": "customContentType:getAll",
        "SUCCESS": "customContentType:getAll:success",
        "ERROR": "customContentType:getAll:error"
      },
      "STORE": {
        "EVENT": "webContentStore:getAll",
        "SUCCESS": "webContentStore:getAll:success",
        "ERROR": "webContentStore:getAll:error"
      },
      "AUTHOR": {
        "EVENT": "webContentAuthor:getAll",
        "SUCCESS": "webContentAuthor:getAll:success",
        "ERROR": "webContentAuthor:getAll:error"
      },
      "EVENT": "webContent:getAll",
      "SUCCESS": "webContent:getAll:success",
      "ERROR": "webContent:getAll:error"
    },
    "GET": {
      "BY_TYPE": {
        "EVENT": "web-content:get-by:type",
        "SUCCESS": "web-content:get-by:type:success",
        "ERROR": "web-content:get-by:type:error"
      },
      "EVENT": "webContent:get",
      "SUCCESS": "webContent:get:success",
      "ERROR": "webContent:get:error"
    }
  },
  "WISHLIST": {
    "ADD": {
      "ITEM": {
        "EVENT": "wishlist:add:item",
        "SUCCESS": "wishlist:add:item:success",
        "ERROR": "wishlist:add:item:error"
      },
      "EVENT": "wishlist:add",
      "SUCCESS": "wishlist:add:success",
      "ERROR": "wishlist:add:error"
    },
    "UPDATE": {
      "EVENT": "wishlist:update",
      "SUCCESS": "wishlist:update:success",
      "ERROR": "wishlist:update:error"
    },
    "DELETE": {
      "ITEM": {
        "EVENT": "wishlist:remove:item",
        "SUCCESS": "wishlist:remove:item:success",
        "ERROR": "wishlist:remove:item:error"
      },
      "EVENT": "wishlist:delete",
      "SUCCESS": "wishlist:delete:success",
      "ERROR": "wishlist:delete:error"
    },
    "GET_ALL": {
      "EVENT": "wishlist:getAll",
      "SUCCESS": "wishlist:getAll:success",
      "ERROR": "wishlist:getAll:error"
    },
    "GET": {
      "BY_CUSTOMER": {
        "EVENT": "wishlist:by:customer",
        "SUCCESS": "wishlist:by:customer:success",
        "ERROR": "wishlist:by:customer:error"
      },
      "EVENT": "wishlist:get",
      "SUCCESS": "wishlist:get:success",
      "ERROR": "wishlist:get:error"
    }
  },
  "RESELLER": {
    "AUTHENTICATE": {
      "EVENT": "reseller:authenticate",
      "SUCCESS": "reseller:authenticate:success",
      "ERROR": "reseller:authenticate:error"
    },
    "ADD": {
      "EVENT": "reseller:add",
      "SUCCESS": "reseller:add:success",
      "ERROR": "reseller:add:error",
      "PASSWORD": {
        "EVENT": "reseller:add-password",
        "SUCCESS": "reseller:add-password:success",
        "ERROR": "reseller:add-password:error"
      }
    },
    "UPDATE": {
      "EVENT": "reseller:update",
      "SUCCESS": "reseller:update:success",
      "ERROR": "reseller:update:error"
    },
    "GET_ALL": {
      "EVENT": "reseller:getAll",
      "SUCCESS": "reseller:getAll:success",
      "ERROR": "reseller:getAll:error"
    },
    "GET": {
      "EVENT": "reseller:get",
      "SUCCESS": "reseller:get:success",
      "ERROR": "reseller:get:error",
      "BY_INVITATIONID": {
        "EVENT": "reseller:get:byInvitationId",
        "SUCCESS": "reseller:get:byInvitationId:success",
        "ERROR": "reseller:get:byInvitationId:error"
      }
    },
    "DELETE": {
      "EVENT": "reseller:delete",
      "SUCCESS": "reseller:delete:success",
      "ERROR": "reseller:delete:error"
    },
    "PASSWORD_RECOVERY": {
      "EVENT": "reseller:password-recovery",
      "SUCCESS": "reseller:password-recovery:success",
      "ERROR": "reseller:password-recovery:error"
    },
    "CHANGE_PASSWORD": {
      "EVENT": "reseller:password-change",
      "SUCCESS": "reseller:password-change:success",
      "ERROR": "reseller:password-change:error"
    },
    "UPDATE_PASSWORD": {
      "EVENT": "reseller:password-update",
      "SUCCESS": "reseller:password-update:success",
      "ERROR": "reseller:password-update:error"
    },
    "UNLOCK": {
      "EVENT": "reseller:unlock",
      "SUCCESS": "reseller:unlock:success",
      "ERROR": "reseller:unlock:error"
    },
    "UPDATE_PACKAGE": {
      "EVENT": "reseller:packages:update",
      "SUCCESS": "reseller:packages:update:success",
      "ERROR": "reseller:packages:update:error"
    },
    "LOGOUT": {
      "EVENT": "reseller:logout",
      "SUCCESS": "reseller:logout:success",
      "ERROR": "reseller:logout:error"
    },
    "PASSWORD_RECOVERY_PHONE": {
      "EVENT": "reseller:password-recovery-phone",
      "SUCCESS": "reseller:password-recovery-phone:success",
      "ERROR": "reseller:password-recovery-phone:error"
    }
  },
  "DOMAIN": {
    "LOOKUP": {
      "EVENT": "domain:lookup",
      "SUCCESS": "domain:lookup:success",
      "ERROR": "domain:lookup:error"
    },
    "SUGGEST": {
      "EVENT": "domain:suggest",
      "SUCCESS": "domain:suggest:success",
      "ERROR": "domain:suggest:error"
    },
    "REGISTER": {
      "EVENT": "domain:register",
      "SUCCESS": "domain:register:success",
      "ERROR": "domain:register:error"
    },
    "PURCHASE": {
      "EVENT": "domain:purchase",
      "SUCCESS": "domain:purchase:success",
      "ERROR": "domain:purchase:error"
    },
    "GET": {
      "EVENT": "domain:get",
      "SUCCESS": "domain:get:success",
      "ERROR": "domain:get:error"
    },
    "REMOVE": {
      "EVENT": "domain:remove",
      "SUCCESS": "domain:remove:success",
      "ERROR": "domain:remove:error"
    },
    "ADD": {
      "EVENT": "domain:add",
      "SUCCESS": "domain:add:success",
      "ERROR": "domain:add:error"
    },
    "GET_PRICES": {
      "EVENT": "domain:getPrices",
      "SUCCESS": "domain:getPrices:success",
      "ERROR": "domain:getPrices:error"
    },
    "GET_TLDs": {
      "EVENT": "domain:getTLDs",
      "SUCCESS": "domain:getTLDs:success",
      "ERROR": "domain:getTLDs:error"
    }
  },
  "ARTICLE": {
    "ADD": {
      "EVENT": "article:add",
      "SUCCESS": "article:add:success",
      "ERROR": "article:add:error"
    },
    "UPDATE": {
      "EVENT": "article:update",
      "SUCCESS": "article:update:success",
      "ERROR": "article:update:error"
    },
    "GET_ALL": {
      "EVENT": "article:getAll",
      "SUCCESS": "article:getAll:success",
      "ERROR": "article:getAll:error"
    },
    "GET": {
      "EVENT": "article:get",
      "SUCCESS": "article:get:success",
      "ERROR": "article:get:error"
    },
    "GET_BY_SLUG": {
      "EVENT": "article:get:by:slug",
      "SUCCESS": "article:get:by:slug:success",
      "ERROR": "article:get:by:slug:error"
    },
    "DELETE": {
      "EVENT": "article:delete",
      "SUCCESS": "article:delete:success",
      "ERROR": "article:delete:error"
    },
    "POLICY_GET_ALL": {
      "EVENT": "policy:getAll",
      "SUCCESS": "policy:getAll:success",
      "ERROR": "policy:getAll:error"
    },
    "POLICY_ADD": {
      "EVENT": "policy:add",
      "SUCCESS": "policy:add:success",
      "ERROR": "policy:add:error"
    },
    "POLICY_UPDATE": {
      "EVENT": "policy:update",
      "SUCCESS": "policy:update:success",
      "ERROR": "policy:update:error"
    },
    "SOLR": {
      "SEARCH": {
        "EVENT": "solr:article:search",
        "SUCCESS": "solr:article:search:success",
        "ERROR": "solr:article:search:error"
      },
      "GET_ALL": {
        "EVENT": "solr:article:getAll",
        "SUCCESS": "solr:article:getAll:success",
        "ERROR": "solr:article:getAll:error"
      }
    }
  },
  "FOLDER": {
    "SOLR": {
      "GET_ALL": {
        "EVENT": "solr:folder:getAll",
        "SUCCESS": "solr:folder:getAll:success",
        "ERROR": "solr:folder:getAll:error"
      }
    },
    "ADD": {
      "EVENT": "folder:add",
      "SUCCESS": "folder:add:success",
      "ERROR": "folder:add:error"
    },
    "RENAME": {
      "EVENT": "folder:rename",
      "SUCCESS": "folder:rename:success",
      "ERROR": "folder:rename:error"
    },
    "UPDATE": {
      "EVENT": "folder:update",
      "SUCCESS": "folder:update:success",
      "ERROR": "folder:update:error"
    },
    "GET_ALL": {
      "EVENT": "folder:getAll",
      "SUCCESS": "folder:getAll:success",
      "ERROR": "folder:getAll:error"
    },
    "GET": {
      "EVENT": "folder:get",
      "SUCCESS": "folder:get:success",
      "ERROR": "folder:get:error"
    },
    "GET_ITEMS": {
      "EVENT": "folder:get:items",
      "SUCCESS": "folder:get:items:success",
      "ERROR": "folder:get:items:error"
    },
    "DELETE": {
      "EVENT": "folder:delete",
      "SUCCESS": "folder:delete:success",
      "ERROR": "folder:delete:error"
    },
    "GET_ALL_FOLDERS": {
      "EVENT": "folder:getAllFolders",
      "SUCCESS": "folder:getAllFolders:success",
      "ERROR": "folder:getAllFolders:error"
    }
  },
  "JOBS": {
    "ADD": {
      "EVENT": "jobs:add",
      "SUCCESS": "jobs:add:success",
      "ERROR": "jobs:add:error"
    },
    "UPDATE": {
      "EVENT": "jobs:update",
      "SUCCESS": "jobs:update:success",
      "ERROR": "jobs:update:error"
    },
    "GET_ALL": {
      "EVENT": "jobs:getAll",
      "SUCCESS": "jobs:getAll:success",
      "ERROR": "jobs:getAll:error"
    },
    "GET": {
      "EVENT": "jobs:get",
      "SUCCESS": "jobs:get:success",
      "ERROR": "jobs:get:error"
    },
    "DELETE": {
      "EVENT": "jobs:delete",
      "SUCCESS": "jobs:delete:success",
      "ERROR": "jobs:delete:error"
    },
    "APPLY_NOW": {
      "EVENT": "jobs:applyNow",
      "SUCCESS": "jobs:applyNow:success",
      "ERROR": "jobs:applyNow:error"
    }
  },
  "PAYMENT_LINKS": {
    "ADD": {
      "ORDER": {
        "EVENT": "payment:links:add:from:order",
        "SUCCESS": "payment:links:add:from:order:success",
        "ERROR": "payment:links:add:from:order:error"
      },
      "EVENT": "payment:links:add",
      "SUCCESS": "payment:links:add:success",
      "ERROR": "payment:links:add:error"
    },
    "RESEND": {
      "EVENT": "payment:links:resend",
      "SUCCESS": "payment:links:resend:success",
      "ERROR": "payment:links:resend:error"
    },
    "UPDATE": {
      "EVENT": "payment:links:update",
      "SUCCESS": "payment:links:update:success",
      "ERROR": "payment:links:update:error"
    },
    "GET_ALL": {
      "EVENT": "payment:links:getAll",
      "SUCCESS": "payment:links:getAll:success",
      "ERROR": "payment:links:getAll:error",
      "PAID": {
        "EVENT": "payment:links:getAll:paid",
        "SUCCESS": "payment:links:getAll:paid:success",
        "ERROR": "payment:links:getAll:paid:error"
      }
    },
    "GET": {
      "EVENT": "payment:links:get",
      "SUCCESS": "payment:links:get:success",
      "ERROR": "payment:links:get:error"
    },
    "DELETE": {
      "EVENT": "payment:links:delete",
      "SUCCESS": "payment:links:delete:success",
      "ERROR": "payment:links:delete:error"
    }
  },
  "EMAILS": {
    "ADD": {
      "EVENT": "emails:add",
      "SUCCESS": "emails:add:success",
      "ERROR": "emails:add:error"
    },
    "UPDATE": {
      "EVENT": "emails:update",
      "SUCCESS": "emails:update:success",
      "ERROR": "emails:update:error"
    },
    "GET_ALL": {
      "EVENT": "emails:getAll",
      "SUCCESS": "emails:getAll:success",
      "ERROR": "emails:getAll:error"
    },
    "GET": {
      "EVENT": "emails:get",
      "SUCCESS": "emails:get:success",
      "ERROR": "emails:get:error"
    },
    "DELETE": {
      "EVENT": "emails:delete",
      "SUCCESS": "emails:delete:success",
      "ERROR": "emails:delete:error"
    }
  },
  "PAGES": {
    "ADD": {
      "EVENT": "pages:add",
      "SUCCESS": "pages:add:success",
      "ERROR": "pages:add:error"
    },
    "UPDATE": {
      "EVENT": "pages:update",
      "SUCCESS": "pages:update:success",
      "ERROR": "pages:update:error"
    },
    "GET_ALL": {
      "EVENT": "pages:getAll",
      "SUCCESS": "pages:getAll:success",
      "ERROR": "pages:getAll:error"
    },
    "GET": {
      "EVENT": "pages:get",
      "SUCCESS": "pages:get:success",
      "ERROR": "pages:get:error"
    },
    "DELETE": {
      "EVENT": "pages:delete",
      "SUCCESS": "pages:delete:success",
      "ERROR": "pages:delete:error"
    }
  },
  "FEATURES": {
    "SOLR": {
      "GET_ALL": {
        "EVENT": "solr:feature:getAll",
        "SUCCESS": "solr:feature:getAll:success",
        "ERROR": "solr:feature:getAll:error"
      }
    },
    "ADD": {
      "EVENT": "feature:add",
      "SUCCESS": "feature:add:success",
      "ERROR": "feature:add:error"
    },
    "UPDATE": {
      "EVENT": "feature:update",
      "SUCCESS": "feature:update:success",
      "ERROR": "feature:update:error"
    },
    "GET_ALL": {
      "EVENT": "feature:getAll",
      "SUCCESS": "feature:getAll:success",
      "ERROR": "feature:getAll:error"
    },
    "GET_FEATURED": {
      "EVENT": "feature:get:featured",
      "SUCCESS": "feature:get:featured:success",
      "ERROR": "feature:get:featured:error"
    },
    "GET": {
      "EVENT": "feature:get",
      "SUCCESS": "feature:get:success",
      "ERROR": "feature:get:error"
    },
    "DELETE": {
      "EVENT": "feature:delete",
      "SUCCESS": "feature:delete:success",
      "ERROR": "feature:delete:error"
    }
  },
  "SMS": {
    "ADD": {
      "EVENT": "sms:add",
      "SUCCESS": "sms:add:success",
      "ERROR": "sms:add:error"
    },
    "GET_ALL": {
      "EVENT": "sms:getAll",
      "SUCCESS": "sms:getAll:success",
      "ERROR": "sms:getAll:error"
    },
    "PURCHASE": {
      "EVENT": "sms:purchase",
      "SUCCESS": "sms:purchase:success",
      "ERROR": "sms:purchase:error"
    },
    "GET": {
      "EVENT": "sms:get",
      "SUCCESS": "sms:get:success",
      "ERROR": "sms:get:error"
    },
    "DELETE": {
      "EVENT": "sms:delete",
      "SUCCESS": "sms:delete:success",
      "ERROR": "sms:delete:error"
    }
  },
  "STORE_HISTORY": {
    "ADD": {
      "EVENT": "store:history:add",
      "SUCCESS": "store:history:add:success",
      "ERROR": "store:history:add:error"
    },
    "GET_ALL": {
      "EVENT": "store:history:getAll",
      "SUCCESS": "store:history:getAll:success",
      "ERROR": "store:history:getAll:error"
    },
    "GET": {
      "EVENT": "store:history:get",
      "SUCCESS": "store:history:get:success",
      "ERROR": "store:history:get:error"
    },
    "UPDATE": {
      "EVENT": "store:history:update",
      "SUCCESS": "store:history:update:success",
      "ERROR": "store:history:update:error"
    },
    "DELETE": {
      "EVENT": "store:history:delete",
      "SUCCESS": "store:history:delete:success",
      "ERROR": "store:history:delete:error"
    }
  },
  "COUPON": {
    "GET_BY_RESELLER": {
      "EVENT": "get:coupons:by:reseller",
      "SUCCESS": "get:coupons:by:reseller:success",
      "ERROR": "get:coupons:by:reseller:error"
    },
    "ADD": {
      "EVENT": "coupon:add",
      "SUCCESS": "coupon:add:success",
      "ERROR": "coupon:add:error"
    },
    "UPDATE": {
      "EVENT": "coupon:update",
      "SUCCESS": "coupon:update:success",
      "ERROR": "coupon:update:error"
    },
    "DELETE": {
      "EVENT": "coupon:delete",
      "SUCCESS": "coupon:delete:success",
      "ERROR": "coupon:delete:error"
    },
    "GET_ALL": {
      "EVENT": "coupon:getAll",
      "SUCCESS": "coupon:getAll:success",
      "ERROR": "coupon:getAll:error"
    },
    "GET": {
      "EVENT": "coupon:get",
      "SUCCESS": "coupon:get:success",
      "ERROR": "coupon:get:error"
    },
    "GET_BY_PACKAGE": {
      "EVENT": "coupon:get:by-package",
      "SUCCESS": "coupon:get:by-package:success",
      "ERROR": "coupon:get:by-package:error"
    },
    "GET_BY_SELLER": {
      "EVENT": "coupon:get:by-seller",
      "SUCCESS": "coupon:get:by-seller:success",
      "ERROR": "coupon:get:by-seller:error"
    },
    "GENERATE_CODE": {
      "EVENT": "coupon:generate-code",
      "SUCCESS": "coupon:generate-code:success",
      "ERROR": "coupon:generate-code:error"
    }
  },
  "STORE_THEME": {
    "UPDATE_PAGES": {
      "EVENT": "store:theme:update:pages",
      "SUCCESS": "store:theme:update:pages:success",
      "ERROR": "store:theme:update:pages:error"
    },
    "ADD": {
      "EVENT": "store:theme:add",
      "SUCCESS": "store:theme:add:success",
      "ERROR": "store:theme:add:error"
    },
    "UPDATE": {
      "EVENT": "store:theme:update",
      "SUCCESS": "store:theme:update:success",
      "ERROR": "store:theme:update:error"
    },
    "GET_ALL": {
      "EVENT": "store:theme:getAll",
      "SUCCESS": "store:theme:getAll:success",
      "ERROR": "store:theme:getAll:error"
    },
    "GET": {
      "EVENT": "store:theme:get",
      "SUCCESS": "store:theme:get:success",
      "ERROR": "store:theme:get:error"
    },
    "DELETE": {
      "EVENT": "store:theme:delete",
      "SUCCESS": "store:theme:delete:success",
      "ERROR": "store:theme:delete:error"
    }
  },
  "FEED": {
    "ADD": {
      "EVENT": "feed:add",
      "SUCCESS": "feed:add:success",
      "ERROR": "feed:add:error"
    },
    "UPDATE": {
      "EVENT": "feed:update",
      "SUCCESS": "feed:update:success",
      "ERROR": "feed:update:error"
    },
    "GET_ALL": {
      "EVENT": "feed:getAll",
      "SUCCESS": "feed:getAll:success",
      "ERROR": "feed:getAll:error"
    },
    "GET": {
      "EVENT": "feed:get",
      "SUCCESS": "feed:get:success",
      "ERROR": "feed:get:error"
    },
    "DELETE": {
      "EVENT": "feed:delete",
      "SUCCESS": "feed:delete:success",
      "ERROR": "feed:delete:error"
    }
  },
  "QUIZ": {
    "ADD": {
      "EVENT": "quiz:add",
      "SUCCESS": "quiz:add:success",
      "ERROR": "quiz:add:error"
    },
    "UPDATE": {
      "EVENT": "quiz:update",
      "SUCCESS": "quiz:update:success",
      "ERROR": "quiz:update:error"
    },
    "GET_ALL": {
      "EVENT": "quiz:getAll",
      "SUCCESS": "quiz:getAll:success",
      "ERROR": "quiz:getAll:error"
    },
    "GET": {
      "EVENT": "quiz:get",
      "SUCCESS": "quiz:get:success",
      "ERROR": "quiz:get:error"
    },
    "DELETE": {
      "EVENT": "quiz:delete",
      "SUCCESS": "quiz:delete:success",
      "ERROR": "quiz:delete:error"
    }
  },
  "REPORT": {
    "ADD": {
      "EVENT": "report:add",
      "SUCCESS": "report:add:success",
      "ERROR": "report:add:error"
    },
    "UPDATE": {
      "EVENT": "report:update",
      "SUCCESS": "report:update:success",
      "ERROR": "report:update:error"
    },
    "GET_ALL": {
      "EVENT": "report:getAll",
      "SUCCESS": "report:getAll:success",
      "ERROR": "report:getAll:error"
    },
    "GET": {
      "EVENT": "report:get",
      "SUCCESS": "report:get:success",
      "ERROR": "report:get:error"
    },
    "DELETE": {
      "EVENT": "report:delete",
      "SUCCESS": "report:delete:success",
      "ERROR": "report:delete:error"
    }
  },
  "ERROR_LOG": {
    "ADD": {
      "EVENT": "error-log:add",
      "SUCCESS": "error-log:add:success",
      "ERROR": "error-log:add:error"
    },

    "GET_ALL": {
      "EVENT": "error-log:getAll",
      "SUCCESS": "error-log:getAll:success",
      "ERROR": "error-log:getAll:error"
    }
  },

  "MATERIAL": {
    "ADD": {
      "EVENT": "material:add",
      "SUCCESS": "material:add:success",
      "ERROR": "material:add:error"
    },
    "UPDATE": {
      "EVENT": "material:update",
      "SUCCESS": "material:update:success",
      "ERROR": "material:update:error"
    },
    "GET_ALL": {
      "EVENT": "material:getAll",
      "SUCCESS": "material:getAll:success",
      "ERROR": "material:getAll:error"
    },
    "GET": {
      "EVENT": "material:get",
      "SUCCESS": "material:get:success",
      "ERROR": "material:get:error"
    },
    "DELETE": {
      "EVENT": "material:delete",
      "SUCCESS": "material:delete:success",
      "ERROR": "material:delete:error"
    }
  },
  "HOME_PRODUCT": {
    "TRENDING": {
      "EVENT": "get:trending:products",
      "SUCCESS": "get:trending:products:success",
      "ERROR": "get:trending:products:error"
    },
    "DISCOUNT": {
      "EVENT": "getAll:discount:products",
      "SUCCESS": "getAll:discount:products:success"
    }
  },
  "BUNDLE": {
    "ADD": {
      "EVENT": "bundle:add",
      "SUCCESS": "bundle:add:success",
      "ERROR": "bundle:add:error"
    },
    "UPDATE": {
      "EVENT": "bundle:update",
      "SUCCESS": "bundle:update:success",
      "ERROR": "bundle:update:error"
    },
    "GET_ALL": {
      "SOLR": {
        "EVENT": "solr:bundle:getAll",
        "SUCCESS": "solr:bundle:getAll:success",
        "ERROR": "solr:bundle:getAll:error"
      },
      "EVENT": "bundle:getAll",
      "SUCCESS": "bundle:getAll:success",
      "ERROR": "bundle:getAll:error"
    },
    "GET": {
      "EVENT": "bundle:get",
      "SUCCESS": "bundle:get:success",
      "ERROR": "bundle:get:error"
    },
    "DELETE": {
      "EVENT": "bundle:delete",
      "SUCCESS": "bundle:delete:success",
      "ERROR": "bundle:delete:error"
    },
    "DELETE_MULTIPLE": {
      "EVENT": "bundle:delete:multiple",
      "SUCCESS": "bundle:delete:multiple:success",
      "ERROR": "bundle:delete:multiple:error"
    }
  },
  "INQUIRY_DETAIL": {
    "ADD": {
      "EVENT": "inquiryDetail:add",
      "SUCCESS": "inquiryDetail:add:success",
      "ERROR": "inquiryDetail:add:error"
    },
    "GET": {
      "EVENT": "inquiryDetail:get",
      "SUCCESS": "inquiryDetail:get:success",
      "ERROR": "inquiryDetail:get:error"
    },
    "GET_ALL": {
      "EVENT": "inquiryDetail:getAll",
      "SUCCESS": "inquiryDetail:getAll:success",
      "ERROR": "inquiryDetail:getAll:error"
    }
  },
  "MEAL": {
    "ADD": {
      "EVENT": "meal:add",
      "SUCCESS": "meal:add:success",
      "ERROR": "meal:add:error"
    },
    "UPDATE": {
      "EVENT": "meal:update",
      "SUCCESS": "meal:update:success",
      "ERROR": "meal:update:error"
    },
    "GET_ALL": {
      "EVENT": "meal:getAll",
      "SUCCESS": "meal:getAll:success",
      "ERROR": "meal:getAll:error"
    },
    "GET": {
      "EVENT": "meal:get",
      "SUCCESS": "meal:get:success",
      "ERROR": "meal:get:error"
    },
    "DELETE": {
      "EVENT": "meal:delete",
      "SUCCESS": "meal:delete:success",
      "ERROR": "meal:delete:error"
    }
  },
  "CAR": {
    "ADD": {
      "EVENT": "car:add",
      "SUCCESS": "car:add:success",
      "ERROR": "car:add:error"
    },
    "UPDATE": {
      "EVENT": "car:update",
      "SUCCESS": "car:update:success",
      "ERROR": "car:update:error"
    },
    "GET_ALL": {
      "SOLR": {
        "EVENT": "solr:car:getAll",
        "SUCCESS": "solr:car:getAll:success",
        "ERROR": "solr:car:getAll:error"
      },
      "EVENT": "car:getAll",
      "SUCCESS": "car:getAll:success",
      "ERROR": "car:getAll:error"
    },
    "GET": {
      "EVENT": "car:get",
      "SUCCESS": "car:get:success",
      "ERROR": "car:get:error"
    },
    "DELETE": {
      "EVENT": "car:delete",
      "SUCCESS": "car:delete:success",
      "ERROR": "car:delete:error"
    }
  },
  "EXPIRY_PRODUCTS": {
    "ADD": {
      "EVENT": "expiry:add",
      "SUCCESS": "expiry:add:success",
      "ERROR": "expiry:add:error"
    },
    "ORDER": {
      "PLACE": {
        "EVENT": "expiry-product:order-place",
        "SUCCESS": "expiry-product:order-place:success",
        "ERROR": "expiry-product:order-place:error"
      },
      "GET_ALL": {
        "EVENT": "expiry-product:order-get-all",
        "SUCCESS": "expiry-product:order-get-all:success",
        "ERROR": "expiry-product:order-get-all:error"
      }
    },
    "UPDATE": {
      "SALE_COUNT": {
        "EVENT": "expiry:salecount:update",
        "SUCCESS": "expiry:salecount:update:success",
        "ERROR": "expiry:salecount:update:error"
      },
      "EVENT": "expiry:update",
      "SUCCESS": "expiry:update:success",
      "ERROR": "expiry:update:error"
    },
    "GET_ALL": {
      "BY_IMEI": {
        "EVENT": "imei:expiry:getAll",
        "SUCCESS": "imei:expiry:getAll:success",
        "ERROR": "imei:expiry:getAll:error"
      },
      "EVENT": "expiry:getAll",
      "SUCCESS": "expiry:getAll:success",
      "ERROR": "expiry:getAll:error"
    },
    "GET": {
      "EVENT": "expiry:get",
      "SUCCESS": "expiry:get:success",
      "ERROR": "expiry:get:error"
    },
    "DELETE": {
      "EVENT": "expiry:delete",
      "SUCCESS": "expiry:delete:success",
      "ERROR": "expiry:delete:error"
    }
  },
  "IMEI": {
    "ADD": {
      "EVENT": "imei:add",
      "SUCCESS": "imei:add:success",
      "ERROR": "imei:add:error"
    },
    "UPDATE": {
      "EVENT": "imei:update",
      "SUCCESS": "imei:update:success",
      "ERROR": "imei:update:error"
    },
    "GET_ALL": {
      "EVENT": "imei:getAll",
      "SUCCESS": "imei:getAll:success",
      "ERROR": "imei:getAll:error"
    },
    "GET": {
      "EVENT": "imei:get",
      "SUCCESS": "imei:get:success",
      "ERROR": "imei:get:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "imei:delete:multiple",
        "SUCCESS": "imei:delete:multiple:success",
        "ERROR": "imei:delete:multiple:error"
      },

      "EVENT": "imei:delete",
      "SUCCESS": "imei:delete:success",
      "ERROR": "imei:delete:error"
    }
  },
  "MEETING": {
    "ADD": {
      "EVENT": "meeting:add",
      "SUCCESS": "meeting:add:success",
      "ERROR": "meeting:add:error"
    },
    "UPDATE": {
      "EVENT": "meeting:update",
      "SUCCESS": "meeting:update:success",
      "ERROR": "meeting:update:error"
    },
    "GET_ALL": {
      "EVENT": "meeting:getAll",
      "SUCCESS": "meeting:getAll:success",
      "ERROR": "meeting:getAll:error"
    },
    "GET": {
      "EVENT": "meeting:get",
      "SUCCESS": "meeting:get:success",
      "ERROR": "meeting:get:error",
      "BY_EMPLOYEE": {
        "EVENT": "meeting:getBy-employee",
        "SUCCESS": "meeting:getBy-employee:success",
        "ERROR": "meeting:getBy-employee:error",
      },
      "BY_COUNT": {
        "EVENT": "meeting:get:count",
        "SUCCESS": "meeting:get:count:success",
        "ERROR": "meeting:get:count:error",
      }
    },
    "DELETE": {
      "EVENT": "meeting:delete",
      "SUCCESS": "meeting:delete:success",
      "ERROR": "meeting:delete:error"
    }
  },
  "EMPLOYEE": {
    "ADD": {
      "EVENT": "sales:employee:add",
      "SUCCESS": "sales:employee:add:success",
      "ERROR": "sales:employee:add:error"
    },
    "UPDATE": {
      "EVENT": "sales:employee:update",
      "SUCCESS": "sales:employee:update:success",
      "ERROR": "sales:employee:update:error"
    },
    "CHECK_AVAILABILITY": {
      "EVENT": "employee:check-availability",
      "SUCCESS": "employee:check-availability:success",
      "ERROR": "employee:check-availability:error"
    },
    "LOCATION": {
      "UPDATE": {
        "EVENT": "employee:location:update",
        "SUCCESS": "employee:location:update:success",
        "ERROR": "employee:location:update:error"
      },
      "MULTIPLE_UPDATE": {
        "EVENT": "employee:location-multiple:update",
        "SUCCESS": "employee:location-multiple:update:success",
        "ERROR": "employee:location-multiple:update:error"
      }
    },
    "IN_OUT_TIME": {
      "UPDATE": {
        "EVENT": "employee:in-out:update",
        "SUCCESS": "employee:in-out:update:success",
        "ERROR": "employee:in-out:update:error"
      },
    },
    "LOCATION_OBJECT": {
      "UPDATE": {
        "EVENT": "location:object:update",
        "SUCCESS": "location:object:update:success",
        "ERROR": "location:object:update:error"
      },
    },
    "GET_ALL": {
      "EVENT": "sales:employee:getAll",
      "SUCCESS": "sales:employee:getAll:success",
      "ERROR": "sales:employee:getAll:error"
    },
    "GET_ALL_FOR_TEAM": {
      "EVENT": "employee:getAll-team",
      "SUCCESS": "employee:getAll-team:success",
      "ERROR": "employee:getAll-team:error"
    },
    "VERIFY": {
      "EVENT": "employee:login:verify",
      "SUCCESS": "employee:login:verify:success",
      "ERROR": "employee:login:verify:error"
    },
    "AUTHENTICATE": {
      "EVENT": "employee:authenticate",
      "SUCCESS": "employee:authenticate:success",
      "ERROR": "employee:authenticate:error"
    },
    "GET": {
      "EVENT": "sales:employee:get",
      "SUCCESS": "sales:employee:get:success",
      "ERROR": "sales:employee:get:error"
    },
    "GET_OTHER_DETAILS": {
      "EVENT": "employee:get-details",
      "SUCCESS": "employee:get-details:success",
      "ERROR": "employee:get-details:error"
    },
    "GET_LIVE_LOCATION": {
      "EVENT": "employee:get-live-location",
      "SUCCESS": "employee:get-live-location:success",
      "ERROR": "employee:get-live-location:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "employee:delete:multiple",
        "SUCCESS": "employee:delete:multiple:success",
        "ERROR": "employee:delete:multiple:error"
      },

      "EVENT": "sales:employee:delete",
      "SUCCESS": "sales:employee:delete:success",
      "ERROR": "sales:employee:delete:error"
    }
  },
  "QUIZ_DETAILS": {
    "BATCH": {
      "ADD": {
        "EVENT": "quiz-batch:add",
        "SUCCESS": "quiz-batch:add:success",
        "ERROR": "quiz-batch:add:error"
      },
      "UPDATE": {
        "EVENT": "quiz-batch:update",
        "SUCCESS": "quiz-batch:update:success",
        "ERROR": "quiz-batch:update:error"
      },
      "GET_ALL": {
        "EVENT": "quiz-batch:getAll",
        "SUCCESS": "quiz-batch:getAll:success",
        "ERROR": "quiz-batch:getAll:error"
      },
      "GET": {
        "EVENT": "quiz-batch:get",
        "SUCCESS": "quiz-batch:get:success",
        "ERROR": "quiz-batch:get:error"
      },
      "DELETE": {
        "MULTIPLE": {
          "EVENT": "quiz-batch:delete:multiple",
          "SUCCESS": "quiz-batch:delete:multiple:success",
          "ERROR": "quiz-batch:delete:multiple:error"
        },

        "EVENT": "quiz-batch:delete",
        "SUCCESS": "quiz-batch:delete:success",
        "ERROR": "quiz-batch:delete:error"
      }
    },
    "RESULTS": {
      "ADD": {
        "EVENT": "quiz-result:add",
        "SUCCESS": "quiz-result:add:success",
        "ERROR": "quiz-result:add:error"
      },
      "GET_ALL": {
        "EVENT": "quiz-result:getAll",
        "SUCCESS": "quiz-result:getAll:success",
        "ERROR": "quiz-result:getAll:error"
      }

    }
  },

  "EVENT": {
    "ADD": {
      "EVENT": "event:add",
      "SUCCESS": "event:add:success",
      "ERROR": "event:add:error"
    },
    "UPDATE": {
      "EVENT": "event:update",
      "SUCCESS": "event:update:success",
      "ERROR": "event:update:error"
    },
    "GET_ALL": {
      "EVENT": "event:getAll",
      "SUCCESS": "event:getAll:success",
      "ERROR": "event:getAll:error"
    },
    "GET": {
      "EVENT": "event:get",
      "SUCCESS": "event:get:success",
      "ERROR": "event:get:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "event:delete:multiple",
        "SUCCESS": "event:delete:multiple:success",
        "ERROR": "event:delete:multiple:error"
      },

      "EVENT": "event:delete",
      "SUCCESS": "event:delete:success",
      "ERROR": "event:delete:error"
    }
  },

  "TASK": {
    "ADD": {
      "EVENT": "task:add",
      "SUCCESS": "task:add:success",
      "ERROR": "task:add:error"
    },
    "UPDATE": {
      "EVENT": "task:update",
      "SUCCESS": "task:update:success",
      "ERROR": "task:update:error"
    },
    "GET_ALL": {
      "EVENT": "task:getAll",
      "SUCCESS": "task:getAll:success",
      "ERROR": "task:getAll:error"
    },
    "GET": {
      "EVENT": "task:get",
      "SUCCESS": "task:get:success",
      "ERROR": "task:get:error",
      "BY_DATE": {
        "EVENT": "task:get-by-date",
        "SUCCESS": "task:get-by-date:success",
        "ERROR": "task:get-by-date:error"
      }
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "task:delete:multiple",
        "SUCCESS": "task:delete:multiple:success",
        "ERROR": "task:delete:multiple:error"
      },

      "EVENT": "task:delete",
      "SUCCESS": "task:delete:success",
      "ERROR": "task:delete:error"
    }
  },
  "TEAM": {
    "ADD": {
      "EVENT": "team:add",
      "SUCCESS": "team:add:success",
      "ERROR": "team:add:error"
    },
    "UPDATE": {
      "EVENT": "team:update",
      "SUCCESS": "team:update:success",
      "ERROR": "team:update:error"
    },
    "GET_ALL": {
      "EVENT": "team:getAll",
      "SUCCESS": "team:getAll:success",
      "ERROR": "team:getAll:error"
    },
    "GET_ALL_TEAM_ONLY": {
      "EVENT": "team:getAll-only",
      "SUCCESS": "team:getAll-only:success",
      "ERROR": "team:getAll-only:error"
    },
    "GET": {
      "EVENT": "team:get",
      "SUCCESS": "team:get:success",
      "ERROR": "team:get:error",
      "BY_LEADER": {
        "EVENT": "team:get:by-leader",
        "SUCCESS": "team:get:by-leader:success",
        "ERROR": "team:get:by-leader:error",
      },
      "BY_LOGGED_IN_USER": {
        "EVENT": "team:get:by-logged-in-user",
        "SUCCESS": "team:get:by-logged-in-user:success",
        "ERROR": "team:get:by-logged-in-user:error",
      }
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "team:delete:multiple",
        "SUCCESS": "team:delete:multiple:success",
        "ERROR": "team:delete:multiple:error"
      },

      "EVENT": "team:delete",
      "SUCCESS": "team:delete:success",
      "ERROR": "team:delete:error"
    }
  },
  "LOCATION_HISTORY": {
    "GET": {
      "BY_EMPLOYEE": {
        "EVENT": "loc-history:get:by-employee",
        "SUCCESS": "loc-history:get:by-employee:success",
        "ERROR": "loc-history:get:by-employee:error",
      },
      "OF_AVAILABLE_DATE": {
        "EVENT": "loc-history-last-30-days:get:by-employee",
        "SUCCESS": "loc-history-last-30-days:get:by-employee:success",
        "ERROR": "loc-history-last-30-days:get:by-employee:error",
      }
    },
    "GET_TOTAL_DISTANCE": {
      "EVENT": "loc-history:get:total-distance-by-day",
      "SUCCESS": "loc-history:get:total-distance-by-day:success",
      "ERROR": "loc-history:get:total-distance-by-day:error",
    }
  },

  "BEAT_PLAN": {
    "ADD": {
      "EVENT": "beat-plan:add",
      "SUCCESS": "beat-plan:add:success",
      "ERROR": "beat-plan:add:error"
    },
    "UPDATE": {
      "EVENT": "beat-plan:update",
      "SUCCESS": "beat-plan:update:success",
      "ERROR": "beat-plan:update:error"
    },
    "GET_ALL": {
      "EVENT": "beat-plan:getAll",
      "SUCCESS": "beat-plan:getAll:success",
      "ERROR": "beat-plan:getAll:error"
    },
    "GET": {
      "EVENT": "beat-plan:get",
      "SUCCESS": "beat-plan:get:success",
      "ERROR": "beat-plan:get:error"
    },
    "GET_BY_EMP": {
      "EVENT": "beat-plan:get:by-empId",
      "SUCCESS": "beat-plan:get:by-empId:success",
      "ERROR": "beat-plan:get:by-empId:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "beat-plan:delete:multiple",
        "SUCCESS": "beat-plan:delete:multiple:success",
        "ERROR": "beat-plan:delete:multiple:error"
      },

      "EVENT": "beat-plan:delete",
      "SUCCESS": "beat-plan:delete:success",
      "ERROR": "beat-plan:delete:error"
    }
  },

  "DISTRIBUTOR": {
    "ADD": {
      "EVENT": "distributor:add",
      "SUCCESS": "distributor:add:success",
      "ERROR": "distributor:add:error"
    },
    "UPDATE": {
      "EVENT": "distributor:update",
      "SUCCESS": "distributor:update:success",
      "ERROR": "distributor:update:error"
    },
    "GET_ALL": {
      "EVENT": "distributor:getAll",
      "SUCCESS": "distributor:getAll:success",
      "ERROR": "distributor:getAll:error"
    },
    "GET_ALL_DISTRIBUTORS": {
      "EVENT": "distributor:getAll-dist",
      "SUCCESS": "distributor:getAll-dist:success",
      "ERROR": "distributor:getAll-dist:error"
    },
    "GET": {
      "EVENT": "distributor:get",
      "SUCCESS": "distributor:get:success",
      "ERROR": "distributor:get:error"
    },
    "GET_NEAR_BY": {
      "EVENT": "distributor:get-near-by",
      "SUCCESS": "distributor:get-near-by:success",
      "ERROR": "distributor:get-near-by:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "distributor:delete:multiple",
        "SUCCESS": "distributor:delete:multiple:success",
        "ERROR": "distributor:delete:multiple:error"
      },

      "EVENT": "distributor:delete",
      "SUCCESS": "distributor:delete:success",
      "ERROR": "distributor:delete:error"
    }
  },
  "ATTENDANCE": {
    "ADD": {
      "EVENT": "attendance:add",
      "SUCCESS": "attendance:add:success",
      "ERROR": "attendance:add:error"
    },
    "UPDATE": {
      "EVENT": "attendance:update",
      "SUCCESS": "attendance:update:success",
      "ERROR": "attendance:update:error"
    },
    "GET_ALL": {
      "EVENT": "attendance:getAll",
      "SUCCESS": "attendance:getAll:success",
      "ERROR": "attendance:getAll:error"
    },
    "GET": {
      "EVENT": "attendance:get",
      "SUCCESS": "attendance:get:success",
      "ERROR": "attendance:get:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "attendance:delete:multiple",
        "SUCCESS": "attendance:delete:multiple:success",
        "ERROR": "attendance:delete:multiple:error"
      },

      "EVENT": "attendance:delete",
      "SUCCESS": "attendance:delete:success",
      "ERROR": "attendance:delete:error"
    }
  },

  "EMAIL_GROUP": {
    "ADD": {
      "EVENT": "email:add",
      "SUCCESS": "email:add:success",
      "ERROR": "email:add:error"
    },
    "UPDATE": {
      "EVENT": "email:update",
      "SUCCESS": "email:update:success",
      "ERROR": "email:update:error"
    },
    "GET_ALL": {
      "EVENT": "email:getAll",
      "SUCCESS": "email:getAll:success",
      "ERROR": "email:getAll:error"
    },
    "GET": {
      "EVENT": "email:get",
      "SUCCESS": "email:get:success",
      "ERROR": "email:get:error"
    },
    "DELETE": {
      "MULTIPLE": {
        "EVENT": "email:delete:multiple",
        "SUCCESS": "email:delete:multiple:success",
        "ERROR": "email:delete:multiple:error"
      },

      "EVENT": "email:delete",
      "SUCCESS": "email:delete:success",
      "ERROR": "email:delete:error"
    }
  },


  "LABOUR": {
    "ADD": {
      "EVENT": "labour:add",
      "SUCCESS": "labour:add:success",
      "ERROR": "labour:add:error"
    },
    "UPDATE": {
      "EVENT": "labour:update",
      "SUCCESS": "labour:update:success",
      "ERROR": "labour:update:error"
    },
    "GET_ALL": {
      "SOLR": {
        "EVENT": "solr:labour:getAll",
        "SUCCESS": "solr:labour:getAll:success",
        "ERROR": "solr:labour:getAll:error",
      },
      "FROM_SOLR": {
        "EVENT": "solr:labours:getAll",
        "SUCCESS": "solr:labours:getAll:success",
        "ERROR": "solr:labours:getAll:error",
      },
      "EVENT": "labour:getAll",
      "SUCCESS": "labour:getAll:success",
      "ERROR": "labour:getAll:error"
    },
    "GET": {
      "EVENT": "labour:get",
      "SUCCESS": "labour:get:success",
      "ERROR": "labour:get:error"
    },
    "DELETE": {
      "EVENT": "labour:delete",
      "SUCCESS": "labour:delete:success",
      "ERROR": "labour:delete:error"
    }
  }
};