'use strict';

var express = require('express');
var router = express();
var path = require("path");
var oppressor = require("oppressor");
var fs = require("fs");
var Helper = require('../../../app/api/shared/server.helper');
var EmployeeCompany = require('../models/server.employee.company.model');
var EmployeeProducts = require('../models/server.bulk.product.model');
var SharedHelper = require('../../../app/api/render/shared');

router.get("/:ownerId", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('ejs', require('ejs').renderFile);
      var reqpath = path.join(_SERVER_ROOT, `/public/salesarmy/views/promotion/vendor.products.ejs`);
      var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
      var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
      var sort = {};
      sort["priority"] = "desc";
      var options = {
        limit: limit,
        page: page,
        sort: sort,
        select: {
          name: 1,
          price: 1,
          score: 1
        },
        lean: true
      };
      var qf = {isDeleted: false, store: store._id};
      qf.employee = req.params.ownerId;
      Helper.getCurrencyRates()
        .then(function (rates) {
          store.currency = rates;
          EmployeeProducts.paginate(qf, options).then(data => {
            // res.send(data.docs);
            var renderObj = {
              currency: {},
              store: store,
              pageTitle: "Product List",
              moment: _MOMENT,
              searchTerm: "",
              products: data.docs,
              checkAddon: SharedHelper.checkAddon,
              checkModule: SharedHelper.checkModule,
              truncateString: SharedHelper.truncateString,
              currencyFilter: SharedHelper.currencyFilter,
              currencyFilterForStore: SharedHelper.currencyFilterForStore,
              optimizeImage: Helper.optimizeImage,
              redirectTo: req.session && req.session.redirectTo ? req.session.redirectTo : null,
              getTemplate: SharedHelper.getTemplate,
              getHelperFunction: SharedHelper.getHelperFunction,
              headerRequired: req.query.headerNotRequired ? false : true
            };
            let themeDir = store.theme.isStatic ? store.theme.directory : '/default';
            if (fs.existsSync(global._SERVER_ROOT + '/static/' + store.subdomain + themeDir + "/pages/footer.html")) {
              renderObj.footerPath = global._SERVER_ROOT + '/static/' + store.subdomain + themeDir + "/pages/footer.html";
            } else {
              renderObj.footerPath = null;
            }
            if (fs.existsSync(global._SERVER_ROOT + '/static/' + store.subdomain + themeDir + "/pages/header.html")) {
              renderObj.headerPath = global._SERVER_ROOT + '/static/' + store.subdomain + themeDir + "/pages/header.html";
            } else {
              renderObj.headerPath = null;
            }
            res.render(reqpath, renderObj);
            router.use(express.static(_SERVER_ROOT + '/public/osiv'));
          });
        });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

router.get("/", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('ejs', require('ejs').renderFile);
      var reqpath = path.join(_SERVER_ROOT, `/public/salesarmy/views/promotion/vendors.ejs`);
      var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
      var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
      var sort = {};
      sort["priority"] = "desc";
      var options = {
        limit: limit,
        page: page,
        sort: sort,
        select: {
          name: 1,
          pictures: 1,
          address: 1,
          owner: 1
        },
        lean: true,
        populate: [
          {path: "pictures", model: "PrivateFile", select: '_id metadata fileId url store'}
        ]
      };
      var qf = {isDeleted: false, store: store._id};
      if (req.query && req.query["location"] && req.query["location"].length > 0) {
        qf.categories = req.query.location;
      }
      EmployeeCompany.paginate(qf, options).then(data => {
        var renderObj = {
          currency: {},
          store: store,
          pageTitle: "Stores",
          moment: _MOMENT,
          searchTerm: "",
          companies: data.docs,
          checkAddon: SharedHelper.checkAddon,
          checkModule: SharedHelper.checkModule,
          truncateString: SharedHelper.truncateString,
          currencyFilter: SharedHelper.currencyFilter,
          currencyFilterForStore: SharedHelper.currencyFilterForStore,
          optimizeImage: Helper.optimizeImage,
          redirectTo: req.session && req.session.redirectTo ? req.session.redirectTo : null,
          getTemplate: SharedHelper.getTemplate,
          getHelperFunction: SharedHelper.getHelperFunction,
          headerRequired: req.query.headerNotRequired ? false : true
        };
        renderObj.currentPage = _.isString(page) ? parseInt(page) : page;
        renderObj.nextPage = renderObj.currentPage != renderObj.pages && renderObj.currentPage < renderObj.pages ? renderObj.currentPage + 1 : false;
        renderObj.totalPages = renderObj.pages;
        let themeDir = store.theme.isStatic ? store.theme.directory : '/default';
        if (fs.existsSync(global._SERVER_ROOT + '/static/' + store.subdomain + themeDir + "/pages/footer.html")) {
          renderObj.footerPath = global._SERVER_ROOT + '/static/' + store.subdomain + themeDir + "/pages/footer.html";
        } else {
          renderObj.footerPath = null;
        }
        if (fs.existsSync(global._SERVER_ROOT + '/static/' + store.subdomain + themeDir + "/pages/header.html")) {
          renderObj.headerPath = global._SERVER_ROOT + '/static/' + store.subdomain + themeDir + "/pages/header.html";
        } else {
          renderObj.headerPath = null;
        }
        res.render(reqpath, renderObj);
        router.use(express.static(_SERVER_ROOT + '/public/osiv'));
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

module.exports = router;