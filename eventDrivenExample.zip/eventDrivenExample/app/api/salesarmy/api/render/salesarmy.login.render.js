'use strict';

var express = require('express');
var router = express();
var path = require("path");
var oppressor = require("oppressor");
var fs = require("fs");
var Helper = require('../../../app/api/shared/server.helper');
router.get("/", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('html', require('ejs').renderFile);
      var reqpath = path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.login.html`);
      if(Helper.checkAddonBoolean(store,"MLM_WALLET")){
        reqpath = path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.static.login.html`)
      }
      res.render(reqpath, {
        currency: {},
        currencyFilter : function(){},
        currencyFilterForStore : function(){},
        store: store,
        checkAddon: Helper.checkAddonBoolean,
        redirectTo: req.session && req.session.redirectTo ? req.session.redirectTo : null,
        optimizeImage: Helper.optimizeImage
      });
      router.use(express.static(_SERVER_ROOT + '/public/salesarmy/views'));
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

module.exports = router;