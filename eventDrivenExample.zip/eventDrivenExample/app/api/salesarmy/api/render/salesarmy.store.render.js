'use strict';

var express = require('express');
var router = express();
var path = require("path");
var oppressor = require("oppressor");
var fs = require("fs");
var Helper = require('../../../app/api/shared/server.helper');
var Store = require('../../../app/api/models/server.store.model');

router.get("/view/:storeId", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      var options = {
        lean: true,
        select: {
          hostname: 1,
          domain: 1,
          subdomain: 1,
          promotions: 1,
          name: 1,
          package: 1,
          owner: 1,
          address: 1,
          settings: 1,
          mobileAppId: 1,
          emailServer: 1
        },
        populate: [{
          path: 'package',
          model: 'StorePackage',
          select: '_id name addOns price expiresAt name storeModules modules'
        }, {
          path: 'owner',
          model: 'Seller',
          select: '_id firstName lastName phone'
        }, {
          path: 'address',
          model: 'Address',
          select: 'address1 address2 city country state zip'
        }]
      };
      var qf = {isDeleted: false, _id: req.params.storeId};
      Store.paginate(qf, options).then(function (documents) {
        res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.store.view.ejs`), {
          store: store,
          currentStore: documents && documents.docs && documents.docs.length > 0 ? documents.docs[0] : null
        });
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});
router.get("/", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('html', require('ejs').renderFile);
      var offset = _.isUndefined(req.query.start) ? 0 : req.query.start;
      var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
      var sort = {createdAt: "desc"};
      if (!_.isUndefined(req.query.length)) {
        if (parseInt(req.query.length) === -1) {
          limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
        } else {
          if (parseInt(req.query.length) !== -1 && req.query.length !== undefined) {
            limit = req.query.length;
          } else {
            limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
          }
        }
      }
      if (!req.query.ajax) {
        limit = 0;
      }
      var options = {
        offset: parseInt(offset),
        limit: parseInt(limit),
        sort: sort,
        lean: true,
        populate: [{
          path: 'package',
          model: 'StorePackage',
          select: '_id name addOns price promotions modules'
        }, {
          path: 'owner',
          model: 'Seller',
          select: '_id firstName lastName phone'
        }]
      };

      var qf = {isDeleted: false};
      if (req.query.search && req.query.search.value.length > 0) {
        qf["$or"] = [{'domain': {'$regex': req.query.search.value, '$options': '$i'}},
          {'hostname': {'$regex': req.query.search.value, '$options': '$i'}},
          {'subdomain': {'$regex': req.query.search.value, '$options': '$i'}}]
      }
      Store.paginate(qf, options).then(function (documents) {
        if (req.query && req.query.ajax) {
          res.send({data: documents.docs, recordsFiltered: documents.total, recordsTotal: 0})
        } else {
          res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.store.ejs`), {
            store: store,
            stores: documents.docs,
            currentTotal: documents.pages
          });
        }
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

module.exports = router;