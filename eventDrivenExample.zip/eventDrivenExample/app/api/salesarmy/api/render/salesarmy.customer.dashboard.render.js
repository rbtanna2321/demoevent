'use strict';

var express = require('express');
var router = express();
var path = require("path");
var oppressor = require("oppressor");
var mongoose = require("mongoose");
var chance = require('chance');
var passcode = require("passcode");
var Helper = require('../../../app/api/shared/server.helper');
var Referrals = require("../models/server.referrals.model");
var Points = require("../models/promotion/server.point.wallet.model");
var Employee = require("../models/server.employee.model");
var Passcode = require("../../../app/api/models/server.passcode.model");

router.get("/", function (req, res, next) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('html', require('ejs').renderFile);
      if (Helper.checkAddonBoolean(store, "MLM_WALLET")) {
        Referrals.findOne({employee: req.employeeData.user._id, isDeleted: false})
          .then(ref => {
            Points.aggregate([{
              $match:
                {
                  store: mongoose.Types.ObjectId(store._id),
                  isDeleted: false,
                  employee: mongoose.Types.ObjectId(req.employeeData.user._id),
                  typeOfWallet: "reward"
                }
            }, {
              $group: {
                _id: {
                  _id: null,
                },
                total: {$sum: "$value"},
                withdrawal: {$sum: "$withdrawal"}
              }
            }]).then(points => {
              var rewardObj = {total: 0};
              if (points && points.length > 0) {
                rewardObj.total = points[0].total;
                rewardObj.withdrawal = points[0].withdrawal;
              }
              Referrals.countDocuments({
                store: store._id,
                isDeleted: false,
                referrer: req.employeeData.user._id,
              }).then(references => {
                Points.paginate({
                  store: store._id,
                  isDeleted: false,
                  employee: req.employeeData.user._id,
                  typeOfWallet: "reward"
                }, {
                  page: 1,
                  limit: 10,
                  sort: {updatedAt: "desc"},
                  lean: true
                }).then(wallets => {
                  Employee.findOne({_id: req.employeeData.user._id})
                    .then(employee => {
                      if (req.employeeData.user.mlm && req.employeeData.user.mlm.referralCode) {
                        getPasscode(req.employeeData.user.mlm.referralCode)
                          .then(passcode => {
                            res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.customer.dashboard.html`), {
                              store: store,
                              referral: ref,
                              rewardObj: rewardObj,
                              Buffer: Buffer,
                              directReference: references,
                              walletsTotal: _.sum(wallets.docs, 'value'),
                              wallets: wallets.docs && wallets.docs.length > 0 ? wallets.docs : [],
                              securityCode: passcode,
                              employee: employee
                            });
                          });
                      } else {
                        res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.customer.dashboard.html`), {
                          store: store,
                          referral: ref,
                          rewardObj: rewardObj,
                          Buffer: Buffer,
                          directReference: references,
                          walletsTotal: _.sum(wallets.docs, 'value'),
                          wallets: wallets.docs && wallets.docs.length > 0 ? wallets.docs : [],
                          securityCode: null,
                          employee: employee
                        });
                      }
                    });
                });
              })
            });
          });
      } else {
        next();
      }
    } else {
      let stream = fs.createReadStream(path.join(__dirname + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

function getPasscode(value) {
  return new Promise((resolve, reject) => {
    Passcode.findOne({value: value})
      .then(ps => {
        if (ps) {
          resolve(ps.code);
        } else {
          var salt = new chance().natural();
          var code = passcode.totp({
            secret: _CONFIG.secret.seller.key,
            counter: salt,
            digits: 4
          });
          var objPasscode = {};
          objPasscode.code = code;
          objPasscode.salt = salt;
          objPasscode.value = value;
          Passcode.createAsync(objPasscode)
            .then(function (res) {
              resolve(res.code);
            })
            .catch(function (err) {
              reject({error: err, code: 500});
            });
        }
      }).catch(function (err) {
      reject({error: err, code: 500});
    });
  });
}

module.exports = router;