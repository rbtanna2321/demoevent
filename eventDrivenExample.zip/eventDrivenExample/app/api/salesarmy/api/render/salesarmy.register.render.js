'use strict';

var express = require('express');
var router = express();
var path = require("path");
var oppressor = require("oppressor");
var fs = require("fs");
var Helper = require('../../../app/api/shared/server.helper');
router.get("/", function (req, res) {
  if(req.query.code && req.query.code.length > 0) {
    Helper.getStore(req.query.hostname).then(function (store) {
      if (typeof store !== 'undefined' && store._id) {
        if (process.env.NODE_CACHE) {
          res.setHeader('Cache-Control', 'max-age=1800');
        }
        router.engine('html', require('ejs').renderFile);
        var templatePath = '/public/salesarmy/views/salesarmy.register.html';
        if (Helper.checkAddonBoolean(store, "MLM_WALLET")) {
          templatePath = '/public/salesarmy/views/salesarmy.register.invite.html'
        }
        res.render(path.join(_SERVER_ROOT, templatePath), {
          currency: {},
          currencyFilter: function () {},
          currencyFilterForStore: function () {},
          store: store,
          optimizeImage: Helper.optimizeImage
        });
        router.use(express.static(_SERVER_ROOT + '/public/salesarmy/views'));
      } else {
        let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
        stream.pipe(oppressor(req)).pipe(res);
      }
    });
  } else {
    res.redirect('/manage/login');
  }
});

module.exports = router;