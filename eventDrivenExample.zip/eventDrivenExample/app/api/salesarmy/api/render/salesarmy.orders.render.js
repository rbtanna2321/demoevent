'use strict';

var express = require('express');
var router = express();
var path = require("path");
var oppressor = require("oppressor");
var fs = require("fs");
var Helper = require('../../../app/api/shared/server.helper');
var Order = require('../models/server.bulk.order.model');

router.get("/", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('html', require('ejs').renderFile);
      var offset = _.isUndefined(req.query.start) ? 0 : req.query.start;
      var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
      var sort = {createdAt: "desc"};
      if (!_.isUndefined(req.query.length)) {
        if (parseInt(req.query.length) === -1) {
          limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
        } else {
          if (parseInt(req.query.length) !== -1 && req.query.length !== undefined) {
            limit = req.query.length;
          } else {
            limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
          }
        }
      }
      if (!req.query.ajax) {
        limit = 0;
      }
      var options = {
        offset: parseInt(offset),
        limit: parseInt(limit),
        sort: sort,
        lean: true,
        populate: [{
          path: 'client',
          select: '_id name'
        }, {
          path: 'employee',
          select: '_id firstName lastName email'
        }, {
          path: 'buyer',
          select: '_id firstName lastName'
        }, {
          path: 'items.item',
          select: 'name price description'
        }]
      };
      var qf = {store: store._id, isDeleted: false};
      if (req.query.search && req.query.search.value.length > 0) {
        qf['$or'] = [];
        qf['$or'].push({'name': {'$regex': req.query.search.value, '$options': 'i'}});
        qf['$or'].push({'description': {'$regex': req.query.search.value, '$options': 'i'}});
      }
      if (!store.settings.salesarmy.showOrdersAddedByOtherEmployees && req.employeeData.user._id != store.owner._id) {
        qf['employee'] = req.employeeData.user._id;
      }
      Order.paginate(qf, options).then(function (documents) {
        if (req.query && req.query.ajax) {
          res.send({data: documents.docs, recordsFiltered: documents.total, recordsTotal: 0})
        } else {
          var viewPath = `/public/salesarmy/views/salesarmy.orders.ejs`;
          if (Helper.checkAddonBoolean(store, "MLM")) {
            viewPath = `/public/salesarmy/views/salesarmy.mlm.orders.html`;
          }
          res.renderViewToClient(req, res, path.join(_SERVER_ROOT, viewPath), {
            store: store,
            orders: documents.docs,
            currentTotal: documents.pages
          });
        }
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

module.exports = router;