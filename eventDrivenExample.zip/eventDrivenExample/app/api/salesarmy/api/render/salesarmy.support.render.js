'use strict';

var express = require('express');
var router = express();
var path = require("path");
var oppressor = require("oppressor");
var fs = require("fs");
var Helper = require('../../../app/api/shared/server.helper');

router.get("/tickets", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('html', require('ejs').renderFile);
      res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.tickets.html`), {
        store: store
      });
    } else {
      let stream = fs.createReadStream(path.join(__dirname + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

module.exports = router;