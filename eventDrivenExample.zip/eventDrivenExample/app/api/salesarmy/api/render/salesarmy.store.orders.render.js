'use strict';

var express = require('express');
var router = express();
var path = require("path");
var oppressor = require("oppressor");
var fs = require("fs");
var Helper = require('../../../app/api/shared/server.helper');
var Order = require('../../../app/api/models/server.order.model');
var Shipment = require('../../../app/api/models/server.shipment.model');

router.get("/:orderId/shipment", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('html', require('ejs').renderFile);
      var offset = _.isUndefined(req.query.start) ? 0 : req.query.start;
      var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
      var sort = {createdAt: "desc"};
      if (!_.isUndefined(req.query.length)) {
        if (parseInt(req.query.length) === -1) {
          limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
        } else {
          if (parseInt(req.query.length) !== -1 && req.query.length !== undefined) {
            limit = req.query.length;
          } else {
            limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
          }
        }
      }
      if (!req.query.ajax) {
        limit = 0;
      }
      var options = {
        offset: parseInt(offset),
        limit: parseInt(limit),
        sort: sort,
        lean: true,
        select: {
          item :1,
          customer:1,
          comment:1,
          order:1,
        }
      };
      var qf = {store: store._id, isDeleted: false, order: req.params.orderId};
      if (req.query.search && req.query.search.value.length > 0) {
        qf['$or'] = [];
        qf['$or'].push({'name': {'$regex': req.query.search.value, '$options': 'i'}});
      }
      Shipment.paginate(qf, options).then(function (documents) {
        if (req.query && req.query.ajax) {
          res.send({data: documents.docs, recordsFiltered: documents.total, recordsTotal: 0})
        } else {
          res.end();
        }
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});
router.get("/:orderId", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('html', require('ejs').renderFile);
      var offset = _.isUndefined(req.query.start) ? 0 : req.query.start;
      var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
      var sort = {createdAt: "desc"};
      if (!_.isUndefined(req.query.length)) {
        if (parseInt(req.query.length) === -1) {
          limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
        } else {
          if (parseInt(req.query.length) !== -1 && req.query.length !== undefined) {
            limit = req.query.length;
          } else {
            limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
          }
        }
      }

      var options = {
        offset: parseInt(offset),
        limit: parseInt(limit),
        sort: sort,
        lean: true,
        populate:[{
          path:"customer",
          model:"Customer",
          select:"email firstName lastName mobile"
        },{
          path:"shippingAddress",
          model:"Address",
          select:"address1 address2 email zip country state city phone name"
        },{
          path:"items.item.images",
          model:"File",
          select:"_id fileId store url metadata"
        },{
          path:"bundles.bundle",
          model:"Bundle",
          select:"_id name items"
        },{
          path:"paymentLink",
          model:"paymentLinks",
          select:"_id link"
        }]
      };
      var qf = {store: store._id, isDeleted: false, _id: req.params.orderId};
      if (req.query.search && req.query.search.value.length > 0) {
        qf['$or'] = [];
        qf['$or'].push({'name': {'$regex': req.query.search.value, '$options': 'i'}});
      }
      Order.paginate(qf, options).then(function (documents) {
          res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.store.order.view.ejs`), {
            store: store,
            order: documents && documents.docs && documents.docs.length > 0 ? documents.docs[0] : null,
            currentTotal: documents.pages,
            currentOrderId: req.params.orderId
          });
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});
router.get("/", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('html', require('ejs').renderFile);
      var offset = _.isUndefined(req.query.start) ? 0 : req.query.start;
      var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
      var sort = {createdAt: "desc"};
      if (!_.isUndefined(req.query.length)) {
        if (parseInt(req.query.length) === -1) {
          limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
        } else {
          if (parseInt(req.query.length) !== -1 && req.query.length !== undefined) {
            limit = req.query.length;
          } else {
            limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
          }
        }
      }
      if (!req.query.ajax) {
        limit = 0;
      }
      var options = {
        offset: parseInt(offset),
        limit: parseInt(limit),
        sort: sort,
        lean: true
      };
      var qf = {store: store._id, isDeleted: false};
      if (req.query.search && req.query.search.value.length > 0) {
        qf['$or'] = [];
        qf['$or'].push({'name': {'$regex': req.query.search.value, '$options': 'i'}});
      }
      Order.paginate(qf, options).then(function (documents) {
        if (req.query && req.query.ajax) {
          res.send({data: documents.docs, recordsFiltered: documents.total, recordsTotal: 0})
        } else {
          res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.store.orders.html`), {
            store: store,
            employees: documents.docs,
            currentTotal: documents.pages
          });
        }
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

module.exports = router;