'use strict';

var express = require('express');
var router = express();
var path = require("path");
var oppressor = require("oppressor");
var fs = require("fs");
var mongoose = require("mongoose");
var Helper = require('../../../app/api/shared/server.helper');
var Catalog = require('../models/server.catalog.model');

router.get("/", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('html', require('ejs').renderFile);
      var offset = _.isUndefined(req.query.start) ? 0 : req.query.start;
      var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
      var sort = {createdAt: "desc"};
      if (!_.isUndefined(req.query.length)) {
        if (parseInt(req.query.length) === -1) {
          limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
        } else {
          if (parseInt(req.query.length) !== -1 && req.query.length !== undefined) {
            limit = req.query.length;
          } else {
            limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
          }
        }
      }
      if (!req.query.ajax) {
        limit = 0;
      }
      var options = {
        offset: parseInt(offset),
        limit: parseInt(limit),
        sort: sort,
        lean: true,
        populate: [
          {path: "products", model: "Sales-Product", select: '_id name price'},
          {path: "user.object", select: '_id name'},
          {path: "employee", model: "Sales-Employee", select: "_id firstName lastName"},
        ],
        // distinct: "user"
      };
      var qf = {store: store._id, isDeleted: false};
      if (req.query.search && req.query.search.value.length > 0) {
        var $match = {
          store: mongoose.Types.ObjectId(store._id),
          isDeleted: false
        };
        var matchQuery = [
          {
            $match: $match
          },
          {
            "$lookup": {
              "from": "sales-distributors",
              "localField": "client",
              "foreignField": "_id",
              "as": "client"
            }
          },
          {$unwind: '$client'},
          {
            $match: {
              $or: [{
                "client.name": {
                  $regex: req.query.search.value,
                  $options: 'g'
                }
              }, {
                "client.email": {
                  $regex: req.query.search.value,
                  $options: 'g'
                }
              }]
            }
          },
          {
            $limit: parseInt(limit)
          }
        ];
        Catalog.aggregate(matchQuery).then(s => {
          res.send({data: s, recordsFiltered: s.length, recordsTotal: 0})
        }).catch(r => {
          console.log(r);
        });
      } else {
        Catalog.paginate(qf, options).then(function (documents) {
          if (req.query && req.query.ajax) {
            res.send({data: documents.docs, recordsFiltered: documents.total, recordsTotal: 0})
          } else {
            res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.catalog.html`), {
              store: store,
              employees: documents.docs,
              currentTotal: documents.pages
            });
          }
        });
      }
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});
router.get("/:catalogId", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      var options = {
        lean: true,
        populate: [{path: "product", model: "Sales-Product", select: '_id name price qty description sku'}]
      };
      if (!req.query.ajax) {
        options.limit = 1;
      }
      var qf = {store: store._id, isDeleted: false, 'user.object': req.params.catalogId};
      Catalog.paginate(qf, options).then(function (documents) {
        if (req.query && req.query.ajax) {
          res.send({data: documents.docs, recordsFiltered: documents.total, recordsTotal: 0})
        } else {
          if(documents.docs.length > 0) {
            res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.catalog.view.ejs`), {
              store: store,
              catalog: documents.docs[0].user
            });
          } else {
            let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/404.html'));
            stream.pipe(oppressor(req)).pipe(res);
          }
        }
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});
module.exports = router;