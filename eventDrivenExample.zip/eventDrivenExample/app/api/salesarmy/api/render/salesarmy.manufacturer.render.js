'use strict';

var express = require('express');
var router = express();
var path = require("path");
var oppressor = require("oppressor");
var fs = require("fs");
var Helper = require('../../../app/api/shared/server.helper');
var Manufacturer = require('../../../app/api/models/server.manufacturer.model');

router.get("/", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('html', require('ejs').renderFile);
      var offset = _.isUndefined(req.query.start) ? 0 : req.query.start;
      var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
      var sort = {createdAt: "desc"};
      if (!_.isUndefined(req.query.length)) {
        if (parseInt(req.query.length) === -1) {
          limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
        } else {
          if (parseInt(req.query.length) !== -1 && req.query.length !== undefined) {
            limit = req.query.length;
          } else {
            limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
          }
        }
      }
      if (!req.query.ajax) {
        limit = 0;
      }
      var options = {
        offset: parseInt(offset),
        limit: parseInt(limit),
        sort: sort,
        lean: true,
        populate: [{path: "image", model: "File", select: '_id metadata fileId url store'},
          {path: "coverImages", model: "File", select: '_id metadata fileId url store'}]
      };

      var qf = {isDeleted: false};
      if (req.query.search && req.query.search.value.length > 0) {
        qf["$or"] = [{'domain': {'$regex': req.query.search.value, '$options': '$i'}},
          {'hostname': {'$regex': req.query.search.value, '$options': '$i'}},
          {'subdomain': {'$regex': req.query.search.value, '$options': '$i'}}]
      }
      Manufacturer.paginate(qf, options).then(function (documents) {
        if (req.query && req.query.ajax) {
          res.send({data: documents.docs, recordsFiltered: documents.total, recordsTotal: 0})
        } else {
          res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.manufacturer.ejs`), {
            store: store,
            Currentmanufacturer: documents.docs,
            currentTotal: documents.pages
          });
        }
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

router.get("/add", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.manufacturer.add.ejs`), {
        store: store,
        currentManufacturer: null,
        formContent: ""
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

router.get("/edit/:manufacturerId", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      var options = {
        lean: true,
        populate: [{path: "image", model: "File", select: '_id metadata fileId url store'},
          {path: "coverImages", model: "File", select: '_id metadata fileId url store'}]
      };
      var qf = {store: store._id, isDeleted: false, _id : req.params.manufacturerId};
      if (req.query.search && req.query.search.value.length > 0) {
        qf['$or'] = [];
        qf['$or'].push({'name': {'$regex': req.query.search.value, '$options': 'i'}});
      }
      Manufacturer.paginate(qf, options).then(function (documents) {
        console.log(documents.docs)
        res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.manufacturer.add.ejs`), {
          store: store,
          currentManufacturer:  documents.docs && documents.docs.length > 0 ? documents.docs[0] : null,
          currentTotal: documents.pages
        });
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

module.exports = router;