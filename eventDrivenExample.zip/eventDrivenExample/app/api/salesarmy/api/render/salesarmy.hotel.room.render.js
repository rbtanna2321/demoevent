'use strict';

var express = require('express');
var router = express();
var path = require("path");
var oppressor = require("oppressor");
var fs = require("fs");
var Helper = require('../../../app/api/shared/server.helper');
var Room = require('../models/server.hotel.room.model');

router.get("/", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      router.engine('html', require('ejs').renderFile);
      var offset = _.isUndefined(req.query.start) ? 0 : req.query.start;
      var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
      var sort = {createdAt: "desc"};
      if (!_.isUndefined(req.query.length)) {
        if (parseInt(req.query.length) === -1) {
          limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
        } else {
          if (parseInt(req.query.length) !== -1 && req.query.length !== undefined) {
            limit = req.query.length;
          } else {
            limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
          }
        }
      }
      if (!req.query.ajax) {
        limit = 0;
      }
      var options = {
        offset: parseInt(offset),
        limit: parseInt(limit),
        sort: sort,
        lean: true,
        populate: [{path:"employee" , model:"Sales-Employee" , select:"_id firstName lastName"},
          {path:"hotel" , model:"Sales-Hotel" , select:"_id name "},
          {path: "images", model: "PrivateFile", select: '_id metadata fileId url store'}]
      };

      var qf = {isDeleted: false};
      if (req.query.search && req.query.search.value.length > 0) {
        qf["$or"] = [{'domain': {'$regex': req.query.search.value, '$options': '$i'}},
          {'hostname': {'$regex': req.query.search.value, '$options': '$i'}},
          {'subdomain': {'$regex': req.query.search.value, '$options': '$i'}}]
      }
      Room.paginate(qf, options).then(function (documents) {
        if (req.query && req.query.ajax) {
          res.send({data: documents.docs, recordsFiltered: documents.total, recordsTotal: 0})
        } else {
          res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.hotel.room.ejs`), {
            store: store,
            CurrentRoom: documents.docs,
            currentTotal: documents.pages
          });
        }
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

router.get("/add", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.hotel.room.add.ejs`), {
        store: store,
        currentRoom: null,
        formContent: ""
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

router.get("/edit/:roomId", function (req, res) {
  Helper.getStore(req.query.hostname).then(function (store) {
    if (typeof store !== 'undefined' && store._id) {
      if (process.env.NODE_CACHE) {
        res.setHeader('Cache-Control', 'max-age=1800');
      }
      var options = {
        lean: true,
        populate: [{path:"employee" , model:"Sales-Employee" , select:"_id firstName lastName"},
          {path:"hotel" , model:"Sales-Hotel" , select:"_id name "},
          {path: "images", model: "PrivateFile", select: '_id metadata fileId url store'}]
      };
      var qf = {store: store._id, isDeleted: false, _id : req.params.roomId};
      if (req.query.search && req.query.search.value.length > 0) {
        qf['$or'] = [];
        qf['$or'].push({'name': {'$regex': req.query.search.value, '$options': 'i'}});
      }
      Room.paginate(qf, options).then(function (documents) {
        res.renderViewToClient(req, res, path.join(_SERVER_ROOT, `/public/salesarmy/views/salesarmy.hotel.room.add.ejs`), {
          store: store,
          currentRoom:  documents.docs && documents.docs.length > 0 ? documents.docs[0] : null,
          currentTotal: documents.pages
        });
      });
    } else {
      let stream = fs.createReadStream(path.join(_SERVER_ROOT + '/public/403.html'));
      stream.pipe(oppressor(req)).pipe(res);
    }
  });
});

module.exports = router;