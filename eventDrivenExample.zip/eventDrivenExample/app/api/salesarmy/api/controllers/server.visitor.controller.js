'use strict';
var  Visitor = require('../models/server.visitor.model');

// Gets a list of Visitors
exports.getAll = function (req) {
  return new Promise(function (resolve, reject) {
    var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
    var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
    var sort = {};
    if (!_.isUndefined(req.query.sortColumn) && !_.isUndefined(req.query.sortOrder)) {
      sort[req.query.sortColumn] = req.query.sortOrder === 'desc' ? -1 : 1;
    } else {
      sort["createdAt"] = -1;
    }
    if (!_.isUndefined(req.query.limit)) {
      if (parseInt(req.query.limit) === -1) {
        limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      } else {
        if (parseInt(req.query.limit) !== -1 && req.query.limit !== undefined) {
          limit = req.query.limit;
        } else {
          limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        }
      }
    }
    var options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: sort,
      lean: true
    };
    if (req.query.query) {
      var qf = {
        $or: [{'name': {'$regex': req.query.query, '$options': '$i'}}],
        isDeleted: false,
        store: req.query.store
      }
    } else {
      qf = {isDeleted: false, store: req.query.store, client: req.query.client};
    }
    Visitor.paginate(qf, options).then(function (result) {
      return result;
    })
      .then(function (data) {
        resolve(data);
      })
      .catch(function (error) {
        _logger.error(error);
        reject(error);
      });
  });
};


// Gets a single Visitor from the DB
exports.get = function (req) {
  return new Promise(function (resolve, reject) {
    Visitor.findOneAsync({_id: req.body._id, isDeleted: false})
      .then(function (res) {
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

// Creates a new Visitor in the DB
exports.add = function (req) {
  return new Promise(function (resolve, reject) {
    Visitor.createAsync(req.body)
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};


// Updates an existing Visitor in the DB
exports.update = function (req) {
  return new Promise(function (resolve, reject) {
    var id = req.body._id;
    if (req.body._id) {
      delete req.body._id;
    }
    Visitor.findOneAndUpdateAsync({_id: id}, req.body, {new: true})
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });

};
