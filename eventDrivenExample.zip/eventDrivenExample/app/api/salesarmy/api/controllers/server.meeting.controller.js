/**
 * Faq controller
 * GET     /api/faq              ->  getAll
 * POST    /api/faq              ->  add
 * GET     /api/faq/:id          ->  get
 * PUT     /api/faq/:id          ->  update
 * DELETE  /api/faq/:id          ->  delete
 */
'use strict';
var Meeting = require('../models/server.meeting.model'),
  Helper = require('../../../app/api/shared/server.helper.js'),
  mongoose = require('mongoose');

exports.getAll = function (req) {
  return new Promise(function (resolve, reject) {
    var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
    var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
    var sort = {};
    if (!_.isUndefined(req.query.sortColumn) && !_.isUndefined(req.query.sortOrder)) {
      sort[req.query.sortColumn] = req.query.sortOrder === 'desc' ? -1 : 1;
    } else {
      sort["createdAt"] = -1;
    }
    if (!_.isUndefined(req.query.limit)) {
      if (parseInt(req.query.limit) === -1) {
        limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      } else {
        if (parseInt(req.query.limit) !== -1 && req.query.limit !== undefined) {
          limit = req.query.limit;
        } else {
          limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        }
      }
    }
    var options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: sort,
      lean: true
    };
    var qf = {};
    if (req.query.searchText) {
      qf = {
        $or: [{'companyName': {'$regex': req.query.searchText, '$options': '$i'}}],
        isDeleted: false,
        store: req.query.store
      }
    } else {
      qf = {isDeleted: false, store: req.query.store,};
    }
    if (!_.isUndefined(req.query.status)) {
      qf.status = req.query.status;
    }
    if (!_.isUndefined(req.query.employee)) {
      qf.employee = mongoose.Types.ObjectId(req.query.employee);
    }
    Meeting.paginate(qf, options).then(function (result) {
      var resultSet = result;
      return resultSet;
    })
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        reject({error: err, code: 500});
      });
  });
};

exports.get = function (req) {
  return new Promise(function (resolve, reject) {
    Meeting.findOneAsync({_id: req.body._id, isDeleted: false})
      .then(function (res) {
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

exports.getMeetingsForEmployee = function (req) {
  return new Promise(function (resolve, reject) {
    Meeting.find({_id: req.body.employee, isDeleted: false})
      .then(function (res) {
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

exports.add = function (req) {
  return new Promise(function (resolve, reject) {
    Meeting.createAsync(req.body)
      .then(function (res) {
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

exports.update = function (req) {
  return new Promise(function (resolve, reject) {
    var id = req.body._id;
    if (req.body._id) {
      delete req.body._id;
    }
    Meeting.findOneAndUpdateAsync({_id: Helper.isValidObjectId(id, req.body, 'Sales-Meeting')}, req.body, {new: true})
      .then(function (res) {
        resolve(Helper.filterObject(req.filterKeys, res));
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

exports.delete = function (req) {
  return new Promise(function (resolve, reject) {
    Meeting.findOneAndUpdateAsync({_id: Helper.isValidObjectId(req.body._id, req.body, 'Sales-Meeting')}, {$set: {isDeleted: true}}, {new: true})
      .then(function (res) {
        resolve(Helper.filterObject(req.filterKeys, res));
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};


exports.getCountsOfMeetings = function (req) {
  return new Promise(function (resolve, reject) {
    Meeting.aggregate([
      {"$project": {employee: 1, status: 1}},
      {"$match": {employee: mongoose.Types.ObjectId(req.body.employee || req.employeeId)}},
      {"$group": {_id: "$status", count: {$sum: 1}}}
    ]).then(function (res) {
      resolve(res);
    }).catch(function (err) {
      _logger.error(err);
      reject(err);
    });
  });
};