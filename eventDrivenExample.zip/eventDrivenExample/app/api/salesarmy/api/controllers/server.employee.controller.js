'use strict';
var Employee = require('../models/server.employee.model'),
  Helper = require('../../../app/api/shared/server.helper.js'),
  async = require('async'),
  TeamRelation = require('../models/server.team.relation.model'),
  BeatPlan = require('../models/server.beatplan.model'),
  Seller = require('../../../app/api/models/server.seller.model'),
  Meeting = require('../models/server.meeting.model'),
  Attendance = require('../models/server.attendance.model'),
  Notification = require('../../../app/api/shared/server.push.notification.helper'),
  AttendanceLog = require('../models/server.attendance.log.model');

exports.addAttendance = function (req) {
  return new Promise(function (resolve, reject) {
    Attendance.createAsync(req.body)
      .then(function (data) {
        req.body = data;
        Attendance.populate(data, 'distributor employee ', function (err, attendance) {
          var attendanceLog = {
            employee: attendance.employee,
            distributor: attendance.distributor,
            isStart: attendance.isStart
          };
          if (Helper.checkAddonBoolean(req.store, "SALES_NOTIFICATION")) {
            Notification.sendToManagersAndLeader(attendance.employee, "text", {
              title: "Attendance Alert",
              subtitle: attendance.employee.firstName + " " + attendance.employee.lastName + " has checked " + (attendance.isStart ? "in." : "out.")
            });
          }
          AttendanceLog.createAsync(attendanceLog)
            .then(function (data) {
            });
          delete attendance.employee;
          resolve(attendance);
        });
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

exports.getAll = function (req) {
  return new Promise(function (resolve, reject) {
    var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
    var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
    var sort = {};
    if (!_.isUndefined(req.query.sortColumn) && !_.isUndefined(req.query.sortOrder)) {
      sort[req.query.sortColumn] = req.query.sortOrder === 'desc' ? -1 : 1;
    } else {
      sort["createdAt"] = -1;
    }
    if (!_.isUndefined(req.query.limit)) {
      if (parseInt(req.query.limit) === -1) {
        limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      } else {
        if (parseInt(req.query.limit) !== -1 && req.query.limit !== undefined) {
          limit = req.query.limit;
        } else {
          limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        }
      }
    }
    var options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: sort,
      lean: true
    };
    var qf = {};
    if (req.query.searchText) {
      qf = {
        $or: [{
          'firstName': {
            '$regex': req.query.searchText,
            '$options': '$i'
          }
        }, {
          'lastName': {
            '$regex': req.query.searchText,
            '$options': '$i'
          }
        }, {
          'employeeNumber': {
            '$regex': req.query.searchText,
            '$options': '$i'
          }
        }, {'location': {'$regex': req.query.searchText, '$options': '$i'}}], isDeleted: false, store: req.query.store
      }
    } else {
      qf = {isDeleted: false, store: req.query.store, memberType: {$nin: ['manager']}};
    }
    Employee.paginate(qf, options).then(function (data) {
      resolve(data);
    })
      .catch(function (err) {
        reject({error: err, code: 500});
      });
  });
};

exports.getAllForTeam = function (req) {
  return new Promise(function (resolve, reject) {
    Employee.find({isDeleted: false, store: req.body.filters.store}, {
      firstName: 1,
      lastName: 1,
      email: 1,
      _id: 1
    })
      .then(function (res) {
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};
// Gets a single employee from the DB
exports.get = function (req) {
  return new Promise(function (resolve, reject) {
    // Employee.findOneAsync({employeeNumber: req.body.employeeNumber,store:req.store , isDeleted: false})
    Employee.findOneAsync({_id: req.body._id, isDeleted: false})
      .then(function (res) {
        if (res) {
          resolve(res);
        } else {
          resolve(false);
        }

      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

// Creates a new Employee in the DB
exports.add = function (req) {
  return new Promise(function (resolve, reject) {
    Employee.createAsync(req.body)
      .then(function (data) {
        req.body = data;
        data.setPassword(req.body.password);
        data.save(function (err, data) {
          if (err) {
            resolve({statusCode: 500, body: err});
          } else {
            resolve({statusCode: 200, body: data});
          }
        });
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

exports.addMultiple = function (req) {
  return new Promise(function (resolve, reject) {
    Employee.createAsync(req.body)
      .then(function (data) {
        var index = 0;
        async.each(data, function (employee, cb) {
          employee.setPassword(employee.password);
          employee.save(function (err, data) {
            index++;
            if (err) {
              cb(err);
            } else {
              cb()
            }

          })
        }, function (err) {
          if (err) {
            reject(err);
          } else {
            resolve(data)
          }
        })

      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

// Updates an existing employee in the DB
exports.update = function (req) {
  return new Promise(function (resolve, reject) {
    var id = req.body._id;
    if (req.body._id) {
      delete req.body._id;
    }
    var changedIMEI = false;
    var password = req.body && req.body.password && req.body.password.length > 0 ? req.body.password : undefined;
    if (password) delete req.body.password;
    var query = {$set: req.body};
    Employee.findOne({_id: id}, {'imei': 1}, {lean: true})
      .then(em => {
        if (em && em.imei && req.body.imei && em.imei != req.body.imei) {
          changedIMEI = true;
        }
        Employee.findOneAndUpdateAsync({_id: id}, query, {new: true})
          .then(function (data) {
            if (password) {
              data.setPassword(password);
              data.save().then(e => {
              }).catch(r => {
                console.log(r);
              });
            }
            if (data.toObject) data = data.toObject();
            data.changedIMEI = changedIMEI;
            resolve(data);
          })
          .catch(function (err) {
            _logger.error(err);
            reject(err);
          });
      }).catch(function (err) {
      _logger.error(err);
      reject(err);
    });
  });
};

//Deletes a employee from DB
exports.delete = function (req) {
  return new Promise(function (resolve, reject) {
    Employee.findOneAndUpdateAsync({_id: req.body._id}, {$set: {isDeleted: true}}, {new: true})
      .then(function (res) {
        TeamRelation.findOneAndUpdate({employee: req.body._id, isDeleted: false}, {$set: {isDeleted: true}})
          .then(rel => {

          });
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

exports.checkAvailability = function (req) {
  return new Promise(function (resolve) {
    Employee.findOneAsync({
      '$or': [{username: req.body.value}, {email: req.body.value}, {mobile: req.body.value}],
      isDeleted: false
    })
      .then(function (data) {
        if (data !== null) {
          resolve({field: req.body.field, available: false});
        } else {
          resolve({field: req.body.field, available: true});
        }
      });
  });
};

exports.getOtherDetails = function (req) {
  return new Promise(function (resolve, reject) {

    var tasks = [];
    var employeeDetails = {};
    var getBeatPlanCount = function (cb) {
      BeatPlan.find({employee: req.body.employeeId, isDeleted: false})
        .then(function (res) {
          if (res) {
            // resolve(res);
            employeeDetails.beatPlanCount = res.length;
            cb(null, employeeDetails)

          } else {
            resolve(false);
          }

        })
        .catch(function (err) {
          _logger.error(err);
          cb(err);
        });
    };
    tasks.push(getBeatPlanCount);

    var getMeetingCount = function (cb) {
      Meeting.find({employee: req.body.employeeId, isDeleted: false})
        .then(function (res) {
          if (res) {
            // resolve(res);
            employeeDetails.meetingCount = res.length;
            cb(null, employeeDetails)

          } else {
            resolve(false);
          }

        })
        .catch(function (err) {
          _logger.error(err);
          cb(error);
        });
    };
    tasks.push(getMeetingCount);


    async.parallel(tasks, function (err, results) {
      if (err) {
        _logger.error(err);
        reject(err);
      } else {
        resolve(results[0]);
      }
    });
  });
};

exports.getLiveLocation = function (req) {
  return new Promise(function (resolve, reject) {
    Employee.findOneAsync({_id: req.body._id, isDeleted: false})
      .then(function (res) {
        if (res) {
          resolve(res);
        } else {
          resolve(false);
        }

      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

exports.authenticate = function (req) {
  return new Promise(function (resolve, reject) {
    req.body = {
      credentials: req.body.credentials || req.body
    };
    var qu = {
      '$or': [{email: req.body.credentials.value, isDeleted: false},
        {'phone.number': req.body.credentials.value, isDeleted: false},
        {username: req.body.credentials.value, isDeleted: false}
      ],
      store: req.query.store
    };
    if (req.query.deviceId) {
      qu.imei = req.query.deviceId;
    }
    Employee.findOne(qu).then(function (seller) {
      if (!_.isNull(seller)) {
        handleAuthentication(seller);
      } else {
        Seller.findOne({
          '$or': [{email: req.body.credentials.value, isDeleted: false},
            {'phone.number': req.body.credentials.value, isDeleted: false},
            {username: req.body.credentials.value, isDeleted: false}
          ],
          store: req.query.store
        }).then(function (seller) {
          if (!_.isNull(seller) && seller._id == req.query.storeObj.owner._id) {
            handleAuthentication(seller);
          } else {
            resolve({
              status: 401,
              message: 'Authentication failed, Incorrect username or password.'
            });
          }
        });
      }
    });

    function handleAuthentication(seller) {
      var promise = Helper.handleAuthentication(req, seller, 'Sales-Employee', false, req.tokenExpiry);
      promise.then(dt => {
        dt.user.teams = [];
        if (dt && dt.user && dt.user._id) {
          var options = {
            page: 1,
            limit: parseInt(_CONFIG.MONGODB.MAX_DOCUMENTS),
            select: {'team': 1, 'isLeader': 1, 'isManager': 1},
            lean: true,
            populate: {
              path: 'team',
              select: 'name _id'
            }
          };
          TeamRelation.paginate({employee: dt.user._id, isDeleted: false}, options)
            .then(function (teams) {
              dt.user.teams = teams.docs;
              resolve(dt);
            }).catch(err => {
            console.log(err);
            resolve(dt)
          });
        } else {
          resolve(dt)
        }
      }).catch(err => {
        resolve(err);
      });
    }
  });
};

exports.authenticateApp = function (req) {
  return new Promise(function (resolve, reject) {
    if (req.query.deviceId) {
      var qu = {
        imei: req.query.deviceId,
        isDeleted: false
      };
      if (qu && qu.imei.length > 0) {
        if (qu.imei.indexOf("|") > -1) {
          qu = {
            imei: {
              "$in": qu.imei.split("|")
            },
            isDeleted: false
          }
        }
        Employee.findOne(qu).then(function (object) {
          if (!_.isNull(object)) {
            var token = object.getToken(req.query.hostname, req.tokenExpiry);
            let response = {};
            response.token = token;
            response.user = {};
            response.status = 200;
            if ("username" in object) response.user.username = object.username;
            if ("mobile" in object) response.user.mobile = object.mobile;
            if ("_id" in object) response.user.id = object._id;
            if ("_id" in object) response.user._id = object._id;
            if ("firstName" in object) response.user.firstName = object.firstName;
            if ("group" in object) response.user.firstName = object.firstName;
            if ("lastName" in object) response.user.lastName = object.lastName;
            if ("email" in object) response.user.email = object.email;
            if ("roles" in object) response.user.roles = object.roles;
            if ("chatAlert" in object) response.user.chatAlert = object.chatAlert;
            if ("gender" in object) response.user.gender = object.gender;
            if ("settings" in object) response.user.settings = object.settings;
            if (!_.isUndefined(object.image) && !_.isNull(object.image)) {
              response.user.photo = object.image.url;
            }
            if ("hr" in object) response.user.hr = object.hr;
            if ("homeLocation" in object) response.user.homeLocation = object.homeLocation;
            if ("currentLocation" in object) response.user.currentLocation = object.currentLocation;
            response.user.teams = [];
            if (response && response.user && response.user._id) {
              Employee.populate(object, {path: 'store', model: 'Store', select: 'mobileAppId package'})
                .then(em => {
                  response.user.app = em.store.mobileAppId;
                  var options = {
                    page: 1,
                    limit: parseInt(_CONFIG.MONGODB.MAX_DOCUMENTS),
                    select: {'team': 1, 'isLeader': 1, 'isManager': 1},
                    lean: true,
                    populate: {
                      path: 'team',
                      select: 'name _id'
                    }
                  };
                  if (req.query.device) {
                    Employee.findOneAndUpdate({_id: response.user._id}, {$set: {'phone.device': req.query.device}})
                      .then(s => {
                      })
                  }
                  TeamRelation.paginate({employee: response.user._id, isDeleted: false}, options)
                    .then(function (teams) {
                      response.user.teams = teams.docs;
                      resolve({result: response, store: em.store});
                    }).catch(err => {
                    console.log(err);
                    resolve({result: response, store: em.store});
                  });
                });
            } else {
              resolve({result:response})
            }
          } else {
            resolve({result:{
              status: 401,
              message: 'Authentication failed, Please contact System Administrator and provide them the IMEI mentioned below.'
            }});
          }
        }).catch(err => {
          console.log(err);
        });
      } else {
        resolve({result:{
          status: 401,
          message: 'Authentication failed, Please contact System Administrator and provide them the IMEI mentioned below.'
        }});
      }
    } else {
      resolve({result:{
        status: 401,
        message: 'Authentication failed, Please contact System Administrator and provide them the IMEI mentioned below.'
      }});
    }
  });
};
