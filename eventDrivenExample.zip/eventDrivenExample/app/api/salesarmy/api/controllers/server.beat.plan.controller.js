'use strict';
var BeatPlan = require('../models/server.beatplan.model'),
  Helper = require('../../../app/api/shared/server.helper.js'),
  _ = require('lodash');


exports.getAll = function (req) {
  return new Promise(function (resolve, reject) {
    var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
    var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
    var sort = {};
    if (!_.isUndefined(req.query.sortColumn) && !_.isUndefined(req.query.sortOrder)) {
      sort[req.query.sortColumn] = req.query.sortOrder === 'desc' ? -1 : 1;
    } else {
      sort["createdAt"] = -1;
    }
    if (!_.isUndefined(req.query.limit)) {
      if (parseInt(req.query.limit) === -1) {
        limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      } else {
        if (parseInt(req.query.limit) !== -1 && req.query.limit !== undefined) {
          limit = req.query.limit;
        } else {
          limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        }
      }
    }
    var options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: sort,
      lean: true
    };
    var qf = {};
    if (req.query.searchText) {
      qf = {
        $or: [{
          'userName': {
            '$regex': req.query.searchText,
            '$options': '$i'
          }
        }, {
          'mobile': {
            '$regex': req.query.searchText,
            '$options': '$i'
          }
        }, {
          'beatPlanNumber': {
            '$regex': req.query.searchText,
            '$options': '$i'
          }
        }, {'location': {'$regex': req.query.searchText, '$options': '$i'}}], isDeleted: false, store: req.query.store
      }
    } else {
      qf = {isDeleted: false, store: req.query.store};
    }
    BeatPlan.paginate(qf, options).then(function (result) {
      var resultSet = result;
      return resultSet;
    })
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        reject({error: err, code: 500});
      });
  });
};

// Gets a single beatPlan from the DB
exports.get = function (req) {
  return new Promise(function (resolve, reject) {
    // BeatPlan.findOneAsync({beatPlanNumber: req.body.beatPlanNumber,store:req.store , isDeleted: false})
    BeatPlan.findOneAsync({_id: req.body._id, isDeleted: false})
      .then(function (res) {
        if (res) {
          resolve(res);
        } else {
          resolve(false);
        }

      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

// Creates a new BeatPlan in the DB
exports.add = function (req) {
  return new Promise(function (resolve, reject) {
    BeatPlan.createAsync(req.body)
      .then(function (data) {
        req.body = data;

        data.setPassword(req.body.password);
        data.save(function (err, data) {
          if (err) {
            resolve({statusCode: 500, body: err});
          } else {
            resolve({statusCode: 200, body: data});
          }
        });
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

// Updates an existing beatPlan in the DB
exports.update = function (req) {
  return new Promise(function (resolve, reject) {
    var id = req.body._id;
    if (req.body._id) {
      delete req.body._id;
    }

    BeatPlan.findOneAsync({_id: id})
      .then(function (doc) {
        // var oldName = doc.name;
        var query = {$set: req.body};
        BeatPlan.findOneAndUpdateAsync({_id: id}, query, {new: true})
          .then(function (data) {
            resolve(Helper.filterObject(req.filterKeys, data));
          })
          .catch(function (err) {
            _logger.error(err);
            reject(err);
          });
      });
  });
};

//Deletes a beatPlan from DB
exports.delete = function (req) {
  return new Promise(function (resolve, reject) {
    BeatPlan.findOneAndUpdateAsync({_id: Helper.isValidObjectId(req.body._id, req.body, 'BeatPlan')}, {$set: {isDeleted: true}}, {new: true})
      .then(function (res) {
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};


exports.getByEmpId = function (req) {
  return new Promise(function (resolve, reject) {
    BeatPlan.findOneAsync({employee: req.body.employee || req.employeeId})
      .then(function (res) {
        if (res) resolve(res);
        else {
          BeatPlan.create({employee: req.body.employee || req.employeeId, store: req.store._id})
            .then(bp => {
              resolve(bp);
            });
        }
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};
