'use strict';
var Task = require('../models/server.task.model'),
  Helper = require('../../../app/api/shared/server.helper.js'),
  moment = require('moment');

exports.getAll = function (req) {
  return new Promise(function (resolve, reject) {
    var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
    var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
    var sort = {};
    if (!_.isUndefined(req.query.sortColumn) && !_.isUndefined(req.query.sortOrder)) {
      sort[req.query.sortColumn] = req.query.sortOrder === 'desc' ? -1 : 1;
    } else {
      sort["createdAt"] = -1;
    }
    if (!_.isUndefined(req.query.limit)) {
      if (parseInt(req.query.limit) === -1) {
        limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      } else {
        if (parseInt(req.query.limit) !== -1 && req.query.limit !== undefined) {
          limit = req.query.limit;
        } else {
          limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        }
      }
    }
    var options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: sort,
      lean: true
    };
    var qf = {};
    if (req.query.searchText) {
      qf = {
        $or: [{
          'firstName': {
            '$regex': req.query.searchText,
            '$options': '$i'
          }
        }, {
          'lastName': {
            '$regex': req.query.searchText,
            '$options': '$i'
          }
        }, {
          'taskNumber': {
            '$regex': req.query.searchText,
            '$options': '$i'
          }
        }, {'location': {'$regex': req.query.searchText, '$options': '$i'}}], isDeleted: false, store: req.query.store
      }
    } else {
      qf = {isDeleted: false, store: req.query.store};
    }
    Task.paginate(qf, options).then(function (result) {
      return result;
    }).then(function (data) {
      resolve(data);
    }).catch(function (err) {
      reject({error: err, code: 500});
    });
  });
};

// Gets a single task from the DB
exports.get = function (req) {
  return new Promise(function (resolve, reject) {
    Task.findOneAsync({_id: req.body._id, isDeleted: false})
      .then(function (res) {
        if (res) {
          resolve(res);
        } else {
          resolve(false);
        }
      }).catch(function (err) {
      _logger.error(err);
      reject(err);
    });
  });
};

// Creates a new Task in the DB
exports.add = function (req) {
  return new Promise(function (resolve, reject) {
    req.body.taskDate = moment(req.body.taskDate).format('DD-MM-YYYY');
    Task.createAsync(req.body)
      .then(function (data) {
        resolve(data);
      }).catch(function (err) {
      _logger.error(err);
      reject(err);
    });
  });
};

// Updates an existing task in the DB
exports.update = function (req) {
  return new Promise(function (resolve, reject) {
    var id = req.body._id;
    if (req.body._id) {
      delete req.body._id;
    }
    var query = {$set: req.body};
    Task.findOneAndUpdateAsync({_id: id}, query, {new: true})
      .then(function (data) {
        resolve(Helper.filterObject(req.filterKeys, data));
      }).catch(function (err) {
      _logger.error(err);
      reject(err);
    });
  });
};

//Deletes a task from DB
exports.delete = function (req) {
  return new Promise(function (resolve, reject) {
    Task.findOneAndUpdateAsync({_id: Helper.isValidObjectId(req.body._id, req.body, 'Task')}, {$set: {isDeleted: true}}, {new: true})
      .then(function (res) {
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};


exports.getTasksByDate = function (req) {
  return new Promise(function (resolve, reject) {
    Task.find({assignTo: {$in: [req.body.employee]}, taskDate: req.body.taskDate})
      .then(function (res) {
        if (res) {
          resolve(res);
        } else {
          reject({message: "No Data found."})
        }
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};



