'use strict';
var Distributor = require('../models/server.distributor.model'),
  Helper = require('../../../app/api/shared/server.helper.js'),
  _ = require('lodash');


exports.getAll = function (req) {
  return new Promise(function (resolve, reject) {
    var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
    var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
    var sort = {};
    if (!_.isUndefined(req.query.sortColumn) && !_.isUndefined(req.query.sortOrder)) {
      sort[req.query.sortColumn] = req.query.sortOrder === 'desc' ? -1 : 1;
    } else {
      sort["createdAt"] = -1;
    }
    if (!_.isUndefined(req.query.limit)) {
      if (parseInt(req.query.limit) === -1) {
        limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      } else {
        if (parseInt(req.query.limit) !== -1 && req.query.limit !== undefined) {
          limit = req.query.limit;
        } else {
          limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        }
      }
    }
    var options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: sort,
      lean: true
    };
    var qf = {};
    if (req.query.searchText) {
      qf = {
        $or: [{
          'name': {
            '$regex': req.query.searchText,
            '$options': '$i'
          }
        }, {'distributorId': {'$regex': req.query.searchText, '$options': '$i'}}],
        isDeleted: false,
        store: req.query.store,
        addedByEmployee: req.query.addedByEmployee || req.query.employee
      }
    } else {
      qf = {
        isDeleted: false,
        store: req.query.store,
        addedByEmployee: req.query.addedByEmployee || req.query.employee
      };
    }
    Distributor.paginate(qf, options)
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        reject({error: err, code: 500});
      });
  });
};

exports.getAllDistributors = function (req) {
  return new Promise(function (resolve, reject) {
    var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
    var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
    var sort = {};
    if (!_.isUndefined(req.query.sortColumn) && !_.isUndefined(req.query.sortOrder)) {
      sort[req.query.sortColumn] = req.query.sortOrder === 'desc' ? -1 : 1;
    } else {
      sort["createdAt"] = -1;
    }
    if (!_.isUndefined(req.query.limit)) {
      if (parseInt(req.query.limit) === -1) {
        limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      } else {
        if (parseInt(req.query.limit) !== -1 && req.query.limit !== undefined) {
          limit = req.query.limit;
        } else {
          limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        }
      }
    }
    var options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: sort,
      lean: true
    };
    var qf = {};
    if (req.query.searchText) {
      qf = {
        $or: [{
          'name': {
            '$regex': req.query.searchText,
            '$options': '$i'
          }
        }, {'distributorId': {'$regex': req.query.searchText, '$options': '$i'}}],
        isDeleted: false,
        store: req.query.store
      }
    } else {
      qf = {isDeleted: false, store: req.query.store};
      // qf = {isDeleted: false, store: req.query.store};
    }
    Distributor.paginate(qf, options)
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        reject({error: err, code: 500});
      });
  });
};


// Gets a single distributor from the DB
exports.get = function (req) {
  return new Promise(function (resolve, reject) {
    // Distributor.findOneAsync({distributorNumber: req.body.distributorNumber,store:req.store , isDeleted: false})
    Distributor.findOneAsync({_id: req.body._id, isDeleted: false})
      .then(function (res) {
        if (res) {
          resolve(res);
        } else {
          resolve(false);
        }

      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

// Creates a new Distributor in the DB
exports.add = function (req) {
  return new Promise(function (resolve, reject) {
    req.body.loc = {};
    req.body.loc.type = 'Point';
    req.body.loc.coordinates = [Number(req.body.latitude), Number(req.body.longitude)];
    Distributor.createAsync(req.body)
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

// Updates an existing distributor in the DB
exports.update = function (req) {
  return new Promise(function (resolve, reject) {
    var id = req.body._id;
    if (req.body._id) {
      delete req.body._id;
    }
    if (_.isUndefined(req.body.geoLocation) && !_.isEmpty(req.body.longitude) && !_.isEmpty(req.body.latitude)) {
      req.body.loc = {};
      req.body.loc.type = 'Point';
      req.body.loc.coordinates = [req.body.longitude, req.body.latitude]
    }
    var query = {$set: req.body};
    Distributor.findOneAndUpdateAsync({_id: id}, query, {new: true})
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

//Deletes a distributor from DB
exports.delete = function (req) {
  return new Promise(function (resolve, reject) {
    Distributor.findOneAndUpdateAsync({_id: Helper.isValidObjectId(req.body._id, req.body, 'Distributor')}, {$set: {isDeleted: true}}, {new: true})
      .then(function (res) {
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

exports.getNearBy = function (req) {
  return new Promise(function (resolve, reject) {
    Distributor.find({
      "loc": {
        $geoWithin: {
          $geometry: {
            type: "Polygon",
            coordinates: req.body.polygon
          }
        }
      },
      "isDeleted": false,
    })
      .then(function (res) {
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};


