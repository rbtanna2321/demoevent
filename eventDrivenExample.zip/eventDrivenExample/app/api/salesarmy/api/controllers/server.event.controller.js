'use strict';
var Event = require('../models/server.event.model'),
  Helper = require('../../../app/api/shared/server.helper.js'),
  _ = require('lodash');


exports.getAll = function (req) {
  return new Promise(function (resolve, reject) {
    var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
    var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
    var sort = {};
    if (!_.isUndefined(req.query.sortColumn) && !_.isUndefined(req.query.sortOrder)) {
      sort[req.query.sortColumn] = req.query.sortOrder === 'desc' ? -1 : 1;
    } else {
      sort["createdAt"] = -1;
    }
    if (!_.isUndefined(req.query.limit)) {
      if (parseInt(req.query.limit) === -1) {
        limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      } else {
        if (parseInt(req.query.limit) !== -1 && req.query.limit !== undefined) {
          limit = req.query.limit;
        } else {
          limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        }
      }
    }
    var options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: sort,
      lean: true
    };
    var qf = {};
    if (req.query.searchText) {
      qf = {
        $or: [{
          'eventId': {
            '$regex': req.query.searchText,
            '$options': '$i'
          }
        }, {'eventTitle': {'$regex': req.query.searchText, '$options': '$i'}}], isDeleted: false, store: req.query.store
      }
    } else {
      qf = {isDeleted: false, store: req.query.store};
    }
    Event.paginate(qf, options).then(function (result) {
      var resultSet = result;
      return resultSet;
    })
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        reject({error: err, code: 500});
      });
  });
};

// Gets a single event from the DB
exports.get = function (req) {
  return new Promise(function (resolve, reject) {
    Event.findOneAsync({_id: req.body._id, isDeleted: false})
      .then(function (res) {
        if (res) {
          resolve(res);
        } else {
          resolve(false);
        }

      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

// Creates a new Event in the DB
exports.add = function (req) {
  return new Promise(function (resolve, reject) {
    Event.createAsync(req.body)
      .then(function (data) {
        Event.populate(data, 'employee', function (err, event) {
          resolve(Helper.filterObject(req.filterKeys, event));
        });
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

// Updates an existing event in the DB
exports.update = function (req) {
  return new Promise(function (resolve, reject) {
    var id = req.body._id;
    if (req.body._id) {
      delete req.body._id;
    }

    Event.findOneAsync({_id: id})
      .then(function (doc) {
        // var oldName = doc.name;
        var query = {$set: req.body};
        Event.findOneAndUpdateAsync({_id: id}, query, {new: true})
          .then(function (data) {
            resolve(Helper.filterObject(req.filterKeys, data));

          })
          .catch(function (err) {
            _logger.error(err);
            reject(err);
          });
      });
  });
};

//Deletes a event from DB
exports.delete = function (req) {
  return new Promise(function (resolve, reject) {
    Event.findOneAndUpdateAsync({_id: Helper.isValidObjectId(req.body._id, req.body, 'Event')}, {$set: {isDeleted: true}}, {new: true})
      .then(function (res) {
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};
