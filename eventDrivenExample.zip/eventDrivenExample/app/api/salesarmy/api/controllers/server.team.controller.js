'use strict';
var Team = require('../models/server.team.model'),
  Employee = require('../models/server.employee.model'),
  TeamRelation = require('../models/server.team.relation.model'),
  async = require('async'),
  Helper = require('../../../app/api/shared/server.helper.js');

// Gets a list of Teams
exports.getAll = function (req) {
  return new Promise(function (resolve, reject) {
    var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
    var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
    var sort = {};
    if (!_.isUndefined(req.query.sortColumn) && !_.isUndefined(req.query.sortOrder)) {
      sort[req.query.sortColumn] = req.query.sortOrder === 'desc' ? -1 : 1;
    } else {
      sort["createdAt"] = -1;
    }
    if (!_.isUndefined(req.query.limit)) {
      if (parseInt(req.query.limit) === -1) {
        limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      } else {
        if (parseInt(req.query.limit) !== -1 && req.query.limit !== undefined) {
          limit = req.query.limit;
        } else {
          limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        }
      }
    }
    var options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: sort,
      lean: true
    };
    if (req.query.query) {
      var qf = {
        $or: [{'name': {'$regex': req.query.query, '$options': '$i'}}],
        isDeleted: false,
        store: req.query.store
      }
    } else {
      qf = {isDeleted: false, store: req.query.store};
    }
    Team.paginate(qf, options).then(function (result) {
      return result;
    })
      .then(function (data) {
        resolve(data);
      })
      .catch(function (error) {
        _logger.error(error);
        reject(error);
      });
  });
};


// Gets a single Team from the DB
exports.get = function (req) {
  return new Promise(function (resolve, reject) {
    Team.findOneAsync({_id: req.body._id, isDeleted: false})
      .then(function (res) {
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};


exports.getAllTeamOnly = function (req) {
  return new Promise(function (resolve, reject) {
    Team.find({isDeleted: false, store: req.body.filters.store, client: req.body.filters.client}, {name: 1, _id: 1})
      .then(function (res) {
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};
exports.getTeamFromEmployee = function (employeeId) {
  return new Promise(function (resolve, reject) {
    if (employeeId && employeeId.length > 0) {
      Team.findOne({employee: {$in: [employeeId]}, isDeleted: false})
        .then(function (res) {
          resolve(res);
        })
        .catch(function (err) {
          _logger.error(err);
          reject(err);
        });
    } else {
      reject({error: "Please provide employee Id"});
    }
  });
};

// Creates a new Team in the DB
exports.add = function (req) {
  return new Promise(function (resolve, reject) {
    Team.createAsync(req.body)
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

exports.addMultiple = function (req) {
  return new Promise(function (resolve, reject) {
    var teams = [];
    var index = 0;
    _.each(req.body, function (team) {
      var manager;
      var leader;
      const tasks = [
        function findManager(cb) {
          Employee.findOne({email: team.manager, isDeleted: false}).then(function (response) {
            manager = response._id;
            return cb(null, manager)
          })
        },
        function findLeader(data, cb1) {
          Employee.findOne({email: team.leader, isDeleted: false}).then(function (res2) {
            leader = res2._id;
            return cb1(null, leader)
          })
        }
      ];

      async.waterfall(tasks, (err, results) => {
        if (err) {
          return (err);
        }
        var teamObj = {
          manager: manager,
          leader: leader,
          name: team.name,
          about: team.about,
          store: team.store,
          client: team.client
        };

        Team.createAsync(teamObj)
          .then(function (data) {
            if (!_.isNull(data)) {
              Team.populate(data, 'manager leader client', function (err, teamData) {
                index++;
                teams.push(teamData);
                if (index == req.body.length) {
                  resolve(teams)
                }
              })
            }
          })
      })
    });
  });
};

// Updates an existing Team in the DB
exports.update = function (req) {
  return new Promise(function (resolve, reject) {
    var id = req.body._id;
    if (req.body._id) {
      delete req.body._id;
    }
    Team.findOneAndUpdateAsync({_id: id}, req.body, {new: true})
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });

};
exports.delete = function (req) {
  return new Promise(function (resolve, reject) {
    Team.findOneAndUpdateAsync({_id: Helper.isValidObjectId(req.body._id, req.body, 'Team')}, {$set: {isDeleted: true}}, {new: true})
      .then(function (res) {
        TeamRelation.updateMany({team: res._id}, {$set: {'isDeleted': true}}, {multi: true})
          .then(e => {
            resolve(res);
          });
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};


// exports.getTeamByLeader = function (req) {
//   return new Promise(function (resolve, reject) {
//     Team.findOneAsync({
//       _id: req.body.teamId,
//       isDeleted: false,
//       "$or": [{leader: req.body.leader}, {manager: req.body.leader}]
//     }, {leader: 1, manager: 1,employee:1})
//       .then(function (res) {
//             Employee.find({team:req.body.teamId, isDeleted: false},{_id:1,email:1,firstName:1,lastName:1,mobile:1,battery:1,nearestClient:1,address:1,lastUpdatedAt:1,currentLocation:1,empNumber:1})
//               .then(function (emps) {
//                 res.employee = emps;
//                 console.log("emp :",res)
//                 resolve(res);
//               })
//       })
//       .catch(function (err) {
//         _logger.error(err);
//         reject(err);
//       });
//   });
// };

exports.getTeamByLeader = function (req) {
  return new Promise(function (resolve, reject) {
    TeamRelation.findOne({team: req.body.teamId, isDeleted: false, employee: req.body.leader})
      .then(main => {
        var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
        var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        var sort = {};
        if (!_.isUndefined(req.query.sortColumn) && !_.isUndefined(req.query.sortOrder)) {
          sort[req.query.sortColumn] = req.query.sortOrder === 'desc' ? -1 : 1;
        } else {
          sort["createdAt"] = -1;
        }
        if (!_.isUndefined(req.query.limit)) {
          if (parseInt(req.query.limit) === -1) {
            limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
          } else {
            if (parseInt(req.query.limit) !== -1 && req.query.limit !== undefined) {
              limit = req.query.limit;
            } else {
              limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
            }
          }
        }
        var qf = {team: req.body.teamId, isDeleted: false, employee: {$nin: req.body.leader}};
        if (main.isLeader || main.isManager) {
          qf.isManager = false;
        }
        if(!main.isLeader && !main.isManager){
          limit=0;
        }
        var options = {
          page: parseInt(page),
          limit: parseInt(limit),
          select: {'employee': 1},
          lean: true,
          populate: {
            path: 'employee',
            select: '_id firstName lastName currentLocation homeLocation phone.number email battery batteryChargeStatus lastUpdatedAt profileColor settings'
          }
        };
        TeamRelation.paginate(qf, options)
          .then(relations => {
            var employees = _.map(relations.docs, function (relation) {
              return relation.employee;
            });
            var dataToReturn = {
              employee: employees,
              total: relations.total,
              limit: relations.limit,
              page: relations.page,
              pages: relations.pages
            };
            if(!main.isLeader && !main.isManager){
              dataToReturn.total = 0;
              dataToReturn.page = 0;
              dataToReturn.pages = 0;
            }
            if (parseInt(page) == 1) {
              var temp = [main.employee];
              dataToReturn.employee = temp.concat(employees);
              resolve(dataToReturn)
            } else {
              resolve(dataToReturn)
            }
          }).catch(err => {
          console.log(err);
        });
      });
  });
};

// this.getTeamByLeader({body:{
//   "leader":"5abe24982ee37d4353a79d18","teamId":"5abe23703491a54140181c95"
// },query:{page:1,limit:2}})

exports.getTeamByLoggedInUser = function (req) {
  return new Promise(function (resolve, reject) {
    var options = {
      page: 1,
      limit: parseInt(_CONFIG.MONGODB.MAX_DOCUMENTS),
      select: {'team': 1, 'isLeader': 1, 'isManager': 1},
      lean: true,
      populate: {
        path: 'team',
        select: 'name _id isDeleted'
      }
    };
    TeamRelation.paginate({employee: req.body._id, isDeleted: false}, options)
      .then(function (teams) {
        resolve(teams.docs);
      }).catch(err => {
      reject(err)
    });
  });
};