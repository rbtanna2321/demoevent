'use strict';
var Expiry = require('../models/server.bulk.product.model');

exports.getAll = function (req) {
  return new Promise(function (resolve, reject) {
    var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
    var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
    var sort = {};
    if (!_.isUndefined(req.query.sortColumn) && !_.isUndefined(req.query.sortOrder)) {
      sort[req.query.sortColumn] = req.query.sortOrder === 'desc' ? -1 : 1;
    } else {
      sort["createdAt"] = -1;
    }
    if (!_.isUndefined(req.query.limit)) {
      if (parseInt(req.query.limit) === -1) {
        limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      } else {
        if (parseInt(req.query.limit) !== -1 && req.query.limit !== undefined) {
          limit = req.query.limit;
        } else {
          limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        }
      }
    }
    var options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: sort,
      lean: true,
      populate: [{path: 'pictures', model: "File", select: "_id fileId store metadata url"}]
    };
    if (req.query.searchText && req.query.searchText != '***') {
      var qf = {
        'name': {'$regex': req.query.searchText.replace(/\*/g, ""), '$options': '$i'},
        isDeleted: false,
        store: req.query.store
      }
    } else {
      qf = {isDeleted: false, store: req.query.store};
    }
    Expiry.paginate(qf, options).then(function (result) {
      return result;
    })
      .then(function (data) {
        resolve(data);
      })
      .catch(function (error) {
        _logger.error(error);
        reject(error);
      });
  });
};

exports.getAllForIMEI = function (req) {
  return new Promise(function (resolve, reject) {
    var page = _.isUndefined(req.query.page) ? 1 : req.query.page;
    var limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
    var sort = {};
    if (!_.isUndefined(req.query.sortColumn) && !_.isUndefined(req.query.sortOrder)) {
      sort[req.query.sortColumn] = req.query.sortOrder === 'desc' ? -1 : 1;
    } else {
      sort["createdAt"] = -1;
    }
    if (!_.isUndefined(req.query.limit)) {
      if (parseInt(req.query.limit) === -1) {
        limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      } else {
        if (parseInt(req.query.limit) !== -1 && req.query.limit !== undefined) {
          limit = req.query.limit;
        } else {
          limit = _CONFIG.MONGODB.DEFAULT_LIMIT;
        }
      }
    }
    var options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: sort,
      lean: true,
      populate: [{path: 'pictures', model: "File", select: "_id fileId store metadata url"}]
    };
    if (req.query.query) {
      var qf = {
        $or: [{'name': {'$regex': req.query.query, '$options': '$i'}}],
        isDeleted: false,
        store: req.query.store
      }
    } else {
      qf = {"qty": {$gt: 0}, isDeleted: false, store: req.query.store};
    }
    Expiry.paginate(qf, options).then(function (result) {
      return result;
    })
      .then(function (data) {
        resolve(data);
      })
      .catch(function (error) {
        _logger.error(error);
        reject(error);
      });
  });
};

exports.get = function (req) {
  return new Promise(function (resolve, reject) {
    var options = {
      page: 1,
      limit: 1,
      lean: true,
      populate: [{path: 'pictures', model: "File", select: "_id fileId store metadata url"}]
    };
    var qf = {_id: req._id, isDeleted: false, store: req.store};
    if(req.multiple){
      options.limit = _CONFIG.MONGODB.MAX_DOCUMENTS;
      qf._id = {$in: req._id};
    }
    Expiry.paginate(qf, options)
      .then(function (data) {
        if(data.docs && data.docs.length > 0) {
          if(req.multiple){
            resolve(data.docs);
          } else {
            resolve(data.docs[0]);
          }
        } else {
          reject({message: "Product not found."})
        }
      })
      .catch(function (error) {
        _logger.error(error);
        reject(error);
      });
  });
};

exports.add = function (req) {
  return new Promise(function (resolve, reject) {
    Expiry.createAsync(req.body)
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

exports.deleteAndAddNew = function (req) {
  return new Promise(function (resolve, reject) {
    Expiry.deleteMany({store: req.store})
      .then(res => {
        Expiry.createAsync(req.body)
          .then(function (data) {
            resolve(data);
          })
          .catch(function (err) {
            _logger.error(err);
            reject(err);
          });
      });
  });
};

exports.update = function (req) {
  return new Promise(function (resolve, reject) {
    var id = req.body._id;
    if (req.body._id) {
      delete req.body._id;
    }
    Expiry.findOneAndUpdateAsync({_id: id}, req.body, {new: true})
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });

};

exports.updateSalesCount = function (req) {
  return new Promise(function (resolve, reject) {
    Expiry.findOneAndUpdateAsync({_id: req.body._id}, {
      $inc: {'qty': -req.body.sales.qty},
      $push: {'sales': req.body.sales}
    }, {new: true})
      .then(function (data) {
        resolve(data);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });

};

exports.delete = function (req) {
  return new Promise(function (resolve, reject) {
    Expiry.findOneAndUpdateAsync({_id: req.body._id}, {$set: {isDeleted: true}}, {new: true})
      .then(function (res) {
        resolve(res);
      })
      .catch(function (err) {
        _logger.error(err);
        reject(err);
      });
  });
};

