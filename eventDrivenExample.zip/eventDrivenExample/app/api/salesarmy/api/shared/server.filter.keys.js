module.exports = {
  "feed": {
    "add": {
      "seller": {
        "hasAccess": true,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      },
      "guest": {
        "hasAccess": false,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      },
      "admin": {
        "hasAccess": true,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      },
      "manager": {
        "hasAccess": true,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      },
      "customer": {
        "hasAccess": false,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      }
    },
    "view": {
      "seller": {
        "hasAccess": true,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      },
      "guest": {
        "hasAccess": true,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      },
      "admin": {
        "hasAccess": true,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      },
      "manager": {
        "hasAccess": true,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      }
    },
    "update": {
      "seller": {
        "hasAccess": true,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      },
      "guest": {
        "hasAccess": false,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      },
      "admin": {
        "hasAccess": true,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      },
      "manager": {
        "hasAccess": true,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      }
    },
    "delete": {
      "seller": {
        "hasAccess": true,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      },
      "guest": {
        "hasAccess": false,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      },
      "admin": {
        "hasAccess": true,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      },
      "manager": {
        "hasAccess": true,
        "keys": [
          "_id",
          "type",
          "customer",
          "action",
          "user",
          "entity",
          "store"
        ]
      }
    }
  }
};