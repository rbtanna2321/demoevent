'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var hotelRoomSchema = new Schema({
  name: String,
  salePrice: Number,
  listPrice: Number,
  capacity: Number,
  maxCapacity: Number,
  unitNumber: Number,
  breakfastIncluded:  {type: Boolean, default: false},
  images: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateFile'
  }],
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  employee: {
    type: mongoose.Schema.ObjectId,
    ref: 'Sales-Employee'
  },
  hotel: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Hotel'
  },
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
hotelRoomSchema.plugin(autopopulate);
hotelRoomSchema.plugin(Paginate);
hotelRoomSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-HotelRoom', hotelRoomSchema);