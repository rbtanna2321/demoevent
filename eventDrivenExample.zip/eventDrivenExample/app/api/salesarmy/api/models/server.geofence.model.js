'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps;

var StoreLocationSchema = new Schema({
  name: {type: String},
  location: {
    type: {type: String, default: "Point"},
    coordinates: []
  },
  radius: Number,
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});

StoreLocationSchema.plugin(autopopulate);
StoreLocationSchema.plugin(SimpleTimestamps);
StoreLocationSchema.plugin(Paginate);
StoreLocationSchema.index({ "location": "2dsphere" });
module.exports = mongoose.model('Sales-Geofence', StoreLocationSchema);