'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var visitorSchema = new Schema({
    unitNumber: String,
    name: String,
    mobile: String,
    information: Object,
    store: {
      type: mongoose.Schema.ObjectId,
      ref: 'Store',
    },
    file: {
      type: mongoose.Schema.ObjectId,
      ref: 'PrivateFile',
      autopopulate: true
    },
    employee: {
      type: mongoose.Schema.ObjectId,
      ref: 'Sales-Employee',
      autopopulate: true
    },
    out: Date,
    isDeleted: {type: Boolean, default: false}
  },
  {timestamps: true});
visitorSchema.plugin(autopopulate);
visitorSchema.plugin(Paginate);
visitorSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Visitor', visitorSchema);