'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps;

var StoreLocationSchema = new Schema({
  name: {type: String},
  geometry: {type: {type: String, default: 'Point'}, coordinates: []},
  properties: {
    phoneFormatted: {type: String},
    phone: {type: String},
    address: {type: String},
    city: {type: String},
    country: {type: String},
    postalCode: {type: String},
    state: {type: String},
    email: {type: String}
  },
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});


StoreLocationSchema.plugin(autopopulate);
StoreLocationSchema.plugin(SimpleTimestamps);
StoreLocationSchema.plugin(Paginate);
module.exports = mongoose.model('StoreLocations', StoreLocationSchema);