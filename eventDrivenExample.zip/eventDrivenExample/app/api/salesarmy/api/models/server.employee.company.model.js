'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  Paginate = require('./paginate-plugin');

var EmployeeCompanySchema = new Schema({
  workingHours: [
    {
      dayIndex: Number,
      startTime: String,
      endTime: String,
      isActive: {type: Boolean, default: false},
      timeOutList: [{
        startTime: String,
        endTime: String
      }]
    }],
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  categories: [String],
  name: String,
  address: String,
  position: {type: {type: String}, coordinates: []},
  rating: {type: Number, default: 0},
  totalFeedback: {type: Number, default: 0},
  totalEmployees: {type: Number, default: 0},
  prime: {
    activated: {type: Boolean, default: false},
    verified: {type: Boolean, default: false},
    waitTime: {type: Number, default: 0}
  },
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee'
  },
  pictures: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateFile'
  }],
  directBookingToOwner: {type: Boolean, default: true},
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});

EmployeeCompanySchema.plugin(SimpleTimestamps);
EmployeeCompanySchema.plugin(autopopulate);
EmployeeCompanySchema.plugin(Paginate);

module.exports = mongoose.model('Sales-EmployeeCompany', EmployeeCompanySchema);