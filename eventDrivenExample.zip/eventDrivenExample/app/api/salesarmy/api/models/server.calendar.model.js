'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var calendarSchema = new Schema({
  companyName: String,
  contactPerson: {
    name: String,
    phoneNumber: String
  },
  location: {
    type: {type: String},
    coordinates: []
  },
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: true
  },
  address: String,
  start: Date,
  end: Date,
  status: String,
  remarks: String,
  title: String,
  color: String,
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});


calendarSchema.plugin(autopopulate);
calendarSchema.plugin(Paginate);
calendarSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Calendar', calendarSchema);