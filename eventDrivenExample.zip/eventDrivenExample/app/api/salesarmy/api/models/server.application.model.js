'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var applicationSchema = new Schema({
  image: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateFile'
  },
  name: String,
  packageId: String,
  genre: String,
  url: String,
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
applicationSchema.plugin(autopopulate);
applicationSchema.plugin(Paginate);
applicationSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Application', applicationSchema);