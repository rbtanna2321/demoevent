'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var taskSchema = new Schema({
  taskId: {
    type: String,
    default: function () {
      var prefix = "TSK-";
      var uniqueId = prefix ? prefix + Math.floor(Date.now()) : Math.floor(Date.now()) + '';
      return uniqueId.toString().toUpperCase();
    }
  },
  title: String,
  description: String,
  status: String,
  taskDate: String,
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  addedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: false
  },
  assignTo: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: true
  }],

  teamId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Team',
    autopopulate: false
  },
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
taskSchema.plugin(autopopulate);
taskSchema.plugin(Paginate);
taskSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Task', taskSchema);