'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var eventSchema = new Schema({
  eventId: {
    type: String, default: function () {
      var prefix = "EVT-";
      var uniqueId = prefix ? prefix + Math.floor(Date.now()) : Math.floor(Date.now()) + '';
      return uniqueId.toString().toUpperCase();
    }
  },
  eventTitle: String,
  latitude: Number,
  longitude: Number,
  eventStartDate: Date,
  eventEndDate: Date,
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: true
  },
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
eventSchema.plugin(autopopulate);
eventSchema.plugin(Paginate);
eventSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Event', eventSchema);