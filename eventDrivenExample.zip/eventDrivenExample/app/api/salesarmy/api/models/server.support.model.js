/**
 * Created by Priyanka on 16/2/2016.
 */
'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps;

var SalesSupportSchema = new Schema({
  type: {type: String},
  subject: {type: String},
  isSent: {type: Boolean, default: false}, //To display in sent box
  isStarred: {type: Boolean, default: false}, //To display in starred box
  isSpam: {type: Boolean, default: false}, //To display in spam box
  priority: {type: Number, default: 0}, //To display in spam box
  markAsClosed: {type: Boolean, default: false},
  customer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Customer',
    autopopulate: true
  },
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Product',
    autopopulate: true
  },
  order: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Order',
    autopopulate: true
  },
  body: {type: String},
  images: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'File',
    autopopulate: true
  }],
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  isDeleted: {type: Boolean, default: false}
});

SalesSupportSchema.plugin(autopopulate);
SalesSupportSchema.plugin(SimpleTimestamps);
SalesSupportSchema.plugin(Paginate);

module.exports = mongoose.model('Sales-Support', SalesSupportSchema);

