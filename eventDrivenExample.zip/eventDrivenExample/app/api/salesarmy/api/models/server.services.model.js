'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var ServiceSchema = new Schema({
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  attachments: [{
    type: mongoose.Schema.ObjectId,
    ref: 'File',
  }],
  image: {
    type: mongoose.Schema.ObjectId,
    ref: 'File',
  },
  page: {
    type: mongoose.Schema.ObjectId,
    ref: 'Pages',
  },
  name: String,
  description: String,
  color: String,
  priority: {type: Number, default: 0},
  isOnline: {type: Boolean, default: true},
  isFeatured: {type: Boolean, default: false},
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});


ServiceSchema.plugin(autopopulate);
ServiceSchema.plugin(Paginate);
ServiceSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Service', ServiceSchema);