'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var attendanceSchema = new Schema({

  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: true
  },
  distributor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Distributor',
    autopopulate: true
  },
  image: {
    type: mongoose.Schema.Types.ObjectId,
    ref : 'PrivateFile',
    autopopulate: true
  },
  latitude : String,
  longitude : String,
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  isStart: {type: Boolean, default: true},
  isDeleted: {type: Boolean, default: false},
  isActive: {type: Boolean, default: false}
}, {
  timestamps: true
});
attendanceSchema.plugin(autopopulate);
attendanceSchema.plugin(Paginate);
attendanceSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Attendance', attendanceSchema);