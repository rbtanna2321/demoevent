'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  Paginate = require('../paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps;

var RequestSchema = new Schema({
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Employee'
  },
  file: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateFile'
  },
  fileType: String,
  isPending: {type: Boolean, default: true},
  isApproved: {type: Boolean, default: false},
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});

RequestSchema.plugin(autopopulate);
RequestSchema.plugin(SimpleTimestamps);
RequestSchema.plugin(Paginate);

module.exports = mongoose.model('Sales-KYCRequest', RequestSchema);