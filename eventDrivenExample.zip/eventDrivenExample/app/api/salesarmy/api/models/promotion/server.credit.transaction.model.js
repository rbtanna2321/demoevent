'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  Paginate = require('../paginate-plugin');

var CreditTransactionSchema = new Schema({
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee'
  },
  amount: Number,
  type: String,
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});

CreditTransactionSchema.plugin(SimpleTimestamps);
CreditTransactionSchema.plugin(autopopulate);
CreditTransactionSchema.plugin(Paginate);

module.exports = mongoose.model('Sales-CreditTransaction', CreditTransactionSchema);