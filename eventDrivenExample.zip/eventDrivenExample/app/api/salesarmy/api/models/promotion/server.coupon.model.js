'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  Paginate = require('../paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps;

var CouponSchema = new Schema({
  couponId: {
    type: String, default: function () {
      var prefix = "";
      var uniqueId = prefix + Math.floor(Date.now());
      return uniqueId.toString().toUpperCase();
    }
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Employee'
  },
  vendor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Employee'
  },
  previousCouponNumber: {type: Number, default: 0},
  couponNumber: {type: Number, default: 0},
  autoActivation : {type: Boolean, default: false},
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  isDeleted: {type: Boolean, default: false}
});

CouponSchema.plugin(autopopulate);
CouponSchema.plugin(SimpleTimestamps);
CouponSchema.plugin(Paginate);

module.exports = mongoose.model('Sales-Coupon', CouponSchema);