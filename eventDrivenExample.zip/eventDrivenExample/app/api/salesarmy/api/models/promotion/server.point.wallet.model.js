'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  Paginate = require('../paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps;

var PointWalletSchema = new Schema({
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Employee'
  },
  couponNumber: Number,
  typeOfWallet: String,
  withdrawal: {type: Number, default: 0},
  value: {type: Number, default: 0},
  hidden: {type: Number, default: 0},
  pending: {type: Number, default: 0},
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  isDeleted: {type: Boolean, default: false}
});

PointWalletSchema.plugin(autopopulate);
PointWalletSchema.plugin(SimpleTimestamps);
PointWalletSchema.plugin(Paginate);

module.exports = mongoose.model('Sales-PointWallet', PointWalletSchema);