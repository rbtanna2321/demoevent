'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('../paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var expenseSchema = new Schema({
  minimumReference : {type:Number,default:0},
  maximumReference : {type:Number,default:0},
  designation: String,
  rewardLimit: Number,
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
expenseSchema.plugin(autopopulate);
expenseSchema.plugin(Paginate);
expenseSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-PromoterDesignation', expenseSchema);