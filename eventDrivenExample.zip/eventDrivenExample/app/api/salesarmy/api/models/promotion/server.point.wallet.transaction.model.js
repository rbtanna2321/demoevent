'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  Paginate = require('../paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps;

var PointWalletTransactionSchema = new Schema({
  purchaser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Employee'
  },
  receiver: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Employee'
  },
  coupon: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Coupon'
  },
  typeOfWallet: String,
  amount: {type: Number, default: 0},
  hiddenAmount: {type: Number, default: 0},
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  isDeleted: {type: Boolean, default: false}
});

PointWalletTransactionSchema.plugin(autopopulate);
PointWalletTransactionSchema.plugin(SimpleTimestamps);
PointWalletTransactionSchema.plugin(Paginate);

module.exports = mongoose.model('Sales-PointWalletTransaction', PointWalletTransactionSchema);