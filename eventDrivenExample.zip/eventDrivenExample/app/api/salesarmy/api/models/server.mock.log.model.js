'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var mockLogSchema = new Schema({
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: false
  },
  date: Date,
  isInUse: Boolean,
  packages: [String],
  location: {
    latitude: {type: Number, default: 0},
    longitude: {type: Number, default: 0},
    address: String
  },
  isDeleted: {type: Boolean, default: false},
}, {
  timestamps: true
});
mockLogSchema.plugin(autopopulate);
mockLogSchema.plugin(Paginate);
mockLogSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Report-Mock', mockLogSchema);