/**
 * Created by Priyanka on 16/2/2016.
 */
'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps;

var SalesSupportSchema = new Schema({
  ticket: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Support'
  },
  message: {type: String},
  sentAt: {type: Date},
  model: {type: String},
  from: {
    type: mongoose.Schema.Types.ObjectId,
    refPath: "model"
  },
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  pictures: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'File'
  }],
  isDeleted: {type: Boolean, default: false}
});

SalesSupportSchema.plugin(autopopulate);
SalesSupportSchema.plugin(SimpleTimestamps);
SalesSupportSchema.plugin(Paginate);

module.exports = mongoose.model('Sales-SupportMessage', SalesSupportSchema);

