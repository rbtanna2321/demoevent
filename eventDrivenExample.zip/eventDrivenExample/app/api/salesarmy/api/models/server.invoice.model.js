'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var invoiceSchema = new Schema({

  client: {
    type: mongoose.Schema.ObjectId,
    ref: 'Sales-Distributor'
  },
  invoiceNumber: String,
  issueDate: {type: Date, default: Date.now},
  dueDate: Date,
  notes: String,
  link: {
    type: mongoose.Schema.ObjectId,
    ref: 'paymentLinks'
  },
  items: [{

    description: String,
    quantity: Number,
    unitPrice: Number,
    amount: Number,
  }],
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store'
  },
  employee: {
    type: mongoose.Schema.ObjectId,
    ref: 'Sales-Employee'
  },
  total: {type: Number, default: 0},
  isDeleted: {type: Boolean, default: false},
}, {
  timestamps: true
});
invoiceSchema.plugin(autopopulate);
invoiceSchema.plugin(SimpleTimestamps);
invoiceSchema.plugin(Paginate);
module.exports = mongoose.model('Sales-Invoice', invoiceSchema);