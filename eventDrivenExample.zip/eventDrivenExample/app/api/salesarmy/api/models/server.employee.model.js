'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  uuid = require('node-uuid'),
  crypto = require('crypto'),
  jwt = require('jsonwebtoken'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  Paginate = require('./paginate-plugin');

var EmployeeSchema = new Schema({
  type: {
    type: String,
    trim: true,
    default: 'basic',
    enum: ['basic', 'starter', 'small-scale', 'medium-scale', 'pro', 'custom']
  },
  salt: {type: String, default: uuid.v1},
  email: {type: String, lowercase: true},
  username: {type: String},
  password: {type: String},
  roles: [{
    type: String,
    enum: ["owner", "employee", "store", "mlm-master", "mlm", "sales", "support", "service", "hr"]
  }],
  invitationId: {type: String},
  firstName: String,
  lastName: String,
  gender: {type: String, enum: ['male', 'female']},
  dob: {type: Date},
  phone: {
    type: {type: String, enum: ['mobile', 'landline']},
    number: {type: String},
    device: {
      version: String,
      manufacturer: String,
      model: String,
      os: String
    }
  },
  settings: {
    gps: Boolean,
    wifi: Boolean,
    carrier: Boolean
  },
  isVerified: {type: Boolean, default: false},
  lastActiveAt: {type: Date, default: Date.now},
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  image: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'File',
    autopopulate: true
  },
  addresses: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Address',
    autopopulate: true
  }],
  isActive: {type: Boolean, default: true},
  pwdRecoveryId: {type: String},
  chatAlert: {type: Boolean, default: false},
  isDeleted: {type: Boolean, default: false},
  //salesarmy
  currentLocation: {
    latitude: {type: Number, default: 0},
    longitude: {type: Number, default: 0},
    address: String
  },
  homeLocation: {
    latitude: {type: Number, default: 0},
    longitude: {type: Number, default: 0},
    address: String,
  },
  profileColor: String,
  city: {type: String, default: ''},
  state: {type: String, default: ''},
  pincode: {type: String, default: ''},
  battery: Number,
  batteryChargeStatus: Boolean,
  lastUpdatedAt: Date,
  imei: String,
  hr: {
    leaves: [{typeOfLeave: String, available: {type: Number, default: 0}, total: {type: Number, default: 0}}]
  },
  mlm: {
    designation: {
      name: String,
      limit: {type: Number, default: 0}
    },
    currentCoupon: {type: Number, default: 0},
    isActiveEmployee: {type: Boolean, default: false},
    slotsFilled: {type: Number, default: 0},
    activatedSlots: {type: Number, default: 0},
    activatedFirstSlots: {type: Number, default: 0},
    credit: {type: Number, default: 0},
    kyc: {
      data: {type: Object, default: {}},
      media: [
        {
          file: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'PrivateFile',
            autopopulate: true
          },
          fileType: String,
          isApproved: {type: Boolean}
        }
      ]
    },
    referralCode: {
      type: String, default: function () {
        var prefix = "";
        var uniqueId = prefix + Math.floor(Date.now());
        return uniqueId.toString().toUpperCase();
      }
    }
  }
}, {
  timestamps: true
});

var hash = function (passwd, salt) {
  return crypto.createHmac('sha256', salt).update(passwd).digest('hex');
};

EmployeeSchema.methods.setPassword = function (passwordString) {
  this.password = hash(passwordString, this.salt);
};

EmployeeSchema.methods.isValidPassword = function (passwordString) {
  return this.password === hash(passwordString, this.salt);
};

EmployeeSchema.methods.getToken = function (hostname, forever) {
  var expiry = _CONFIG.token.expiry;
  if (forever) expiry = '5y';
  return jwt.sign({data: this}, _CONFIG.secret.seller.key + hostname, {
    expiresIn: expiry
  });
};

EmployeeSchema.methods.getAppToken = function (hostname, forever) {
  var expiry = _CONFIG.token.expiry;
  if (forever) expiry = '5y';
  return jwt.sign({data: this}, _CONFIG.secret.seller.key + hostname, {
    expiresIn: expiry
  });
};

EmployeeSchema.plugin(SimpleTimestamps);
EmployeeSchema.plugin(autopopulate);
EmployeeSchema.plugin(Paginate);

module.exports = mongoose.model('Sales-Employee', EmployeeSchema);