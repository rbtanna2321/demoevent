'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var quizBatchSchema = new Schema({

  quizBatchId: {
    type: String, default: function () {
      var prefix = "QB-";
      var uniqueId = prefix ? prefix + Math.floor(Date.now()) : Math.floor(Date.now()) + '';
      return uniqueId.toString().toUpperCase();
    }
  },
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },

  participants: [{
    number: String,
    isCompleted: {type: Boolean, default: false}
  }],
  quiz: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'quiz',
    autopopulate: true
  },
  isDeleted: {type: Boolean, default: false},
  isActive: {type: Boolean, default: false}
}, {
  timestamps: true
});
quizBatchSchema.plugin(autopopulate);
quizBatchSchema.plugin(Paginate);
quizBatchSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-QuizBatch', quizBatchSchema);