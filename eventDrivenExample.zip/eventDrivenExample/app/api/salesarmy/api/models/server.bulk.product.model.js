'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var ExpirySchema = new Schema({
  name: String,
  sku: String,
  qty: Number,
  price: Number,
  description: String,
  sales: [{
    salesperson: {
      type: mongoose.Schema.ObjectId,
      ref: 'Sales-Employee',
      autopopulate: true
    },
    company: String,
    qty: Number,
    date: {type: Date, default: Date.now}
  }],
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  pictures: [{
    type: mongoose.Schema.ObjectId,
    ref: 'File',
  }],
  score: {type: Number, default: 0},
  employee: {
    type: mongoose.Schema.ObjectId,
    ref: 'Sales-Employee'
  },
  status: String,
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
ExpirySchema.plugin(autopopulate);
ExpirySchema.plugin(Paginate);
ExpirySchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Product', ExpirySchema);