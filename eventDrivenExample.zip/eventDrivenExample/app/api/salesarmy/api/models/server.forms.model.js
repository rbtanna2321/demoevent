'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  slug = require('mongoose-slug-updater'),
  autopopulate = require('mongoose-autopopulate');

var formsSchema = new Schema({
  name: String,
  slug: {type: String, slug: "name", uniqueGroupSlug: ['store', 'isDeleted'], index: true},
  description: String,
  subTitle: String,
  title: String,
  duration: Number,
  sections: [{
    title: String,
    questions: [{
      type: mongoose.Schema.ObjectId,
      ref: 'ProductQuestion',
    }],
    conditions: [{
      question: {
        type: mongoose.Schema.ObjectId,
        ref: 'ProductQuestion',
      },
      value: String,
      state: {type: String, enum: ["equal", "greater", "lower", "greater-equal", "lower-equal"]},
      show: [{
        type: mongoose.Schema.ObjectId,
        ref: 'ProductQuestion',
      }],
      hide: [{
        type: mongoose.Schema.ObjectId,
        ref: 'ProductQuestion',
      }]
    }],
  }],
  conditions: [{
    question: {
      type: mongoose.Schema.ObjectId,
      ref: 'ProductQuestion',
    },
    value: String,
    state: {type: String, enum: ["equal", "greater", "lower", "greater-equal", "lower-equal"]},
    show: [{
      type: mongoose.Schema.ObjectId,
      ref: 'ProductQuestion',
    }],
    hide: [{
      type: mongoose.Schema.ObjectId,
      ref: 'ProductQuestion',
    }]
  }],
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  isDeleted: {type: Boolean, default: false},
  isActive: {type: Boolean, default: false}
}, {
  timestamps: true
});
formsSchema.plugin(autopopulate);
formsSchema.plugin(SimpleTimestamps);
formsSchema.plugin(Paginate);
formsSchema.plugin(slug);
module.exports = mongoose.model('Sales-Forms', formsSchema);