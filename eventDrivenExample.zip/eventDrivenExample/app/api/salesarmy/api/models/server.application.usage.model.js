'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var applicationSchema = new Schema({
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee'
  },
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  applications: [{
    application: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Sales-Application'
    },
    time: {type: Number, default: 0},
    launchCount: {type: Number, default: 0}
  }],
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
applicationSchema.plugin(autopopulate);
applicationSchema.plugin(Paginate);
applicationSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-ApplicationUsage', applicationSchema);