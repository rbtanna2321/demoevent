'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var distributorSchema = new Schema({
  distributorId: {
    type: String, default: function () {
      var prefix = "DT-";
      var uniqueId = prefix ? prefix + Math.floor(Date.now()) : Math.floor(Date.now()) + '';
      return uniqueId.toString().toUpperCase();
    }
  },
  name: String,
  email: String,
  mobile: String,
  description: String,
  address: {
    address1: String,
    address2: String,
    city: String,
    state: String,
    country: String,
    pincode: String,
  },
  loc: {type: {type: String, default: "Point"}, coordinates: []},
  latitude: String,
  longitude: String,
  addedByEmployee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: {select: '_id firstName lastName'}
  },
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
distributorSchema.plugin(autopopulate);
distributorSchema.plugin(Paginate);
distributorSchema.plugin(SimpleTimestamps);
distributorSchema.index({"loc": "2dsphere"});
module.exports = mongoose.model('Sales-Distributor', distributorSchema);