'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var attendanceSchema = new Schema({

  batch: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'QuizBatch',
    autopopulate: true
  },
  participant: String,
  quizQuestions: [
    {
      question: String,
      answer: String,
      isCorrect: Boolean
    }
  ],
  image: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'File',
    autopopulate: true
  },
  imgBuffer: String,
  latitude: String,
  longitude: String,
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  isDeleted: {type: Boolean, default: false},
  isActive: {type: Boolean, default: false}
}, {
  timestamps: true
});
attendanceSchema.plugin(autopopulate);
attendanceSchema.plugin(SimpleTimestamps);
attendanceSchema.plugin(Paginate);
module.exports = mongoose.model('Sales-QuizResult', attendanceSchema);