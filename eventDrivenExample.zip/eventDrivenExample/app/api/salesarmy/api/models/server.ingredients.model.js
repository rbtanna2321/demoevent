'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var ingredientSchema = new Schema({
  images: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateFile'
  }],
  attributes : [{
    name: String,
    value: String
  }],
  name: String,
  description: String,
  nutritionFact: String,
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
ingredientSchema.plugin(autopopulate);
ingredientSchema.plugin(Paginate);
ingredientSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Ingredient', ingredientSchema);