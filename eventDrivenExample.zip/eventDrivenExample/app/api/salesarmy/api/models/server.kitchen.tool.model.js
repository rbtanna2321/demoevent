'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var kitchenToolSchema = new Schema({
  images: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateFile'
  }],
  attributes : [{
    name: String,
    value: String
  }],
  name: String,
  size: String,
  description: String,
  isDeleted: {type: Boolean, default: false},
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
}, {
  timestamps: true
});
kitchenToolSchema.plugin(autopopulate);
kitchenToolSchema.plugin(Paginate);
kitchenToolSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-KitchenTool', kitchenToolSchema);