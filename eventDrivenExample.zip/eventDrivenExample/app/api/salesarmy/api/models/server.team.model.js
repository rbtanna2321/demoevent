'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var teamSchema = new Schema({
  teamId: {
    type: String,
    default: function () {
      var prefix = "TM-";
      var uniqueId = prefix ? prefix + Math.floor(Date.now()) : Math.floor(Date.now()) + '';
      return uniqueId.toString().toUpperCase();
    }
  },
  name: String,
  about: String,
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  isDeleted: {type: Boolean, default: false},
  isActive: {type: Boolean, default: false}
}, {
  timestamps: true
});
teamSchema.plugin(autopopulate);
teamSchema.plugin(Paginate);
teamSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Team', teamSchema);