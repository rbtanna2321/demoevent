'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var recipeSchema = new Schema({
  images: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateFile'
  }],
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  video: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateFile'
  },
  shortVideo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateFile'
  },
  duration: Number,
  caloriesPerServing: Number,
  ingredients: [{
    ingredient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Sales-Ingredient'
    },
    quantity: Number,
    unit: String
  }],
  tools: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-KitchenTool'
  }],
  attributes: [{
    name: String,
    value: String
  }],
  steps: [{
    name: String,
    description: String,
    image: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'PrivateFile'
    }
  }],
  name: String,
  tags: [String],
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
recipeSchema.plugin(autopopulate);
recipeSchema.plugin(Paginate);
recipeSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Recipe', recipeSchema);