'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  autopopulate = require('mongoose-autopopulate');

var meetingsSchema = new Schema({

  companyName: String,
  contactPerson: {
    name: String,
    phoneNumber: String
  },
  location: {
    type: {type: String},
    coordinates: []
  },

  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: true
  },
  address: String,
  time: Date,
  status: String,
  remarks: String,
  postponeTime: Date,
  isDeleted: {type: Boolean, default: false},
  isActive: {type: Boolean, default: false}
}, {
  timestamps: true
});


meetingsSchema.plugin(autopopulate);
meetingsSchema.plugin(Paginate);
module.exports = mongoose.model('Sales-Meeting', meetingsSchema);