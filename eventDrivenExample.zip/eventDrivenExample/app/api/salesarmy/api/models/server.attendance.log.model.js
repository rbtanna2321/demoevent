
'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps;

var AttendanceLogSchema = new Schema({

  attendanceDate: {type: Date, default: Date.now},
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: true
  },
  distributor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Distributor',
    autopopulate: true
  },
  isStart: {type: Boolean, default: true},
  isDeleted: {type: Boolean, default: false},

},{
  timestamps: true
});


AttendanceLogSchema.plugin(autopopulate);
AttendanceLogSchema.plugin(SimpleTimestamps);
AttendanceLogSchema.plugin(Paginate);
module.exports = mongoose.model('AttendanceLog', AttendanceLogSchema);