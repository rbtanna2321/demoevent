'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var wifiLogSchema = new Schema({
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: false
  },
  switchOnDate : Date,
  switchOffDate : Date,
  switchOnLocation: {
    latitude: {type: Number, default: 0},
    longitude: {type: Number, default: 0},
    address: String
  },
  switchOffLocation: {
    latitude: {type: Number, default: 0},
    longitude: {type: Number, default: 0},
    address: String
  },
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
wifiLogSchema.plugin(autopopulate);
wifiLogSchema.plugin(Paginate);
wifiLogSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Report-Wifi', wifiLogSchema);