'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var hotelSchema = new Schema({
  name: String,
  description: String,
  features: [String],
  images: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateFile'
  }],
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  location: {
    latitude: {type: Number, default: 0},
    longitude: {type: Number, default: 0},
    address: String
  },
  amenities: {
    geyser: {type: Boolean, default: false},
    tv: {type: Boolean, default: false},
    ac: {type: Boolean, default: false},
    parkingFacility: {type: Boolean, default: false},
    complimentaryVegBreakfast: {type: Boolean, default: false},
    cctvCameras: {type: Boolean, default: false},
    elevator: {type: Boolean, default: false},
    cardPayment: {type: Boolean, default: false},
    powerBackup: {type: Boolean, default: false},
    swimmingPool: {type: Boolean, default: false},
    conferenceRoom: {type: Boolean, default: false},
    bar: {type: Boolean, default: false},
    diningArea: {type: Boolean, default: false},
    wheelchairAccessible: {type: Boolean, default: false},
    banquetHall: {type: Boolean, default: false},
    inRoomSafe: {type: Boolean, default: false},
    miniFridge: {type: Boolean, default: false},
    inHouseRestaurant: {type: Boolean, default: false},
    freeWifi: {type: Boolean, default: false},
    gym: {type: Boolean, default: false},
    hairDryer: {type: Boolean, default: false},
    laundry: {type: Boolean, default: false},
    petFriendly: {type: Boolean, default: false},
    hdtv: {type: Boolean, default: false},
    spa: {type: Boolean, default: false},
    wellnessCenter: {type: Boolean, default: false},
    electricity: {type: Boolean, default: false},
    bathTub: {type: Boolean, default: false},
    kitchen: {type: Boolean, default: false},
    netflix: {type: Boolean, default: false},
    kindle: {type: Boolean, default: false},
    coffeeTeaMaker: {type: Boolean, default: false},
    sofaSet: {type: Boolean, default: false},
    jacuzzi: {type: Boolean, default: false},
    fullLengthMirror: {type: Boolean, default: false},
    balcony: {type: Boolean, default: false},
    kingBed: {type: Boolean, default: false},
    queenBed: {type: Boolean, default: false},
    singleBed: {type: Boolean, default: false},
    intercom: {type: Boolean, default: false},
    sufficientRoomSize: {type: Boolean, default: false},
    sufficientWashroom: {type: Boolean, default: false},
  },
  employee: {
    type: mongoose.Schema.ObjectId,
    ref: 'Sales-Employee'
  },
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
hotelSchema.plugin(autopopulate);
hotelSchema.plugin(Paginate);
hotelSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Hotel', hotelSchema);