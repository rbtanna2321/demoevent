'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps;

var NotificationSchema = new Schema({
  type: {type: String},
  hash: {type: String},
  payload: Object,
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee'
  },
  isDeleted: {type: Boolean, default: false}
}, {timestamps: true});

NotificationSchema.plugin(autopopulate);
NotificationSchema.plugin(require("./paginate-plugin"));
NotificationSchema.plugin(SimpleTimestamps);

module.exports = mongoose.model('Sales-Notification', NotificationSchema);