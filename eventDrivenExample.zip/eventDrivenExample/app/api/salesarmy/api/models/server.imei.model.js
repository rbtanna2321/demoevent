'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  autopopulate = require('mongoose-autopopulate');

var imeiSchema = new Schema({
  imeiNumber: String,
  userName: String,
  designation: String,
  mobile: String,
  location: String,


  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  isActive: {type: Boolean, default: false},
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
imeiSchema.plugin(autopopulate);
imeiSchema.plugin(Paginate);
module.exports = mongoose.model('Sales-IMEI', imeiSchema);