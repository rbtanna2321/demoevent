'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var teamSchema = new Schema({
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: {select: '_id firstName lastName homeLocation email currentLocation battery batteryChargeStatus profileColor nearestClient lastUpdatedAt'}
  },
  isManager: {type: Boolean, default: false},
  isLeader: {type: Boolean, default: false},
  team: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Team',
    autopopulate: true
  },
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
teamSchema.plugin(autopopulate);
teamSchema.plugin(Paginate);
teamSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-TeamRelation', teamSchema);