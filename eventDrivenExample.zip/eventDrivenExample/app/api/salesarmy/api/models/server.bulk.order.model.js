'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  Helper = require('../../../app/api/shared/server.helper.js'),
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps;

var OrderSchema = new Schema({

  orderId: {
    type: String, default: function () {
      var prefix = "OD-";
      var uniqueId = prefix + Math.floor(Date.now());
      return uniqueId.toString().toUpperCase();
    }
  },
  items: [
    {
      delivered: {type: Number, default: 0},
      quantity: {type: Number, default: 1},
      price: {type: Number, default: 0},
      item: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Sales-Product',
        autopopulate: true
      },
    }
  ],
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  buyer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: true
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: true
  },
  client: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Distributor',
    autopopulate: true
  },
  score: {
    type: Number, default: 0
  },
  status: {type: String, default: "pending"},
  note: {type: String},
  total: {type: Number, default: 0},
  isDeleted: {type: Boolean, default: false}
});

OrderSchema.plugin(autopopulate);
OrderSchema.plugin(SimpleTimestamps);
OrderSchema.plugin(Paginate);
module.exports = mongoose.model('Sales-Order', OrderSchema);