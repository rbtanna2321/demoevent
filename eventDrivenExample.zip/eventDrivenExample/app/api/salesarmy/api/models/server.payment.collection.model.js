'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var paymentCollectionSchema = new Schema({
  category: String,
  note: String,
  comment: String,
  company: String,
  amount: Number,
  dateOfPayment: {type: Date, default: Date.now},
  attachments: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateFile',
    autopopulate: true
  }],
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: true
  },
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});
paymentCollectionSchema.plugin(autopopulate);
paymentCollectionSchema.plugin(Paginate);
paymentCollectionSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-PaymentCollection', paymentCollectionSchema);