'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var beatPlanSchema = new Schema({
  planId: {
    type: String, default: function () {
      var prefix = "BEAT-";
      var uniqueId = prefix ? prefix + Math.floor(Date.now()) : Math.floor(Date.now()) + '';
      return uniqueId.toString().toUpperCase();
    }
  },
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: false
  },
  monday: {
    distributor: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Sales-Distributor',
      autopopulate: true
    }]
  },
  tuesday: {
    distributor: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Sales-Distributor',
      autopopulate: true
    }]
  },
  wednesday: {
    distributor: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Sales-Distributor',
      autopopulate: true
    }]
  },
  thursday: {
    distributor: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Sales-Distributor',
      autopopulate: true
    }]
  },
  friday: {
    distributor: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Sales-Distributor',
      autopopulate: true
    }]
  },
  saturday: {
    distributor: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Sales-Distributor',
      autopopulate: true
    }]
  },
  sunday: {
    distributor: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Sales-Distributor',
      autopopulate: true
    }]
  },
  isDeleted: {type: Boolean, default: false},
  isActive: {type: Boolean, default: false}
}, {
  timestamps: true
});
beatPlanSchema.plugin(autopopulate);
beatPlanSchema.plugin(Paginate);
beatPlanSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-BeatPlan', beatPlanSchema);