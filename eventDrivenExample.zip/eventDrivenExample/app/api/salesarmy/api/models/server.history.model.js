/**
 * Created by abc on 3/2/2016.
 */
'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  autopopulate = require('mongoose-autopopulate');

var LocationSchema = new Schema({
  position: {type: {type: String}, coordinates: []},
  address: String,
  fence: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Geofence'
  },
  battery: Number,
  batteryChargeStatus: Boolean,
  settings: {
    gps: Boolean,
    wifi: Boolean,
    carrier: Boolean,
    mock : {
      isInUse : Boolean,
      packages: [String]
    }
  },
  lastUpdatedAt: Date,
  accuracy: Number,
  provider: String
});

var historySchema = new Schema({
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: true
  },
  loc: [LocationSchema],
  isTrip: {type: Boolean, default: false},
  distanceTravelled: {type: Number, default: 0},
  inTime: Date,
  outTime: Date,
  other: String,
  day: Number,
  month: Number,
  year: Number
}, {
  timestamps: true
});
historySchema.index({"loc.position": "2dsphere"});

historySchema.plugin(autopopulate);
historySchema.plugin(Paginate);

module.exports = mongoose.model('Sales-History', historySchema);
