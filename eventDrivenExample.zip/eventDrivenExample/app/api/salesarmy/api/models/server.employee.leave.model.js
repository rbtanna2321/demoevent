'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var employeeLeaveSchema = new Schema({
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: true
  },
  remarks : String,
  reason : String,
  typeOfLeave: String,
  isApproved: {type: Boolean, default: false},
  approvedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: true
  },
  dateFrom: Date,
  dateTo: Date,
  isHalfDay: {type: Boolean, default: false},
  approvalDate: Date,
  isDeleted: {type: Boolean, default: false}
}, {
  timestamps: true
});


employeeLeaveSchema.plugin(autopopulate);
employeeLeaveSchema.plugin(Paginate);
employeeLeaveSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-EmployeeLeave', employeeLeaveSchema);