'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var chatMessageSchema = new Schema({
  chatId: {
    type: mongoose.Schema.ObjectId,
    ref: 'Sales-Chat',
  },
  message: String,
  sender: {
    type: mongoose.Schema.ObjectId,
    ref: 'Sales-Employee',
    autopopulate : {select: '_id name'}
  },
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  isDeleted: {type: Boolean, default: false},
  isActive: {type: Boolean, default: false}
}, {
  timestamps: true
});
chatMessageSchema.plugin(autopopulate);
chatMessageSchema.plugin(Paginate);
chatMessageSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-ChatMessage', chatMessageSchema);