'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var expenseSchema = new Schema({
  category: String,
  note: String,
  comment: String,
  company: String,
  amount: Number,
  invoiceFrom: String,
  dateOfExpense: {type: Date, default: Date.now},
  attachments: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateFile',
    autopopulate: true
  }],
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee',
    autopopulate: true
  },
  isDeleted: {type: Boolean, default: false},
  isApproved: Boolean
}, {
  timestamps: true
});
expenseSchema.plugin(autopopulate);
expenseSchema.plugin(Paginate);
expenseSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Expense', expenseSchema);