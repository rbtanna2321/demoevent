'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps;

var ReferralSchema = new Schema({
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  referrer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee'
  },
  parent: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee'
  },
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sales-Employee'
  },
  slotsBelow: {type: Number, default: 0},
  score: {type: Number, default: 0},
  groupScore: {type: Number, default: 0},
  groupHiddenScore: {type: Number, default: 0},
  secondRemittanceCompleted : {type: Boolean, default: false},
  withdrawal: {type: Number, default: 0},
  isDeleted: {type: Boolean, default: false}
});

ReferralSchema.plugin(autopopulate);
ReferralSchema.plugin(SimpleTimestamps);
ReferralSchema.plugin(Paginate);
module.exports = mongoose.model('Sales-Referrals', ReferralSchema);