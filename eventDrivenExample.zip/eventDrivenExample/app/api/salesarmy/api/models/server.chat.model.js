'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps,
  autopopulate = require('mongoose-autopopulate');

var chatSchema = new Schema({
  members: [{
    type: mongoose.Schema.ObjectId,
    ref: 'Sales-Employee',
  }],
  team: {
    type: mongoose.Schema.ObjectId,
    ref: 'Sales-Team',
    autopopulate: {select: '_id name'}
  },
  store: {
    type: mongoose.Schema.ObjectId,
    ref: 'Store',
  },
  isDeleted: {type: Boolean, default: false},
  isActive: {type: Boolean, default: false}
}, {
  timestamps: true
});
chatSchema.plugin(autopopulate);
chatSchema.plugin(Paginate);
chatSchema.plugin(SimpleTimestamps);
module.exports = mongoose.model('Sales-Chat', chatSchema);