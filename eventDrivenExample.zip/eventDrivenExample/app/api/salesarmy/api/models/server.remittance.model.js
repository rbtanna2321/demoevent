'use strict';
var mongoose = require('bluebird').promisifyAll(require('mongoose')),
  Schema = mongoose.Schema,
  autopopulate = require('mongoose-autopopulate'),
  Paginate = require('./paginate-plugin'),
  SimpleTimestamps = require("mongoose-simpletimestamps").SimpleTimestamps;

var RemittanceSchema = new Schema({
  store: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Store'
  },
  oneTimeOnly: {type: Boolean, default: false},
  remittanceToNumberOfPeople: {type: Number, default: 0},
  remittanceToParent: {type: Boolean, default: false},
  activeStatusRequired: {type: Boolean, default: false},
  remittanceAmount: {type: Number, default: 0},
  minTransactionAmount:  {type: Number, default: 0},
  isDeleted: {type: Boolean, default: false},
  type: {type: Number, default: 0},
  levels : [{
    level: Number,
    amount: Number,
    typeOfRemittance: String
  }]
});

RemittanceSchema.plugin(autopopulate);
RemittanceSchema.plugin(SimpleTimestamps);
RemittanceSchema.plugin(Paginate);
module.exports = mongoose.model('Sales-Remittances', RemittanceSchema);